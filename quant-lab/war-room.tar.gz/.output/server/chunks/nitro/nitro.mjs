import process from 'node:process';globalThis._importMeta_=globalThis._importMeta_||{url:"file:///_entry.js",env:process.env};import { promises, existsSync, writeFileSync, renameSync, unlinkSync, readFileSync, mkdirSync, statSync, readdirSync, realpathSync, lstatSync, readlinkSync, symlinkSync, rmdirSync } from 'node:fs';
import { resolve as resolve$1, dirname as dirname$1, join, relative } from 'node:path';
import { homedir } from 'node:os';
import { parseDocument, parse as parse$2, isMap, isScalar } from 'yaml';
import { DatabaseSync } from 'node:sqlite';
import { spawn } from 'node:child_process';
import http, { Server as Server$1 } from 'node:http';
import https, { Server } from 'node:https';
import { EventEmitter } from 'node:events';
import { Buffer as Buffer$1 } from 'node:buffer';
import { createHash, randomUUID } from 'node:crypto';
import { createRouterMatcher } from 'vue-router';
import { Readable, Writable, Transform } from 'node:stream';
import { ndJsonStream, ClientSideConnection, PROTOCOL_VERSION } from '@zed-industries/agent-client-protocol';
import { fileURLToPath } from 'node:url';
import { getIcons } from '@iconify/utils';
import { consola } from 'consola';

const suspectProtoRx = /"(?:_|\\u0{2}5[Ff]){2}(?:p|\\u0{2}70)(?:r|\\u0{2}72)(?:o|\\u0{2}6[Ff])(?:t|\\u0{2}74)(?:o|\\u0{2}6[Ff])(?:_|\\u0{2}5[Ff]){2}"\s*:/;
const suspectConstructorRx = /"(?:c|\\u0063)(?:o|\\u006[Ff])(?:n|\\u006[Ee])(?:s|\\u0073)(?:t|\\u0074)(?:r|\\u0072)(?:u|\\u0075)(?:c|\\u0063)(?:t|\\u0074)(?:o|\\u006[Ff])(?:r|\\u0072)"\s*:/;
const JsonSigRx = /^\s*["[{]|^\s*-?\d{1,16}(\.\d{1,17})?([Ee][+-]?\d+)?\s*$/;
function jsonParseTransform(key, value) {
  if (key === "__proto__" || key === "constructor" && value && typeof value === "object" && "prototype" in value) {
    warnKeyDropped(key);
    return;
  }
  return value;
}
function warnKeyDropped(key) {
  console.warn(`[destr] Dropping "${key}" key to prevent prototype pollution.`);
}
function destr(value, options = {}) {
  if (typeof value !== "string") {
    return value;
  }
  if (value[0] === '"' && value[value.length - 1] === '"' && value.indexOf("\\") === -1) {
    return value.slice(1, -1);
  }
  const _value = value.trim();
  if (_value.length <= 9) {
    switch (_value.toLowerCase()) {
      case "true": {
        return true;
      }
      case "false": {
        return false;
      }
      case "undefined": {
        return void 0;
      }
      case "null": {
        return null;
      }
      case "nan": {
        return Number.NaN;
      }
      case "infinity": {
        return Number.POSITIVE_INFINITY;
      }
      case "-infinity": {
        return Number.NEGATIVE_INFINITY;
      }
    }
  }
  if (!JsonSigRx.test(value)) {
    if (options.strict) {
      throw new SyntaxError("[destr] Invalid JSON");
    }
    return value;
  }
  try {
    if (suspectProtoRx.test(value) || suspectConstructorRx.test(value)) {
      if (options.strict) {
        throw new Error("[destr] Possible prototype pollution");
      }
      return JSON.parse(value, jsonParseTransform);
    }
    return JSON.parse(value);
  } catch (error) {
    if (options.strict) {
      throw error;
    }
    return value;
  }
}

const HASH_RE = /#/g;
const AMPERSAND_RE = /&/g;
const SLASH_RE = /\//g;
const EQUAL_RE = /=/g;
const IM_RE = /\?/g;
const PLUS_RE = /\+/g;
const ENC_CARET_RE = /%5e/gi;
const ENC_BACKTICK_RE = /%60/gi;
const ENC_PIPE_RE = /%7c/gi;
const ENC_SPACE_RE = /%20/gi;
const ENC_SLASH_RE = /%2f/gi;
const ENC_ENC_SLASH_RE = /%252f/gi;
function encode(text) {
  return encodeURI("" + text).replace(ENC_PIPE_RE, "|");
}
function encodeQueryValue(input) {
  return encode(typeof input === "string" ? input : JSON.stringify(input)).replace(PLUS_RE, "%2B").replace(ENC_SPACE_RE, "+").replace(HASH_RE, "%23").replace(AMPERSAND_RE, "%26").replace(ENC_BACKTICK_RE, "`").replace(ENC_CARET_RE, "^").replace(SLASH_RE, "%2F");
}
function encodeQueryKey(text) {
  return encodeQueryValue(text).replace(EQUAL_RE, "%3D");
}
function encodePath(text) {
  return encode(text).replace(HASH_RE, "%23").replace(IM_RE, "%3F").replace(ENC_ENC_SLASH_RE, "%2F").replace(AMPERSAND_RE, "%26").replace(PLUS_RE, "%2B");
}
function decode$2(text = "") {
  try {
    return decodeURIComponent("" + text);
  } catch {
    return "" + text;
  }
}
function decodePath(text) {
  return decode$2(text.replace(ENC_SLASH_RE, "%252F"));
}
function decodeQueryKey(text) {
  return decode$2(text.replace(PLUS_RE, " "));
}
function decodeQueryValue(text) {
  return decode$2(text.replace(PLUS_RE, " "));
}

function parseQuery(parametersString = "") {
  const object = /* @__PURE__ */ Object.create(null);
  if (parametersString[0] === "?") {
    parametersString = parametersString.slice(1);
  }
  for (const parameter of parametersString.split("&")) {
    const s = parameter.match(/([^=]+)=?(.*)/) || [];
    if (s.length < 2) {
      continue;
    }
    const key = decodeQueryKey(s[1]);
    if (key === "__proto__" || key === "constructor") {
      continue;
    }
    const value = decodeQueryValue(s[2] || "");
    if (object[key] === void 0) {
      object[key] = value;
    } else if (Array.isArray(object[key])) {
      object[key].push(value);
    } else {
      object[key] = [object[key], value];
    }
  }
  return object;
}
function encodeQueryItem(key, value) {
  if (typeof value === "number" || typeof value === "boolean") {
    value = String(value);
  }
  if (!value) {
    return encodeQueryKey(key);
  }
  if (Array.isArray(value)) {
    return value.map(
      (_value) => `${encodeQueryKey(key)}=${encodeQueryValue(_value)}`
    ).join("&");
  }
  return `${encodeQueryKey(key)}=${encodeQueryValue(value)}`;
}
function stringifyQuery(query) {
  return Object.keys(query).filter((k) => query[k] !== void 0).map((k) => encodeQueryItem(k, query[k])).filter(Boolean).join("&");
}

const PROTOCOL_STRICT_REGEX = /^[\s\w\0+.-]{2,}:([/\\]{1,2})/;
const PROTOCOL_REGEX = /^[\s\w\0+.-]{2,}:([/\\]{2})?/;
const PROTOCOL_RELATIVE_REGEX = /^([/\\]\s*){2,}[^/\\]/;
const PROTOCOL_SCRIPT_RE = /^[\s\0]*(blob|data|javascript|vbscript):$/i;
const TRAILING_SLASH_RE = /\/$|\/\?|\/#/;
const JOIN_LEADING_SLASH_RE = /^\.?\//;
function hasProtocol(inputString, opts = {}) {
  if (typeof opts === "boolean") {
    opts = { acceptRelative: opts };
  }
  if (opts.strict) {
    return PROTOCOL_STRICT_REGEX.test(inputString);
  }
  return PROTOCOL_REGEX.test(inputString) || (opts.acceptRelative ? PROTOCOL_RELATIVE_REGEX.test(inputString) : false);
}
function isScriptProtocol(protocol) {
  return !!protocol && PROTOCOL_SCRIPT_RE.test(protocol);
}
function hasTrailingSlash(input = "", respectQueryAndFragment) {
  if (!respectQueryAndFragment) {
    return input.endsWith("/");
  }
  return TRAILING_SLASH_RE.test(input);
}
function withoutTrailingSlash(input = "", respectQueryAndFragment) {
  if (!respectQueryAndFragment) {
    return (hasTrailingSlash(input) ? input.slice(0, -1) : input) || "/";
  }
  if (!hasTrailingSlash(input, true)) {
    return input || "/";
  }
  let path = input;
  let fragment = "";
  const fragmentIndex = input.indexOf("#");
  if (fragmentIndex !== -1) {
    path = input.slice(0, fragmentIndex);
    fragment = input.slice(fragmentIndex);
  }
  const [s0, ...s] = path.split("?");
  const cleanPath = s0.endsWith("/") ? s0.slice(0, -1) : s0;
  return (cleanPath || "/") + (s.length > 0 ? `?${s.join("?")}` : "") + fragment;
}
function withTrailingSlash(input = "", respectQueryAndFragment) {
  if (!respectQueryAndFragment) {
    return input.endsWith("/") ? input : input + "/";
  }
  if (hasTrailingSlash(input, true)) {
    return input || "/";
  }
  let path = input;
  let fragment = "";
  const fragmentIndex = input.indexOf("#");
  if (fragmentIndex !== -1) {
    path = input.slice(0, fragmentIndex);
    fragment = input.slice(fragmentIndex);
    if (!path) {
      return fragment;
    }
  }
  const [s0, ...s] = path.split("?");
  return s0 + "/" + (s.length > 0 ? `?${s.join("?")}` : "") + fragment;
}
function hasLeadingSlash(input = "") {
  return input.startsWith("/");
}
function withLeadingSlash(input = "") {
  return hasLeadingSlash(input) ? input : "/" + input;
}
function withBase(input, base) {
  if (isEmptyURL(base) || hasProtocol(input)) {
    return input;
  }
  const _base = withoutTrailingSlash(base);
  if (input.startsWith(_base)) {
    const nextChar = input[_base.length];
    if (!nextChar || nextChar === "/" || nextChar === "?") {
      return input;
    }
  }
  return joinURL(_base, input);
}
function withoutBase(input, base) {
  if (isEmptyURL(base)) {
    return input;
  }
  const _base = withoutTrailingSlash(base);
  if (!input.startsWith(_base)) {
    return input;
  }
  const nextChar = input[_base.length];
  if (nextChar && nextChar !== "/" && nextChar !== "?") {
    return input;
  }
  const trimmed = input.slice(_base.length);
  return trimmed[0] === "/" ? trimmed : "/" + trimmed;
}
function withQuery(input, query) {
  const parsed = parseURL(input);
  const mergedQuery = { ...parseQuery(parsed.search), ...query };
  parsed.search = stringifyQuery(mergedQuery);
  return stringifyParsedURL(parsed);
}
function getQuery$1(input) {
  return parseQuery(parseURL(input).search);
}
function isEmptyURL(url) {
  return !url || url === "/";
}
function isNonEmptyURL(url) {
  return url && url !== "/";
}
function joinURL(base, ...input) {
  let url = base || "";
  for (const segment of input.filter((url2) => isNonEmptyURL(url2))) {
    if (url) {
      const _segment = segment.replace(JOIN_LEADING_SLASH_RE, "");
      url = withTrailingSlash(url) + _segment;
    } else {
      url = segment;
    }
  }
  return url;
}
function joinRelativeURL(..._input) {
  const JOIN_SEGMENT_SPLIT_RE = /\/(?!\/)/;
  const input = _input.filter(Boolean);
  const segments = [];
  let segmentsDepth = 0;
  for (const i of input) {
    if (!i || i === "/") {
      continue;
    }
    for (const [sindex, s] of i.split(JOIN_SEGMENT_SPLIT_RE).entries()) {
      if (!s || s === ".") {
        continue;
      }
      if (s === "..") {
        if (segments.length === 1 && hasProtocol(segments[0])) {
          continue;
        }
        segments.pop();
        segmentsDepth--;
        continue;
      }
      if (sindex === 1 && segments[segments.length - 1]?.endsWith(":/")) {
        segments[segments.length - 1] += "/" + s;
        continue;
      }
      segments.push(s);
      segmentsDepth++;
    }
  }
  let url = segments.join("/");
  if (segmentsDepth >= 0) {
    if (input[0]?.startsWith("/") && !url.startsWith("/")) {
      url = "/" + url;
    } else if (input[0]?.startsWith("./") && !url.startsWith("./")) {
      url = "./" + url;
    }
  } else {
    url = "../".repeat(-1 * segmentsDepth) + url;
  }
  if (input[input.length - 1]?.endsWith("/") && !url.endsWith("/")) {
    url += "/";
  }
  return url;
}

const protocolRelative = Symbol.for("ufo:protocolRelative");
function parseURL(input = "", defaultProto) {
  const _specialProtoMatch = input.match(
    /^[\s\0]*(blob:|data:|javascript:|vbscript:)(.*)/i
  );
  if (_specialProtoMatch) {
    const [, _proto, _pathname = ""] = _specialProtoMatch;
    return {
      protocol: _proto.toLowerCase(),
      pathname: _pathname,
      href: _proto + _pathname,
      auth: "",
      host: "",
      search: "",
      hash: ""
    };
  }
  if (!hasProtocol(input, { acceptRelative: true })) {
    return parsePath(input);
  }
  const [, protocol = "", auth, hostAndPath = ""] = input.replace(/\\/g, "/").match(/^[\s\0]*([\w+.-]{2,}:)?\/\/([^/@]+@)?(.*)/) || [];
  let [, host = "", path = ""] = hostAndPath.match(/([^#/?]*)(.*)?/) || [];
  if (protocol === "file:") {
    path = path.replace(/\/(?=[A-Za-z]:)/, "");
  }
  const { pathname, search, hash } = parsePath(path);
  return {
    protocol: protocol.toLowerCase(),
    auth: auth ? auth.slice(0, Math.max(0, auth.length - 1)) : "",
    host,
    pathname,
    search,
    hash,
    [protocolRelative]: !protocol
  };
}
function parsePath(input = "") {
  const [pathname = "", search = "", hash = ""] = (input.match(/([^#?]*)(\?[^#]*)?(#.*)?/) || []).splice(1);
  return {
    pathname,
    search,
    hash
  };
}
function stringifyParsedURL(parsed) {
  const pathname = parsed.pathname || "";
  const search = parsed.search ? (parsed.search.startsWith("?") ? "" : "?") + parsed.search : "";
  const hash = parsed.hash || "";
  const auth = parsed.auth ? parsed.auth + "@" : "";
  const host = parsed.host || "";
  const proto = parsed.protocol || parsed[protocolRelative] ? (parsed.protocol || "") + "//" : "";
  return proto + auth + host + pathname + search + hash;
}

const NullObject$1 = /* @__PURE__ */ (() => {
  const C = function() {
  };
  C.prototype = /* @__PURE__ */ Object.create(null);
  return C;
})();
function parse$1(str, options) {
  if (typeof str !== "string") {
    throw new TypeError("argument str must be a string");
  }
  const obj = new NullObject$1();
  const opt = {};
  const dec = opt.decode || decode$1;
  let index = 0;
  while (index < str.length) {
    const eqIdx = str.indexOf("=", index);
    if (eqIdx === -1) {
      break;
    }
    let endIdx = str.indexOf(";", index);
    if (endIdx === -1) {
      endIdx = str.length;
    } else if (endIdx < eqIdx) {
      index = str.lastIndexOf(";", eqIdx - 1) + 1;
      continue;
    }
    const key = str.slice(index, eqIdx).trim();
    if (opt?.filter && !opt?.filter(key)) {
      index = endIdx + 1;
      continue;
    }
    if (void 0 === obj[key]) {
      let val = str.slice(eqIdx + 1, endIdx).trim();
      if (val.codePointAt(0) === 34) {
        val = val.slice(1, -1);
      }
      obj[key] = tryDecode$1(val, dec);
    }
    index = endIdx + 1;
  }
  return obj;
}
function decode$1(str) {
  return str.includes("%") ? decodeURIComponent(str) : str;
}
function tryDecode$1(str, decode2) {
  try {
    return decode2(str);
  } catch {
    return str;
  }
}

const fieldContentRegExp = /^[\u0009\u0020-\u007E\u0080-\u00FF]+$/;
function serialize$2(name, value, options) {
  const opt = options || {};
  const enc = opt.encode || encodeURIComponent;
  if (typeof enc !== "function") {
    throw new TypeError("option encode is invalid");
  }
  if (!fieldContentRegExp.test(name)) {
    throw new TypeError("argument name is invalid");
  }
  const encodedValue = enc(value);
  if (encodedValue && !fieldContentRegExp.test(encodedValue)) {
    throw new TypeError("argument val is invalid");
  }
  let str = name + "=" + encodedValue;
  if (void 0 !== opt.maxAge && opt.maxAge !== null) {
    const maxAge = opt.maxAge - 0;
    if (Number.isNaN(maxAge) || !Number.isFinite(maxAge)) {
      throw new TypeError("option maxAge is invalid");
    }
    str += "; Max-Age=" + Math.floor(maxAge);
  }
  if (opt.domain) {
    if (!fieldContentRegExp.test(opt.domain)) {
      throw new TypeError("option domain is invalid");
    }
    str += "; Domain=" + opt.domain;
  }
  if (opt.path) {
    if (!fieldContentRegExp.test(opt.path)) {
      throw new TypeError("option path is invalid");
    }
    str += "; Path=" + opt.path;
  }
  if (opt.expires) {
    if (!isDate(opt.expires) || Number.isNaN(opt.expires.valueOf())) {
      throw new TypeError("option expires is invalid");
    }
    str += "; Expires=" + opt.expires.toUTCString();
  }
  if (opt.httpOnly) {
    str += "; HttpOnly";
  }
  if (opt.secure) {
    str += "; Secure";
  }
  if (opt.priority) {
    const priority = typeof opt.priority === "string" ? opt.priority.toLowerCase() : opt.priority;
    switch (priority) {
      case "low": {
        str += "; Priority=Low";
        break;
      }
      case "medium": {
        str += "; Priority=Medium";
        break;
      }
      case "high": {
        str += "; Priority=High";
        break;
      }
      default: {
        throw new TypeError("option priority is invalid");
      }
    }
  }
  if (opt.sameSite) {
    const sameSite = typeof opt.sameSite === "string" ? opt.sameSite.toLowerCase() : opt.sameSite;
    switch (sameSite) {
      case true: {
        str += "; SameSite=Strict";
        break;
      }
      case "lax": {
        str += "; SameSite=Lax";
        break;
      }
      case "strict": {
        str += "; SameSite=Strict";
        break;
      }
      case "none": {
        str += "; SameSite=None";
        break;
      }
      default: {
        throw new TypeError("option sameSite is invalid");
      }
    }
  }
  if (opt.partitioned) {
    str += "; Partitioned";
  }
  return str;
}
function isDate(val) {
  return Object.prototype.toString.call(val) === "[object Date]" || val instanceof Date;
}

function parseSetCookie(setCookieValue, options) {
  const parts = (setCookieValue || "").split(";").filter((str) => typeof str === "string" && !!str.trim());
  const nameValuePairStr = parts.shift() || "";
  const parsed = _parseNameValuePair(nameValuePairStr);
  const name = parsed.name;
  let value = parsed.value;
  try {
    value = options?.decode === false ? value : (options?.decode || decodeURIComponent)(value);
  } catch {
  }
  const cookie = {
    name,
    value
  };
  for (const part of parts) {
    const sides = part.split("=");
    const partKey = (sides.shift() || "").trimStart().toLowerCase();
    const partValue = sides.join("=");
    switch (partKey) {
      case "expires": {
        cookie.expires = new Date(partValue);
        break;
      }
      case "max-age": {
        cookie.maxAge = Number.parseInt(partValue, 10);
        break;
      }
      case "secure": {
        cookie.secure = true;
        break;
      }
      case "httponly": {
        cookie.httpOnly = true;
        break;
      }
      case "samesite": {
        cookie.sameSite = partValue;
        break;
      }
      default: {
        cookie[partKey] = partValue;
      }
    }
  }
  return cookie;
}
function _parseNameValuePair(nameValuePairStr) {
  let name = "";
  let value = "";
  const nameValueArr = nameValuePairStr.split("=");
  if (nameValueArr.length > 1) {
    name = nameValueArr.shift();
    value = nameValueArr.join("=");
  } else {
    value = nameValuePairStr;
  }
  return { name, value };
}

const NODE_TYPES = {
  NORMAL: 0,
  WILDCARD: 1,
  PLACEHOLDER: 2
};

function createRouter$1(options = {}) {
  const ctx = {
    options,
    rootNode: createRadixNode(),
    staticRoutesMap: {}
  };
  const normalizeTrailingSlash = (p) => options.strictTrailingSlash ? p : p.replace(/\/$/, "") || "/";
  if (options.routes) {
    for (const path in options.routes) {
      insert(ctx, normalizeTrailingSlash(path), options.routes[path]);
    }
  }
  return {
    ctx,
    lookup: (path) => lookup(ctx, normalizeTrailingSlash(path)),
    insert: (path, data) => insert(ctx, normalizeTrailingSlash(path), data),
    remove: (path) => remove(ctx, normalizeTrailingSlash(path))
  };
}
function lookup(ctx, path) {
  const staticPathNode = ctx.staticRoutesMap[path];
  if (staticPathNode) {
    return staticPathNode.data;
  }
  const sections = path.split("/");
  const params = {};
  let paramsFound = false;
  let wildcardNode = null;
  let node = ctx.rootNode;
  let wildCardParam = null;
  for (let i = 0; i < sections.length; i++) {
    const section = sections[i];
    if (node.wildcardChildNode !== null) {
      wildcardNode = node.wildcardChildNode;
      wildCardParam = sections.slice(i).join("/");
    }
    const nextNode = node.children.get(section);
    if (nextNode === void 0) {
      if (node && node.placeholderChildren.length > 1) {
        const remaining = sections.length - i;
        node = node.placeholderChildren.find((c) => c.maxDepth === remaining) || null;
      } else {
        node = node.placeholderChildren[0] || null;
      }
      if (!node) {
        break;
      }
      if (node.paramName) {
        params[node.paramName] = section;
      }
      paramsFound = true;
    } else {
      node = nextNode;
    }
  }
  if ((node === null || node.data === null) && wildcardNode !== null) {
    node = wildcardNode;
    params[node.paramName || "_"] = wildCardParam;
    paramsFound = true;
  }
  if (!node) {
    return null;
  }
  if (paramsFound) {
    return {
      ...node.data,
      params: paramsFound ? params : void 0
    };
  }
  return node.data;
}
function insert(ctx, path, data) {
  let isStaticRoute = true;
  const sections = path.split("/");
  let node = ctx.rootNode;
  let _unnamedPlaceholderCtr = 0;
  const matchedNodes = [node];
  for (const section of sections) {
    let childNode;
    if (childNode = node.children.get(section)) {
      node = childNode;
    } else {
      const type = getNodeType(section);
      childNode = createRadixNode({ type, parent: node });
      node.children.set(section, childNode);
      if (type === NODE_TYPES.PLACEHOLDER) {
        childNode.paramName = section === "*" ? `_${_unnamedPlaceholderCtr++}` : section.slice(1);
        node.placeholderChildren.push(childNode);
        isStaticRoute = false;
      } else if (type === NODE_TYPES.WILDCARD) {
        node.wildcardChildNode = childNode;
        childNode.paramName = section.slice(
          3
          /* "**:" */
        ) || "_";
        isStaticRoute = false;
      }
      matchedNodes.push(childNode);
      node = childNode;
    }
  }
  for (const [depth, node2] of matchedNodes.entries()) {
    node2.maxDepth = Math.max(matchedNodes.length - depth, node2.maxDepth || 0);
  }
  node.data = data;
  if (isStaticRoute === true) {
    ctx.staticRoutesMap[path] = node;
  }
  return node;
}
function remove(ctx, path) {
  let success = false;
  const sections = path.split("/");
  let node = ctx.rootNode;
  for (const section of sections) {
    node = node.children.get(section);
    if (!node) {
      return success;
    }
  }
  if (node.data) {
    const lastSection = sections.at(-1) || "";
    node.data = null;
    if (Object.keys(node.children).length === 0 && node.parent) {
      node.parent.children.delete(lastSection);
      node.parent.wildcardChildNode = null;
      node.parent.placeholderChildren = [];
    }
    success = true;
  }
  return success;
}
function createRadixNode(options = {}) {
  return {
    type: options.type || NODE_TYPES.NORMAL,
    maxDepth: 0,
    parent: options.parent || null,
    children: /* @__PURE__ */ new Map(),
    data: options.data || null,
    paramName: options.paramName || null,
    wildcardChildNode: null,
    placeholderChildren: []
  };
}
function getNodeType(str) {
  if (str.startsWith("**")) {
    return NODE_TYPES.WILDCARD;
  }
  if (str[0] === ":" || str === "*") {
    return NODE_TYPES.PLACEHOLDER;
  }
  return NODE_TYPES.NORMAL;
}

function toRouteMatcher(router) {
  const table = _routerNodeToTable("", router.ctx.rootNode);
  return _createMatcher(table, router.ctx.options.strictTrailingSlash);
}
function _createMatcher(table, strictTrailingSlash) {
  return {
    ctx: { table },
    matchAll: (path) => _matchRoutes(path, table, strictTrailingSlash)
  };
}
function _createRouteTable() {
  return {
    static: /* @__PURE__ */ new Map(),
    wildcard: /* @__PURE__ */ new Map(),
    dynamic: /* @__PURE__ */ new Map()
  };
}
function _matchRoutes(path, table, strictTrailingSlash) {
  if (strictTrailingSlash !== true && path.endsWith("/")) {
    path = path.slice(0, -1) || "/";
  }
  const matches = [];
  for (const [key, value] of _sortRoutesMap(table.wildcard)) {
    if (path === key || path.startsWith(key + "/")) {
      matches.push(value);
    }
  }
  for (const [key, value] of _sortRoutesMap(table.dynamic)) {
    if (path.startsWith(key + "/")) {
      const subPath = "/" + path.slice(key.length).split("/").splice(2).join("/");
      matches.push(..._matchRoutes(subPath, value));
    }
  }
  const staticMatch = table.static.get(path);
  if (staticMatch) {
    matches.push(staticMatch);
  }
  return matches.filter(Boolean);
}
function _sortRoutesMap(m) {
  return [...m.entries()].sort((a, b) => a[0].length - b[0].length);
}
function _routerNodeToTable(initialPath, initialNode) {
  const table = _createRouteTable();
  function _addNode(path, node) {
    if (path) {
      if (node.type === NODE_TYPES.NORMAL && !(path.includes("*") || path.includes(":"))) {
        if (node.data) {
          table.static.set(path, node.data);
        }
      } else if (node.type === NODE_TYPES.WILDCARD) {
        table.wildcard.set(path.replace("/**", ""), node.data);
      } else if (node.type === NODE_TYPES.PLACEHOLDER) {
        const subTable = _routerNodeToTable("", node);
        if (node.data) {
          subTable.static.set("/", node.data);
        }
        table.dynamic.set(path.replace(/\/\*|\/:\w+/, ""), subTable);
        return;
      }
    }
    for (const [childPath, child] of node.children.entries()) {
      _addNode(`${path}/${childPath}`.replace("//", "/"), child);
    }
  }
  _addNode(initialPath, initialNode);
  return table;
}

function isPlainObject(value) {
  if (value === null || typeof value !== "object") {
    return false;
  }
  const prototype = Object.getPrototypeOf(value);
  if (prototype !== null && prototype !== Object.prototype && Object.getPrototypeOf(prototype) !== null) {
    return false;
  }
  if (Symbol.iterator in value) {
    return false;
  }
  if (Symbol.toStringTag in value) {
    return Object.prototype.toString.call(value) === "[object Module]";
  }
  return true;
}

function _defu(baseObject, defaults, namespace = ".", merger) {
  if (!isPlainObject(defaults)) {
    return _defu(baseObject, {}, namespace, merger);
  }
  const object = { ...defaults };
  for (const key of Object.keys(baseObject)) {
    if (key === "__proto__" || key === "constructor") {
      continue;
    }
    const value = baseObject[key];
    if (value === null || value === void 0) {
      continue;
    }
    if (merger && merger(object, key, value, namespace)) {
      continue;
    }
    if (Array.isArray(value) && Array.isArray(object[key])) {
      object[key] = [...value, ...object[key]];
    } else if (isPlainObject(value) && isPlainObject(object[key])) {
      object[key] = _defu(
        value,
        object[key],
        (namespace ? `${namespace}.` : "") + key.toString(),
        merger
      );
    } else {
      object[key] = value;
    }
  }
  return object;
}
function createDefu(merger) {
  return (...arguments_) => (
    // eslint-disable-next-line unicorn/no-array-reduce
    arguments_.reduce((p, c) => _defu(p, c, "", merger), {})
  );
}
const defu = createDefu();
const defuFn = createDefu((object, key, currentValue) => {
  if (object[key] !== void 0 && typeof currentValue === "function") {
    object[key] = currentValue(object[key]);
    return true;
  }
});

function o(n){throw new Error(`${n} is not implemented yet!`)}let i$1 = class i extends EventEmitter{__unenv__={};readableEncoding=null;readableEnded=true;readableFlowing=false;readableHighWaterMark=0;readableLength=0;readableObjectMode=false;readableAborted=false;readableDidRead=false;closed=false;errored=null;readable=false;destroyed=false;static from(e,t){return new i(t)}constructor(e){super();}_read(e){}read(e){}setEncoding(e){return this}pause(){return this}resume(){return this}isPaused(){return  true}unpipe(e){return this}unshift(e,t){}wrap(e){return this}push(e,t){return  false}_destroy(e,t){this.removeAllListeners();}destroy(e){return this.destroyed=true,this._destroy(e),this}pipe(e,t){return {}}compose(e,t){throw new Error("Method not implemented.")}[Symbol.asyncDispose](){return this.destroy(),Promise.resolve()}async*[Symbol.asyncIterator](){throw o("Readable.asyncIterator")}iterator(e){throw o("Readable.iterator")}map(e,t){throw o("Readable.map")}filter(e,t){throw o("Readable.filter")}forEach(e,t){throw o("Readable.forEach")}reduce(e,t,r){throw o("Readable.reduce")}find(e,t){throw o("Readable.find")}findIndex(e,t){throw o("Readable.findIndex")}some(e,t){throw o("Readable.some")}toArray(e){throw o("Readable.toArray")}every(e,t){throw o("Readable.every")}flatMap(e,t){throw o("Readable.flatMap")}drop(e,t){throw o("Readable.drop")}take(e,t){throw o("Readable.take")}asIndexedPairs(e){throw o("Readable.asIndexedPairs")}};let l$1 = class l extends EventEmitter{__unenv__={};writable=true;writableEnded=false;writableFinished=false;writableHighWaterMark=0;writableLength=0;writableObjectMode=false;writableCorked=0;closed=false;errored=null;writableNeedDrain=false;writableAborted=false;destroyed=false;_data;_encoding="utf8";constructor(e){super();}pipe(e,t){return {}}_write(e,t,r){if(this.writableEnded){r&&r();return}if(this._data===void 0)this._data=e;else {const s=typeof this._data=="string"?Buffer$1.from(this._data,this._encoding||t||"utf8"):this._data,a=typeof e=="string"?Buffer$1.from(e,t||this._encoding||"utf8"):e;this._data=Buffer$1.concat([s,a]);}this._encoding=t,r&&r();}_writev(e,t){}_destroy(e,t){}_final(e){}write(e,t,r){const s=typeof t=="string"?this._encoding:"utf8",a=typeof t=="function"?t:typeof r=="function"?r:void 0;return this._write(e,s,a),true}setDefaultEncoding(e){return this}end(e,t,r){const s=typeof e=="function"?e:typeof t=="function"?t:typeof r=="function"?r:void 0;if(this.writableEnded)return s&&s(),this;const a=e===s?void 0:e;if(a){const u=t===s?void 0:t;this.write(a,u,s);}return this.writableEnded=true,this.writableFinished=true,this.emit("close"),this.emit("finish"),this}cork(){}uncork(){}destroy(e){return this.destroyed=true,delete this._data,this.removeAllListeners(),this}compose(e,t){throw new Error("Method not implemented.")}[Symbol.asyncDispose](){return Promise.resolve()}};const c$1=class c{allowHalfOpen=true;_destroy;constructor(e=new i$1,t=new l$1){Object.assign(this,e),Object.assign(this,t),this._destroy=m(e._destroy,t._destroy);}};function _(){return Object.assign(c$1.prototype,i$1.prototype),Object.assign(c$1.prototype,l$1.prototype),c$1}function m(...n){return function(...e){for(const t of n)t(...e);}}const g=_();class A extends g{__unenv__={};bufferSize=0;bytesRead=0;bytesWritten=0;connecting=false;destroyed=false;pending=false;localAddress="";localPort=0;remoteAddress="";remoteFamily="";remotePort=0;autoSelectFamilyAttemptedAddresses=[];readyState="readOnly";constructor(e){super();}write(e,t,r){return  false}connect(e,t,r){return this}end(e,t,r){return this}setEncoding(e){return this}pause(){return this}resume(){return this}setTimeout(e,t){return this}setNoDelay(e){return this}setKeepAlive(e,t){return this}address(){return {}}unref(){return this}ref(){return this}destroySoon(){this.destroy();}resetAndDestroy(){const e=new Error("ERR_SOCKET_CLOSED");return e.code="ERR_SOCKET_CLOSED",this.destroy(e),this}}class y extends i$1{aborted=false;httpVersion="1.1";httpVersionMajor=1;httpVersionMinor=1;complete=true;connection;socket;headers={};trailers={};method="GET";url="/";statusCode=200;statusMessage="";closed=false;errored=null;readable=false;constructor(e){super(),this.socket=this.connection=e||new A;}get rawHeaders(){const e=this.headers,t=[];for(const r in e)if(Array.isArray(e[r]))for(const s of e[r])t.push(r,s);else t.push(r,e[r]);return t}get rawTrailers(){return []}setTimeout(e,t){return this}get headersDistinct(){return p(this.headers)}get trailersDistinct(){return p(this.trailers)}}function p(n){const e={};for(const[t,r]of Object.entries(n))t&&(e[t]=(Array.isArray(r)?r:[r]).filter(Boolean));return e}class w extends l$1{statusCode=200;statusMessage="";upgrading=false;chunkedEncoding=false;shouldKeepAlive=false;useChunkedEncodingByDefault=false;sendDate=false;finished=false;headersSent=false;strictContentLength=false;connection=null;socket=null;req;_headers={};constructor(e){super(),this.req=e;}assignSocket(e){e._httpMessage=this,this.socket=e,this.connection=e,this.emit("socket",e),this._flush();}_flush(){this.flushHeaders();}detachSocket(e){}writeContinue(e){}writeHead(e,t,r){e&&(this.statusCode=e),typeof t=="string"&&(this.statusMessage=t,t=void 0);const s=r||t;if(s&&!Array.isArray(s))for(const a in s)this.setHeader(a,s[a]);return this.headersSent=true,this}writeProcessing(){}setTimeout(e,t){return this}appendHeader(e,t){e=e.toLowerCase();const r=this._headers[e],s=[...Array.isArray(r)?r:[r],...Array.isArray(t)?t:[t]].filter(Boolean);return this._headers[e]=s.length>1?s:s[0],this}setHeader(e,t){return this._headers[e.toLowerCase()]=t,this}setHeaders(e){for(const[t,r]of Object.entries(e))this.setHeader(t,r);return this}getHeader(e){return this._headers[e.toLowerCase()]}getHeaders(){return this._headers}getHeaderNames(){return Object.keys(this._headers)}hasHeader(e){return e.toLowerCase()in this._headers}removeHeader(e){delete this._headers[e.toLowerCase()];}addTrailers(e){}flushHeaders(){}writeEarlyHints(e,t){typeof t=="function"&&t();}}const E=(()=>{const n=function(){};return n.prototype=Object.create(null),n})();function R(n={}){const e=new E,t=Array.isArray(n)||H(n)?n:Object.entries(n);for(const[r,s]of t)if(s){if(e[r]===void 0){e[r]=s;continue}e[r]=[...Array.isArray(e[r])?e[r]:[e[r]],...Array.isArray(s)?s:[s]];}return e}function H(n){return typeof n?.entries=="function"}function v(n={}){if(n instanceof Headers)return n;const e=new Headers;for(const[t,r]of Object.entries(n))if(r!==void 0){if(Array.isArray(r)){for(const s of r)e.append(t,String(s));continue}e.set(t,String(r));}return e}const S=new Set([101,204,205,304]);async function b(n,e){const t=new y,r=new w(t);t.url=e.url?.toString()||"/";let s;if(!t.url.startsWith("/")){const d=new URL(t.url);s=d.host,t.url=d.pathname+d.search+d.hash;}t.method=e.method||"GET",t.headers=R(e.headers||{}),t.headers.host||(t.headers.host=e.host||s||"localhost"),t.connection.encrypted=t.connection.encrypted||e.protocol==="https",t.body=e.body||null,t.__unenv__=e.context,await n(t,r);let a=r._data;(S.has(r.statusCode)||t.method.toUpperCase()==="HEAD")&&(a=null,delete r._headers["content-length"]);const u={status:r.statusCode,statusText:r.statusMessage,headers:r._headers,body:a};return t.destroy(),r.destroy(),u}async function C(n,e,t={}){try{const r=await b(n,{url:e,...t});return new Response(r.body,{status:r.status,statusText:r.statusText,headers:v(r.headers)})}catch(r){return new Response(r.toString(),{status:Number.parseInt(r.statusCode||r.code)||500,statusText:r.statusText})}}

function hasProp(obj, prop) {
  try {
    return prop in obj;
  } catch {
    return false;
  }
}

class H3Error extends Error {
  static __h3_error__ = true;
  statusCode = 500;
  fatal = false;
  unhandled = false;
  statusMessage;
  data;
  cause;
  constructor(message, opts = {}) {
    super(message, opts);
    if (opts.cause && !this.cause) {
      this.cause = opts.cause;
    }
  }
  toJSON() {
    const obj = {
      message: this.message,
      statusCode: sanitizeStatusCode(this.statusCode, 500)
    };
    if (this.statusMessage) {
      obj.statusMessage = sanitizeStatusMessage(this.statusMessage);
    }
    if (this.data !== void 0) {
      obj.data = this.data;
    }
    return obj;
  }
}
function createError$1(input) {
  if (typeof input === "string") {
    return new H3Error(input);
  }
  if (isError(input)) {
    return input;
  }
  const err = new H3Error(input.message ?? input.statusMessage ?? "", {
    cause: input.cause || input
  });
  if (hasProp(input, "stack")) {
    try {
      Object.defineProperty(err, "stack", {
        get() {
          return input.stack;
        }
      });
    } catch {
      try {
        err.stack = input.stack;
      } catch {
      }
    }
  }
  if (input.data) {
    err.data = input.data;
  }
  if (input.statusCode) {
    err.statusCode = sanitizeStatusCode(input.statusCode, err.statusCode);
  } else if (input.status) {
    err.statusCode = sanitizeStatusCode(input.status, err.statusCode);
  }
  if (input.statusMessage) {
    err.statusMessage = input.statusMessage;
  } else if (input.statusText) {
    err.statusMessage = input.statusText;
  }
  if (err.statusMessage) {
    const originalMessage = err.statusMessage;
    const sanitizedMessage = sanitizeStatusMessage(err.statusMessage);
    if (sanitizedMessage !== originalMessage) {
      console.warn(
        "[h3] Please prefer using `message` for longer error messages instead of `statusMessage`. In the future, `statusMessage` will be sanitized by default."
      );
    }
  }
  if (input.fatal !== void 0) {
    err.fatal = input.fatal;
  }
  if (input.unhandled !== void 0) {
    err.unhandled = input.unhandled;
  }
  return err;
}
function sendError(event, error, debug) {
  if (event.handled) {
    return;
  }
  const h3Error = isError(error) ? error : createError$1(error);
  const responseBody = {
    statusCode: h3Error.statusCode,
    statusMessage: h3Error.statusMessage,
    stack: [],
    data: h3Error.data
  };
  if (debug) {
    responseBody.stack = (h3Error.stack || "").split("\n").map((l) => l.trim());
  }
  if (event.handled) {
    return;
  }
  const _code = Number.parseInt(h3Error.statusCode);
  setResponseStatus(event, _code, h3Error.statusMessage);
  event.node.res.setHeader("content-type", MIMES.json);
  event.node.res.end(JSON.stringify(responseBody, void 0, 2));
}
function isError(input) {
  return input?.constructor?.__h3_error__ === true;
}

function getQuery(event) {
  return getQuery$1(event.path || "");
}
function getRouterParams(event, opts = {}) {
  let params = event.context.params || {};
  if (opts.decode) {
    params = { ...params };
    for (const key in params) {
      params[key] = decode$2(params[key]);
    }
  }
  return params;
}
function getRouterParam(event, name, opts = {}) {
  const params = getRouterParams(event, opts);
  return params[name];
}
function isMethod(event, expected, allowHead) {
  if (typeof expected === "string") {
    if (event.method === expected) {
      return true;
    }
  } else if (expected.includes(event.method)) {
    return true;
  }
  return false;
}
function assertMethod(event, expected, allowHead) {
  if (!isMethod(event, expected)) {
    throw createError$1({
      statusCode: 405,
      statusMessage: "HTTP method is not allowed."
    });
  }
}
function getRequestHeaders(event) {
  const _headers = {};
  for (const key in event.node.req.headers) {
    const val = event.node.req.headers[key];
    _headers[key] = Array.isArray(val) ? val.filter(Boolean).join(", ") : val;
  }
  return _headers;
}
function getRequestHeader(event, name) {
  const headers = getRequestHeaders(event);
  const value = headers[name.toLowerCase()];
  return value;
}
const getHeader = getRequestHeader;
function getRequestHost(event, opts = {}) {
  if (opts.xForwardedHost) {
    const _header = event.node.req.headers["x-forwarded-host"];
    const xForwardedHost = (_header || "").split(",").shift()?.trim();
    if (xForwardedHost) {
      return xForwardedHost;
    }
  }
  return event.node.req.headers.host || "localhost";
}
function getRequestProtocol(event, opts = {}) {
  if (opts.xForwardedProto !== false && event.node.req.headers["x-forwarded-proto"] === "https") {
    return "https";
  }
  return event.node.req.connection?.encrypted ? "https" : "http";
}
function getRequestURL(event, opts = {}) {
  const host = getRequestHost(event, opts);
  const protocol = getRequestProtocol(event, opts);
  const path = (event.node.req.originalUrl || event.path).replace(
    /^[/\\]+/g,
    "/"
  );
  return new URL(path, `${protocol}://${host}`);
}

const RawBodySymbol = Symbol.for("h3RawBody");
const ParsedBodySymbol = Symbol.for("h3ParsedBody");
const PayloadMethods$1 = ["PATCH", "POST", "PUT", "DELETE"];
function readRawBody(event, encoding = "utf8") {
  assertMethod(event, PayloadMethods$1);
  const _rawBody = event._requestBody || event.web?.request?.body || event.node.req[RawBodySymbol] || event.node.req.rawBody || event.node.req.body;
  if (_rawBody) {
    const promise2 = Promise.resolve(_rawBody).then((_resolved) => {
      if (Buffer.isBuffer(_resolved)) {
        return _resolved;
      }
      if (typeof _resolved.pipeTo === "function") {
        return new Promise((resolve, reject) => {
          const chunks = [];
          _resolved.pipeTo(
            new WritableStream({
              write(chunk) {
                chunks.push(chunk);
              },
              close() {
                resolve(Buffer.concat(chunks));
              },
              abort(reason) {
                reject(reason);
              }
            })
          ).catch(reject);
        });
      } else if (typeof _resolved.pipe === "function") {
        return new Promise((resolve, reject) => {
          const chunks = [];
          _resolved.on("data", (chunk) => {
            chunks.push(chunk);
          }).on("end", () => {
            resolve(Buffer.concat(chunks));
          }).on("error", reject);
        });
      }
      if (_resolved.constructor === Object) {
        return Buffer.from(JSON.stringify(_resolved));
      }
      if (_resolved instanceof URLSearchParams) {
        return Buffer.from(_resolved.toString());
      }
      if (_resolved instanceof FormData) {
        return new Response(_resolved).bytes().then((uint8arr) => Buffer.from(uint8arr));
      }
      return Buffer.from(_resolved);
    });
    return encoding ? promise2.then((buff) => buff.toString(encoding)) : promise2;
  }
  if (!Number.parseInt(event.node.req.headers["content-length"] || "") && !/\bchunked\b/i.test(
    String(event.node.req.headers["transfer-encoding"] ?? "")
  )) {
    return Promise.resolve(void 0);
  }
  const promise = event.node.req[RawBodySymbol] = new Promise(
    (resolve, reject) => {
      const bodyData = [];
      event.node.req.on("error", (err) => {
        reject(err);
      }).on("data", (chunk) => {
        bodyData.push(chunk);
      }).on("end", () => {
        resolve(Buffer.concat(bodyData));
      });
    }
  );
  const result = encoding ? promise.then((buff) => buff.toString(encoding)) : promise;
  return result;
}
async function readBody(event, options = {}) {
  const request = event.node.req;
  if (hasProp(request, ParsedBodySymbol)) {
    return request[ParsedBodySymbol];
  }
  const contentType = request.headers["content-type"] || "";
  const body = await readRawBody(event);
  let parsed;
  if (contentType === "application/json") {
    parsed = _parseJSON(body, options.strict ?? true);
  } else if (contentType.startsWith("application/x-www-form-urlencoded")) {
    parsed = _parseURLEncodedBody(body);
  } else if (contentType.startsWith("text/")) {
    parsed = body;
  } else {
    parsed = _parseJSON(body, options.strict ?? false);
  }
  request[ParsedBodySymbol] = parsed;
  return parsed;
}
function getRequestWebStream(event) {
  if (!PayloadMethods$1.includes(event.method)) {
    return;
  }
  const bodyStream = event.web?.request?.body || event._requestBody;
  if (bodyStream) {
    return bodyStream;
  }
  const _hasRawBody = RawBodySymbol in event.node.req || "rawBody" in event.node.req || "body" in event.node.req || "__unenv__" in event.node.req;
  if (_hasRawBody) {
    return new ReadableStream({
      async start(controller) {
        const _rawBody = await readRawBody(event, false);
        if (_rawBody) {
          controller.enqueue(_rawBody);
        }
        controller.close();
      }
    });
  }
  return new ReadableStream({
    start: (controller) => {
      event.node.req.on("data", (chunk) => {
        controller.enqueue(chunk);
      });
      event.node.req.on("end", () => {
        controller.close();
      });
      event.node.req.on("error", (err) => {
        controller.error(err);
      });
    }
  });
}
function _parseJSON(body = "", strict) {
  if (!body) {
    return void 0;
  }
  try {
    return destr(body, { strict });
  } catch {
    throw createError$1({
      statusCode: 400,
      statusMessage: "Bad Request",
      message: "Invalid JSON body"
    });
  }
}
function _parseURLEncodedBody(body) {
  const form = new URLSearchParams(body);
  const parsedForm = /* @__PURE__ */ Object.create(null);
  for (const [key, value] of form.entries()) {
    if (hasProp(parsedForm, key)) {
      if (!Array.isArray(parsedForm[key])) {
        parsedForm[key] = [parsedForm[key]];
      }
      parsedForm[key].push(value);
    } else {
      parsedForm[key] = value;
    }
  }
  return parsedForm;
}

function handleCacheHeaders(event, opts) {
  const cacheControls = ["public", ...opts.cacheControls || []];
  let cacheMatched = false;
  if (opts.maxAge !== void 0) {
    cacheControls.push(`max-age=${+opts.maxAge}`, `s-maxage=${+opts.maxAge}`);
  }
  if (opts.modifiedTime) {
    const modifiedTime = new Date(opts.modifiedTime);
    const ifModifiedSince = event.node.req.headers["if-modified-since"];
    event.node.res.setHeader("last-modified", modifiedTime.toUTCString());
    if (ifModifiedSince && new Date(ifModifiedSince) >= modifiedTime) {
      cacheMatched = true;
    }
  }
  if (opts.etag) {
    event.node.res.setHeader("etag", opts.etag);
    const ifNonMatch = event.node.req.headers["if-none-match"];
    if (ifNonMatch === opts.etag) {
      cacheMatched = true;
    }
  }
  event.node.res.setHeader("cache-control", cacheControls.join(", "));
  if (cacheMatched) {
    event.node.res.statusCode = 304;
    if (!event.handled) {
      event.node.res.end();
    }
    return true;
  }
  return false;
}

const MIMES = {
  html: "text/html",
  json: "application/json"
};

const DISALLOWED_STATUS_CHARS = /[^\u0009\u0020-\u007E]/g;
function sanitizeStatusMessage(statusMessage = "") {
  return statusMessage.replace(DISALLOWED_STATUS_CHARS, "");
}
function sanitizeStatusCode(statusCode, defaultStatusCode = 200) {
  if (!statusCode) {
    return defaultStatusCode;
  }
  if (typeof statusCode === "string") {
    statusCode = Number.parseInt(statusCode, 10);
  }
  if (statusCode < 100 || statusCode > 999) {
    return defaultStatusCode;
  }
  return statusCode;
}

function getDistinctCookieKey(name, opts) {
  return [name, opts.domain || "", opts.path || "/"].join(";");
}

function parseCookies(event) {
  return parse$1(event.node.req.headers.cookie || "");
}
function getCookie(event, name) {
  return parseCookies(event)[name];
}
function setCookie(event, name, value, serializeOptions = {}) {
  if (!serializeOptions.path) {
    serializeOptions = { path: "/", ...serializeOptions };
  }
  const newCookie = serialize$2(name, value, serializeOptions);
  const currentCookies = splitCookiesString(
    event.node.res.getHeader("set-cookie")
  );
  if (currentCookies.length === 0) {
    event.node.res.setHeader("set-cookie", newCookie);
    return;
  }
  const newCookieKey = getDistinctCookieKey(name, serializeOptions);
  event.node.res.removeHeader("set-cookie");
  for (const cookie of currentCookies) {
    const parsed = parseSetCookie(cookie);
    const key = getDistinctCookieKey(parsed.name, parsed);
    if (key === newCookieKey) {
      continue;
    }
    event.node.res.appendHeader("set-cookie", cookie);
  }
  event.node.res.appendHeader("set-cookie", newCookie);
}
function deleteCookie(event, name, serializeOptions) {
  setCookie(event, name, "", {
    ...serializeOptions,
    maxAge: 0
  });
}
function splitCookiesString(cookiesString) {
  if (Array.isArray(cookiesString)) {
    return cookiesString.flatMap((c) => splitCookiesString(c));
  }
  if (typeof cookiesString !== "string") {
    return [];
  }
  const cookiesStrings = [];
  let pos = 0;
  let start;
  let ch;
  let lastComma;
  let nextStart;
  let cookiesSeparatorFound;
  const skipWhitespace = () => {
    while (pos < cookiesString.length && /\s/.test(cookiesString.charAt(pos))) {
      pos += 1;
    }
    return pos < cookiesString.length;
  };
  const notSpecialChar = () => {
    ch = cookiesString.charAt(pos);
    return ch !== "=" && ch !== ";" && ch !== ",";
  };
  while (pos < cookiesString.length) {
    start = pos;
    cookiesSeparatorFound = false;
    while (skipWhitespace()) {
      ch = cookiesString.charAt(pos);
      if (ch === ",") {
        lastComma = pos;
        pos += 1;
        skipWhitespace();
        nextStart = pos;
        while (pos < cookiesString.length && notSpecialChar()) {
          pos += 1;
        }
        if (pos < cookiesString.length && cookiesString.charAt(pos) === "=") {
          cookiesSeparatorFound = true;
          pos = nextStart;
          cookiesStrings.push(cookiesString.slice(start, lastComma));
          start = pos;
        } else {
          pos = lastComma + 1;
        }
      } else {
        pos += 1;
      }
    }
    if (!cookiesSeparatorFound || pos >= cookiesString.length) {
      cookiesStrings.push(cookiesString.slice(start));
    }
  }
  return cookiesStrings;
}

const defer = typeof setImmediate === "undefined" ? (fn) => fn() : setImmediate;
function send(event, data, type) {
  if (type) {
    defaultContentType(event, type);
  }
  return new Promise((resolve) => {
    defer(() => {
      if (!event.handled) {
        event.node.res.end(data);
      }
      resolve();
    });
  });
}
function sendNoContent(event, code) {
  if (event.handled) {
    return;
  }
  if (!code && event.node.res.statusCode !== 200) {
    code = event.node.res.statusCode;
  }
  const _code = sanitizeStatusCode(code, 204);
  if (_code === 204) {
    event.node.res.removeHeader("content-length");
  }
  event.node.res.writeHead(_code);
  event.node.res.end();
}
function setResponseStatus(event, code, text) {
  if (code) {
    event.node.res.statusCode = sanitizeStatusCode(
      code,
      event.node.res.statusCode
    );
  }
  if (text) {
    event.node.res.statusMessage = sanitizeStatusMessage(text);
  }
}
function getResponseStatus(event) {
  return event.node.res.statusCode;
}
function getResponseStatusText(event) {
  return event.node.res.statusMessage;
}
function defaultContentType(event, type) {
  if (type && event.node.res.statusCode !== 304 && !event.node.res.getHeader("content-type")) {
    event.node.res.setHeader("content-type", type);
  }
}
function sendRedirect(event, location, code = 302) {
  event.node.res.statusCode = sanitizeStatusCode(
    code,
    event.node.res.statusCode
  );
  event.node.res.setHeader("location", location);
  const encodedLoc = location.replace(/"/g, "%22");
  const html = `<!DOCTYPE html><html><head><meta http-equiv="refresh" content="0; url=${encodedLoc}"></head></html>`;
  return send(event, html, MIMES.html);
}
function getResponseHeader(event, name) {
  return event.node.res.getHeader(name);
}
function setResponseHeaders(event, headers) {
  for (const [name, value] of Object.entries(headers)) {
    event.node.res.setHeader(
      name,
      value
    );
  }
}
const setHeaders = setResponseHeaders;
function setResponseHeader(event, name, value) {
  event.node.res.setHeader(name, value);
}
function appendResponseHeader(event, name, value) {
  let current = event.node.res.getHeader(name);
  if (!current) {
    event.node.res.setHeader(name, value);
    return;
  }
  if (!Array.isArray(current)) {
    current = [current.toString()];
  }
  event.node.res.setHeader(name, [...current, value]);
}
function removeResponseHeader(event, name) {
  return event.node.res.removeHeader(name);
}
function isStream(data) {
  if (!data || typeof data !== "object") {
    return false;
  }
  if (typeof data.pipe === "function") {
    if (typeof data._read === "function") {
      return true;
    }
    if (typeof data.abort === "function") {
      return true;
    }
  }
  if (typeof data.pipeTo === "function") {
    return true;
  }
  return false;
}
function isWebResponse(data) {
  return typeof Response !== "undefined" && data instanceof Response;
}
function sendStream(event, stream) {
  if (!stream || typeof stream !== "object") {
    throw new Error("[h3] Invalid stream provided.");
  }
  event.node.res._data = stream;
  if (!event.node.res.socket) {
    event._handled = true;
    return Promise.resolve();
  }
  if (hasProp(stream, "pipeTo") && typeof stream.pipeTo === "function") {
    return stream.pipeTo(
      new WritableStream({
        write(chunk) {
          event.node.res.write(chunk);
        }
      })
    ).then(() => {
      event.node.res.end();
    });
  }
  if (hasProp(stream, "pipe") && typeof stream.pipe === "function") {
    return new Promise((resolve, reject) => {
      stream.pipe(event.node.res);
      if (stream.on) {
        stream.on("end", () => {
          event.node.res.end();
          resolve();
        });
        stream.on("error", (error) => {
          reject(error);
        });
      }
      event.node.res.on("close", () => {
        if (stream.abort) {
          stream.abort();
        }
      });
    });
  }
  throw new Error("[h3] Invalid or incompatible stream provided.");
}
function sendWebResponse(event, response) {
  for (const [key, value] of response.headers) {
    if (key === "set-cookie") {
      event.node.res.appendHeader(key, splitCookiesString(value));
    } else {
      event.node.res.setHeader(key, value);
    }
  }
  if (response.status) {
    event.node.res.statusCode = sanitizeStatusCode(
      response.status,
      event.node.res.statusCode
    );
  }
  if (response.statusText) {
    event.node.res.statusMessage = sanitizeStatusMessage(response.statusText);
  }
  if (response.redirected) {
    event.node.res.setHeader("location", response.url);
  }
  if (!response.body) {
    event.node.res.end();
    return;
  }
  return sendStream(event, response.body);
}

const PayloadMethods = /* @__PURE__ */ new Set(["PATCH", "POST", "PUT", "DELETE"]);
const ignoredHeaders = /* @__PURE__ */ new Set([
  "transfer-encoding",
  "accept-encoding",
  "connection",
  "keep-alive",
  "upgrade",
  "expect",
  "host",
  "accept"
]);
async function proxyRequest(event, target, opts = {}) {
  let body;
  let duplex;
  if (PayloadMethods.has(event.method)) {
    if (opts.streamRequest) {
      body = getRequestWebStream(event);
      duplex = "half";
    } else {
      body = await readRawBody(event, false).catch(() => void 0);
    }
  }
  const method = opts.fetchOptions?.method || event.method;
  const fetchHeaders = mergeHeaders$1(
    getProxyRequestHeaders(event, { host: target.startsWith("/") }),
    opts.fetchOptions?.headers,
    opts.headers
  );
  return sendProxy(event, target, {
    ...opts,
    fetchOptions: {
      method,
      body,
      duplex,
      ...opts.fetchOptions,
      headers: fetchHeaders
    }
  });
}
async function sendProxy(event, target, opts = {}) {
  let response;
  try {
    response = await _getFetch(opts.fetch)(target, {
      headers: opts.headers,
      ignoreResponseError: true,
      // make $ofetch.raw transparent
      ...opts.fetchOptions
    });
  } catch (error) {
    throw createError$1({
      status: 502,
      statusMessage: "Bad Gateway",
      cause: error
    });
  }
  event.node.res.statusCode = sanitizeStatusCode(
    response.status,
    event.node.res.statusCode
  );
  event.node.res.statusMessage = sanitizeStatusMessage(response.statusText);
  const cookies = [];
  for (const [key, value] of response.headers.entries()) {
    if (key === "content-encoding") {
      continue;
    }
    if (key === "content-length") {
      continue;
    }
    if (key === "set-cookie") {
      cookies.push(...splitCookiesString(value));
      continue;
    }
    event.node.res.setHeader(key, value);
  }
  if (cookies.length > 0) {
    event.node.res.setHeader(
      "set-cookie",
      cookies.map((cookie) => {
        if (opts.cookieDomainRewrite) {
          cookie = rewriteCookieProperty(
            cookie,
            opts.cookieDomainRewrite,
            "domain"
          );
        }
        if (opts.cookiePathRewrite) {
          cookie = rewriteCookieProperty(
            cookie,
            opts.cookiePathRewrite,
            "path"
          );
        }
        return cookie;
      })
    );
  }
  if (opts.onResponse) {
    await opts.onResponse(event, response);
  }
  if (response._data !== void 0) {
    return response._data;
  }
  if (event.handled) {
    return;
  }
  if (opts.sendStream === false) {
    const data = new Uint8Array(await response.arrayBuffer());
    return event.node.res.end(data);
  }
  if (response.body) {
    for await (const chunk of response.body) {
      event.node.res.write(chunk);
    }
  }
  return event.node.res.end();
}
function getProxyRequestHeaders(event, opts) {
  const headers = /* @__PURE__ */ Object.create(null);
  const reqHeaders = getRequestHeaders(event);
  for (const name in reqHeaders) {
    if (!ignoredHeaders.has(name) || name === "host" && opts?.host) {
      headers[name] = reqHeaders[name];
    }
  }
  return headers;
}
function fetchWithEvent(event, req, init, options) {
  return _getFetch(options?.fetch)(req, {
    ...init,
    context: init?.context || event.context,
    headers: {
      ...getProxyRequestHeaders(event, {
        host: typeof req === "string" && req.startsWith("/")
      }),
      ...init?.headers
    }
  });
}
function _getFetch(_fetch) {
  if (_fetch) {
    return _fetch;
  }
  if (globalThis.fetch) {
    return globalThis.fetch;
  }
  throw new Error(
    "fetch is not available. Try importing `node-fetch-native/polyfill` for Node.js."
  );
}
function rewriteCookieProperty(header, map, property) {
  const _map = typeof map === "string" ? { "*": map } : map;
  return header.replace(
    new RegExp(`(;\\s*${property}=)([^;]+)`, "gi"),
    (match, prefix, previousValue) => {
      let newValue;
      if (previousValue in _map) {
        newValue = _map[previousValue];
      } else if ("*" in _map) {
        newValue = _map["*"];
      } else {
        return match;
      }
      return newValue ? prefix + newValue : "";
    }
  );
}
function mergeHeaders$1(defaults, ...inputs) {
  const _inputs = inputs.filter(Boolean);
  if (_inputs.length === 0) {
    return defaults;
  }
  const merged = new Headers(defaults);
  for (const input of _inputs) {
    const entries = Array.isArray(input) ? input : typeof input.entries === "function" ? input.entries() : Object.entries(input);
    for (const [key, value] of entries) {
      if (value !== void 0) {
        merged.set(key, value);
      }
    }
  }
  return merged;
}

function formatEventStreamMessage(message) {
  let result = "";
  if (message.id) {
    result += `id: ${_sanitizeSingleLine(message.id)}
`;
  }
  if (message.event) {
    result += `event: ${_sanitizeSingleLine(message.event)}
`;
  }
  if (typeof message.retry === "number" && Number.isInteger(message.retry)) {
    result += `retry: ${message.retry}
`;
  }
  const data = typeof message.data === "string" ? message.data : "";
  for (const line of data.split(/\r\n|\r|\n/)) {
    result += `data: ${line}
`;
  }
  result += "\n";
  return result;
}
function _sanitizeSingleLine(value) {
  return value.replace(/[\n\r]/g, "");
}
function formatEventStreamMessages(messages) {
  let result = "";
  for (const msg of messages) {
    result += formatEventStreamMessage(msg);
  }
  return result;
}
function setEventStreamHeaders(event) {
  const headers = {
    "Content-Type": "text/event-stream",
    "Cache-Control": "private, no-cache, no-store, no-transform, must-revalidate, max-age=0",
    "X-Accel-Buffering": "no"
    // prevent nginx from buffering the response
  };
  if (!isHttp2Request(event)) {
    headers.Connection = "keep-alive";
  }
  setResponseHeaders(event, headers);
}
function isHttp2Request(event) {
  return getHeader(event, ":path") !== void 0 && getHeader(event, ":method") !== void 0;
}

class EventStream {
  _h3Event;
  _transformStream = new TransformStream();
  _writer;
  _encoder = new TextEncoder();
  _writerIsClosed = false;
  _paused = false;
  _unsentData;
  _disposed = false;
  _handled = false;
  constructor(event, opts = {}) {
    this._h3Event = event;
    this._writer = this._transformStream.writable.getWriter();
    this._writer.closed.then(() => {
      this._writerIsClosed = true;
    });
    if (opts.autoclose !== false) {
      this._h3Event.node.req.on("close", () => this.close());
    }
  }
  async push(message) {
    if (typeof message === "string") {
      await this._sendEvent({ data: message });
      return;
    }
    if (Array.isArray(message)) {
      if (message.length === 0) {
        return;
      }
      if (typeof message[0] === "string") {
        const msgs = [];
        for (const item of message) {
          msgs.push({ data: item });
        }
        await this._sendEvents(msgs);
        return;
      }
      await this._sendEvents(message);
      return;
    }
    await this._sendEvent(message);
  }
  async _sendEvent(message) {
    if (this._writerIsClosed) {
      return;
    }
    if (this._paused && !this._unsentData) {
      this._unsentData = formatEventStreamMessage(message);
      return;
    }
    if (this._paused) {
      this._unsentData += formatEventStreamMessage(message);
      return;
    }
    await this._writer.write(this._encoder.encode(formatEventStreamMessage(message))).catch();
  }
  async _sendEvents(messages) {
    if (this._writerIsClosed) {
      return;
    }
    const payload = formatEventStreamMessages(messages);
    if (this._paused && !this._unsentData) {
      this._unsentData = payload;
      return;
    }
    if (this._paused) {
      this._unsentData += payload;
      return;
    }
    await this._writer.write(this._encoder.encode(payload)).catch();
  }
  pause() {
    this._paused = true;
  }
  get isPaused() {
    return this._paused;
  }
  async resume() {
    this._paused = false;
    await this.flush();
  }
  async flush() {
    if (this._writerIsClosed) {
      return;
    }
    if (this._unsentData?.length) {
      await this._writer.write(this._encoder.encode(this._unsentData));
      this._unsentData = void 0;
    }
  }
  /**
   * Close the stream and the connection if the stream is being sent to the client
   */
  async close() {
    if (this._disposed) {
      return;
    }
    if (!this._writerIsClosed) {
      try {
        await this._writer.close();
      } catch {
      }
    }
    if (this._h3Event._handled && this._handled && !this._h3Event.node.res.closed) {
      this._h3Event.node.res.end();
    }
    this._disposed = true;
  }
  /**
   * Triggers callback when the writable stream is closed.
   * It is also triggered after calling the `close()` method.
   */
  onClosed(cb) {
    this._writer.closed.then(cb);
  }
  async send() {
    setEventStreamHeaders(this._h3Event);
    setResponseStatus(this._h3Event, 200);
    this._h3Event._handled = true;
    this._handled = true;
    await sendStream(this._h3Event, this._transformStream.readable);
  }
}

function createEventStream(event, opts) {
  return new EventStream(event, opts);
}

class H3Event {
  "__is_event__" = true;
  // Context
  node;
  // Node
  web;
  // Web
  context = {};
  // Shared
  // Request
  _method;
  _path;
  _headers;
  _requestBody;
  // Response
  _handled = false;
  // Hooks
  _onBeforeResponseCalled;
  _onAfterResponseCalled;
  constructor(req, res) {
    this.node = { req, res };
  }
  // --- Request ---
  get method() {
    if (!this._method) {
      this._method = (this.node.req.method || "GET").toUpperCase();
    }
    return this._method;
  }
  get path() {
    return this._path || this.node.req.url || "/";
  }
  get headers() {
    if (!this._headers) {
      this._headers = _normalizeNodeHeaders(this.node.req.headers);
    }
    return this._headers;
  }
  // --- Respoonse ---
  get handled() {
    return this._handled || this.node.res.writableEnded || this.node.res.headersSent;
  }
  respondWith(response) {
    return Promise.resolve(response).then(
      (_response) => sendWebResponse(this, _response)
    );
  }
  // --- Utils ---
  toString() {
    return `[${this.method}] ${this.path}`;
  }
  toJSON() {
    return this.toString();
  }
  // --- Deprecated ---
  /** @deprecated Please use `event.node.req` instead. */
  get req() {
    return this.node.req;
  }
  /** @deprecated Please use `event.node.res` instead. */
  get res() {
    return this.node.res;
  }
}
function isEvent(input) {
  return hasProp(input, "__is_event__");
}
function createEvent(req, res) {
  return new H3Event(req, res);
}
function _normalizeNodeHeaders(nodeHeaders) {
  const headers = new Headers();
  for (const [name, value] of Object.entries(nodeHeaders)) {
    if (Array.isArray(value)) {
      for (const item of value) {
        headers.append(name, item);
      }
    } else if (value) {
      headers.set(name, value);
    }
  }
  return headers;
}

function defineEventHandler(handler) {
  if (typeof handler === "function") {
    handler.__is_handler__ = true;
    return handler;
  }
  const _hooks = {
    onRequest: _normalizeArray(handler.onRequest),
    onBeforeResponse: _normalizeArray(handler.onBeforeResponse)
  };
  const _handler = (event) => {
    return _callHandler(event, handler.handler, _hooks);
  };
  _handler.__is_handler__ = true;
  _handler.__resolve__ = handler.handler.__resolve__;
  _handler.__websocket__ = handler.websocket;
  return _handler;
}
function _normalizeArray(input) {
  return input ? Array.isArray(input) ? input : [input] : void 0;
}
async function _callHandler(event, handler, hooks) {
  if (hooks.onRequest) {
    for (const hook of hooks.onRequest) {
      await hook(event);
      if (event.handled) {
        return;
      }
    }
  }
  const body = await handler(event);
  const response = { body };
  if (hooks.onBeforeResponse) {
    for (const hook of hooks.onBeforeResponse) {
      await hook(event, response);
    }
  }
  return response.body;
}
const eventHandler = defineEventHandler;
function isEventHandler(input) {
  return hasProp(input, "__is_handler__");
}
function toEventHandler(input, _, _route) {
  return input;
}
function defineLazyEventHandler(factory) {
  let _promise;
  let _resolved;
  const resolveHandler = () => {
    if (_resolved) {
      return Promise.resolve(_resolved);
    }
    if (!_promise) {
      _promise = Promise.resolve(factory()).then((r) => {
        const handler2 = r.default || r;
        if (typeof handler2 !== "function") {
          throw new TypeError(
            "Invalid lazy handler result. It should be a function:",
            handler2
          );
        }
        _resolved = { handler: toEventHandler(r.default || r) };
        return _resolved;
      });
    }
    return _promise;
  };
  const handler = eventHandler((event) => {
    if (_resolved) {
      return _resolved.handler(event);
    }
    return resolveHandler().then((r) => r.handler(event));
  });
  handler.__resolve__ = resolveHandler;
  return handler;
}
const lazyEventHandler = defineLazyEventHandler;

function createApp(options = {}) {
  const stack = [];
  const handler = createAppEventHandler(stack, options);
  const resolve = createResolver(stack);
  handler.__resolve__ = resolve;
  const getWebsocket = cachedFn(() => websocketOptions(resolve, options));
  const app = {
    // @ts-expect-error
    use: (arg1, arg2, arg3) => use(app, arg1, arg2, arg3),
    resolve,
    handler,
    stack,
    options,
    get websocket() {
      return getWebsocket();
    }
  };
  return app;
}
function use(app, arg1, arg2, arg3) {
  if (Array.isArray(arg1)) {
    for (const i of arg1) {
      use(app, i, arg2, arg3);
    }
  } else if (Array.isArray(arg2)) {
    for (const i of arg2) {
      use(app, arg1, i, arg3);
    }
  } else if (typeof arg1 === "string") {
    app.stack.push(
      normalizeLayer({ ...arg3, route: arg1, handler: arg2 })
    );
  } else if (typeof arg1 === "function") {
    app.stack.push(normalizeLayer({ ...arg2, handler: arg1 }));
  } else {
    app.stack.push(normalizeLayer({ ...arg1 }));
  }
  return app;
}
function createAppEventHandler(stack, options) {
  const spacing = options.debug ? 2 : void 0;
  return eventHandler(async (event) => {
    event.node.req.originalUrl = event.node.req.originalUrl || event.node.req.url || "/";
    const _rawReqUrl = event.node.req.url || "/";
    const _reqPath = _decodePath(event._path || _rawReqUrl);
    event._path = _reqPath;
    const _needsRawUrl = _reqPath !== _rawReqUrl;
    let _layerPath;
    if (options.onRequest) {
      await options.onRequest(event);
    }
    for (const layer of stack) {
      if (layer.route.length > 1) {
        if (!_reqPath.startsWith(layer.route)) {
          continue;
        }
        _layerPath = _reqPath.slice(layer.route.length) || "/";
      } else {
        _layerPath = _reqPath;
      }
      if (layer.match && !layer.match(_layerPath, event)) {
        continue;
      }
      event._path = _layerPath;
      event.node.req.url = _needsRawUrl ? layer.route.length > 1 ? _rawReqUrl.slice(layer.route.length) || "/" : _rawReqUrl : _layerPath;
      const val = await layer.handler(event);
      const _body = val === void 0 ? void 0 : await val;
      if (_body !== void 0) {
        const _response = { body: _body };
        if (options.onBeforeResponse) {
          event._onBeforeResponseCalled = true;
          await options.onBeforeResponse(event, _response);
        }
        await handleHandlerResponse(event, _response.body, spacing);
        if (options.onAfterResponse) {
          event._onAfterResponseCalled = true;
          await options.onAfterResponse(event, _response);
        }
        return;
      }
      if (event.handled) {
        if (options.onAfterResponse) {
          event._onAfterResponseCalled = true;
          await options.onAfterResponse(event, void 0);
        }
        return;
      }
    }
    if (!event.handled) {
      throw createError$1({
        statusCode: 404,
        statusMessage: `Cannot find any path matching ${event.path || "/"}.`
      });
    }
    if (options.onAfterResponse) {
      event._onAfterResponseCalled = true;
      await options.onAfterResponse(event, void 0);
    }
  });
}
function createResolver(stack) {
  return async (path) => {
    let _layerPath;
    for (const layer of stack) {
      if (layer.route === "/" && !layer.handler.__resolve__) {
        continue;
      }
      if (!path.startsWith(layer.route)) {
        continue;
      }
      _layerPath = path.slice(layer.route.length) || "/";
      if (layer.match && !layer.match(_layerPath, void 0)) {
        continue;
      }
      let res = { route: layer.route, handler: layer.handler };
      if (res.handler.__resolve__) {
        const _res = await res.handler.__resolve__(_layerPath);
        if (!_res) {
          continue;
        }
        res = {
          ...res,
          ..._res,
          route: joinURL(res.route || "/", _res.route || "/")
        };
      }
      return res;
    }
  };
}
function normalizeLayer(input) {
  let handler = input.handler;
  if (handler.handler) {
    handler = handler.handler;
  }
  if (input.lazy) {
    handler = lazyEventHandler(handler);
  } else if (!isEventHandler(handler)) {
    handler = toEventHandler(handler, void 0, input.route);
  }
  return {
    route: withoutTrailingSlash(input.route),
    match: input.match,
    handler
  };
}
function handleHandlerResponse(event, val, jsonSpace) {
  if (val === null) {
    return sendNoContent(event);
  }
  if (val) {
    if (isWebResponse(val)) {
      return sendWebResponse(event, val);
    }
    if (isStream(val)) {
      return sendStream(event, val);
    }
    if (val.buffer) {
      return send(event, val);
    }
    if (val.arrayBuffer && typeof val.arrayBuffer === "function") {
      return val.arrayBuffer().then((arrayBuffer) => {
        return send(event, Buffer.from(arrayBuffer), val.type);
      });
    }
    if (val instanceof Error) {
      throw createError$1(val);
    }
    if (typeof val.end === "function") {
      return true;
    }
  }
  const valType = typeof val;
  if (valType === "string") {
    return send(event, val, MIMES.html);
  }
  if (valType === "object" || valType === "boolean" || valType === "number") {
    return send(event, JSON.stringify(val, void 0, jsonSpace), MIMES.json);
  }
  if (valType === "bigint") {
    return send(event, val.toString(), MIMES.json);
  }
  throw createError$1({
    statusCode: 500,
    statusMessage: `[h3] Cannot send ${valType} as response.`
  });
}
function cachedFn(fn) {
  let cache;
  return () => {
    if (!cache) {
      cache = fn();
    }
    return cache;
  };
}
function _decodePath(url) {
  const qIndex = url.indexOf("?");
  const path = qIndex === -1 ? url : url.slice(0, qIndex);
  const query = qIndex === -1 ? "" : url.slice(qIndex);
  const decodedPath = path.includes("%25") ? decodePath(path.replace(/%25/g, "%2525")) : decodePath(path);
  return decodedPath + query;
}
function websocketOptions(evResolver, appOptions) {
  return {
    ...appOptions.websocket,
    async resolve(info) {
      const url = info.request?.url || info.url || "/";
      const { pathname } = typeof url === "string" ? parseURL(url) : url;
      const resolved = await evResolver(pathname);
      return resolved?.handler?.__websocket__ || {};
    }
  };
}

const RouterMethods = [
  "connect",
  "delete",
  "get",
  "head",
  "options",
  "post",
  "put",
  "trace",
  "patch"
];
function createRouter(opts = {}) {
  const _router = createRouter$1({});
  const routes = {};
  let _matcher;
  const router = {};
  const addRoute = (path, handler, method) => {
    let route = routes[path];
    if (!route) {
      routes[path] = route = { path, handlers: {} };
      _router.insert(path, route);
    }
    if (Array.isArray(method)) {
      for (const m of method) {
        addRoute(path, handler, m);
      }
    } else {
      route.handlers[method] = toEventHandler(handler);
    }
    return router;
  };
  router.use = router.add = (path, handler, method) => addRoute(path, handler, method || "all");
  for (const method of RouterMethods) {
    router[method] = (path, handle) => router.add(path, handle, method);
  }
  const matchHandler = (path = "/", method = "get") => {
    const qIndex = path.indexOf("?");
    if (qIndex !== -1) {
      path = path.slice(0, Math.max(0, qIndex));
    }
    const matched = _router.lookup(path);
    if (!matched || !matched.handlers) {
      return {
        error: createError$1({
          statusCode: 404,
          name: "Not Found",
          statusMessage: `Cannot find any route matching ${path || "/"}.`
        })
      };
    }
    let handler = matched.handlers[method] || matched.handlers.all;
    if (!handler) {
      if (!_matcher) {
        _matcher = toRouteMatcher(_router);
      }
      const _matches = _matcher.matchAll(path).reverse();
      for (const _match of _matches) {
        if (_match.handlers[method]) {
          handler = _match.handlers[method];
          matched.handlers[method] = matched.handlers[method] || handler;
          break;
        }
        if (_match.handlers.all) {
          handler = _match.handlers.all;
          matched.handlers.all = matched.handlers.all || handler;
          break;
        }
      }
    }
    if (!handler) {
      return {
        error: createError$1({
          statusCode: 405,
          name: "Method Not Allowed",
          statusMessage: `Method ${method} is not allowed on this route.`
        })
      };
    }
    return { matched, handler };
  };
  const isPreemptive = opts.preemptive || opts.preemtive;
  router.handler = eventHandler((event) => {
    const match = matchHandler(
      event.path,
      event.method.toLowerCase()
    );
    if ("error" in match) {
      if (isPreemptive) {
        throw match.error;
      } else {
        return;
      }
    }
    event.context.matchedRoute = match.matched;
    const params = match.matched.params || {};
    event.context.params = params;
    return Promise.resolve(match.handler(event)).then((res) => {
      if (res === void 0 && isPreemptive) {
        return null;
      }
      return res;
    });
  });
  router.handler.__resolve__ = async (path) => {
    path = withLeadingSlash(path);
    const match = matchHandler(path);
    if ("error" in match) {
      return;
    }
    let res = {
      route: match.matched.path,
      handler: match.handler
    };
    if (match.handler.__resolve__) {
      const _res = await match.handler.__resolve__(path);
      if (!_res) {
        return;
      }
      res = { ...res, ..._res };
    }
    return res;
  };
  return router;
}
function toNodeListener(app) {
  const toNodeHandle = async function(req, res) {
    const event = createEvent(req, res);
    try {
      await app.handler(event);
    } catch (_error) {
      const error = createError$1(_error);
      if (!isError(_error)) {
        error.unhandled = true;
      }
      setResponseStatus(event, error.statusCode, error.statusMessage);
      if (app.options.onError) {
        await app.options.onError(error, event);
      }
      if (event.handled) {
        return;
      }
      if (error.unhandled || error.fatal) {
        console.error("[h3]", error.fatal ? "[fatal]" : "[unhandled]", error);
      }
      if (app.options.onBeforeResponse && !event._onBeforeResponseCalled) {
        await app.options.onBeforeResponse(event, { body: error });
      }
      await sendError(event, error, !!app.options.debug);
      if (app.options.onAfterResponse && !event._onAfterResponseCalled) {
        await app.options.onAfterResponse(event, { body: error });
      }
    }
  };
  return toNodeHandle;
}

function flatHooks(configHooks, hooks = {}, parentName) {
  for (const key in configHooks) {
    const subHook = configHooks[key];
    const name = parentName ? `${parentName}:${key}` : key;
    if (typeof subHook === "object" && subHook !== null) {
      flatHooks(subHook, hooks, name);
    } else if (typeof subHook === "function") {
      hooks[name] = subHook;
    }
  }
  return hooks;
}
const defaultTask = { run: (function_) => function_() };
const _createTask = () => defaultTask;
const createTask = typeof console.createTask !== "undefined" ? console.createTask : _createTask;
function serialTaskCaller(hooks, args) {
  const name = args.shift();
  const task = createTask(name);
  return hooks.reduce(
    (promise, hookFunction) => promise.then(() => task.run(() => hookFunction(...args))),
    Promise.resolve()
  );
}
function parallelTaskCaller(hooks, args) {
  const name = args.shift();
  const task = createTask(name);
  return Promise.all(hooks.map((hook) => task.run(() => hook(...args))));
}
function callEachWith(callbacks, arg0) {
  for (const callback of [...callbacks]) {
    callback(arg0);
  }
}

class Hookable {
  constructor() {
    this._hooks = {};
    this._before = void 0;
    this._after = void 0;
    this._deprecatedMessages = void 0;
    this._deprecatedHooks = {};
    this.hook = this.hook.bind(this);
    this.callHook = this.callHook.bind(this);
    this.callHookWith = this.callHookWith.bind(this);
  }
  hook(name, function_, options = {}) {
    if (!name || typeof function_ !== "function") {
      return () => {
      };
    }
    const originalName = name;
    let dep;
    while (this._deprecatedHooks[name]) {
      dep = this._deprecatedHooks[name];
      name = dep.to;
    }
    if (dep && !options.allowDeprecated) {
      let message = dep.message;
      if (!message) {
        message = `${originalName} hook has been deprecated` + (dep.to ? `, please use ${dep.to}` : "");
      }
      if (!this._deprecatedMessages) {
        this._deprecatedMessages = /* @__PURE__ */ new Set();
      }
      if (!this._deprecatedMessages.has(message)) {
        console.warn(message);
        this._deprecatedMessages.add(message);
      }
    }
    if (!function_.name) {
      try {
        Object.defineProperty(function_, "name", {
          get: () => "_" + name.replace(/\W+/g, "_") + "_hook_cb",
          configurable: true
        });
      } catch {
      }
    }
    this._hooks[name] = this._hooks[name] || [];
    this._hooks[name].push(function_);
    return () => {
      if (function_) {
        this.removeHook(name, function_);
        function_ = void 0;
      }
    };
  }
  hookOnce(name, function_) {
    let _unreg;
    let _function = (...arguments_) => {
      if (typeof _unreg === "function") {
        _unreg();
      }
      _unreg = void 0;
      _function = void 0;
      return function_(...arguments_);
    };
    _unreg = this.hook(name, _function);
    return _unreg;
  }
  removeHook(name, function_) {
    if (this._hooks[name]) {
      const index = this._hooks[name].indexOf(function_);
      if (index !== -1) {
        this._hooks[name].splice(index, 1);
      }
      if (this._hooks[name].length === 0) {
        delete this._hooks[name];
      }
    }
  }
  deprecateHook(name, deprecated) {
    this._deprecatedHooks[name] = typeof deprecated === "string" ? { to: deprecated } : deprecated;
    const _hooks = this._hooks[name] || [];
    delete this._hooks[name];
    for (const hook of _hooks) {
      this.hook(name, hook);
    }
  }
  deprecateHooks(deprecatedHooks) {
    Object.assign(this._deprecatedHooks, deprecatedHooks);
    for (const name in deprecatedHooks) {
      this.deprecateHook(name, deprecatedHooks[name]);
    }
  }
  addHooks(configHooks) {
    const hooks = flatHooks(configHooks);
    const removeFns = Object.keys(hooks).map(
      (key) => this.hook(key, hooks[key])
    );
    return () => {
      for (const unreg of removeFns.splice(0, removeFns.length)) {
        unreg();
      }
    };
  }
  removeHooks(configHooks) {
    const hooks = flatHooks(configHooks);
    for (const key in hooks) {
      this.removeHook(key, hooks[key]);
    }
  }
  removeAllHooks() {
    for (const key in this._hooks) {
      delete this._hooks[key];
    }
  }
  callHook(name, ...arguments_) {
    arguments_.unshift(name);
    return this.callHookWith(serialTaskCaller, name, ...arguments_);
  }
  callHookParallel(name, ...arguments_) {
    arguments_.unshift(name);
    return this.callHookWith(parallelTaskCaller, name, ...arguments_);
  }
  callHookWith(caller, name, ...arguments_) {
    const event = this._before || this._after ? { name, args: arguments_, context: {} } : void 0;
    if (this._before) {
      callEachWith(this._before, event);
    }
    const result = caller(
      name in this._hooks ? [...this._hooks[name]] : [],
      arguments_
    );
    if (result instanceof Promise) {
      return result.finally(() => {
        if (this._after && event) {
          callEachWith(this._after, event);
        }
      });
    }
    if (this._after && event) {
      callEachWith(this._after, event);
    }
    return result;
  }
  beforeEach(function_) {
    this._before = this._before || [];
    this._before.push(function_);
    return () => {
      if (this._before !== void 0) {
        const index = this._before.indexOf(function_);
        if (index !== -1) {
          this._before.splice(index, 1);
        }
      }
    };
  }
  afterEach(function_) {
    this._after = this._after || [];
    this._after.push(function_);
    return () => {
      if (this._after !== void 0) {
        const index = this._after.indexOf(function_);
        if (index !== -1) {
          this._after.splice(index, 1);
        }
      }
    };
  }
}
function createHooks() {
  return new Hookable();
}

const s$1=globalThis.Headers,i=globalThis.AbortController,l=globalThis.fetch||(()=>{throw new Error("[node-fetch-native] Failed to fetch: `globalThis.fetch` is not available!")});

class FetchError extends Error {
  constructor(message, opts) {
    super(message, opts);
    this.name = "FetchError";
    if (opts?.cause && !this.cause) {
      this.cause = opts.cause;
    }
  }
}
function createFetchError(ctx) {
  const errorMessage = ctx.error?.message || ctx.error?.toString() || "";
  const method = ctx.request?.method || ctx.options?.method || "GET";
  const url = ctx.request?.url || String(ctx.request) || "/";
  const requestStr = `[${method}] ${JSON.stringify(url)}`;
  const statusStr = ctx.response ? `${ctx.response.status} ${ctx.response.statusText}` : "<no response>";
  const message = `${requestStr}: ${statusStr}${errorMessage ? ` ${errorMessage}` : ""}`;
  const fetchError = new FetchError(
    message,
    ctx.error ? { cause: ctx.error } : void 0
  );
  for (const key of ["request", "options", "response"]) {
    Object.defineProperty(fetchError, key, {
      get() {
        return ctx[key];
      }
    });
  }
  for (const [key, refKey] of [
    ["data", "_data"],
    ["status", "status"],
    ["statusCode", "status"],
    ["statusText", "statusText"],
    ["statusMessage", "statusText"]
  ]) {
    Object.defineProperty(fetchError, key, {
      get() {
        return ctx.response && ctx.response[refKey];
      }
    });
  }
  return fetchError;
}

const payloadMethods = new Set(
  Object.freeze(["PATCH", "POST", "PUT", "DELETE"])
);
function isPayloadMethod(method = "GET") {
  return payloadMethods.has(method.toUpperCase());
}
function isJSONSerializable(value) {
  if (value === void 0) {
    return false;
  }
  const t = typeof value;
  if (t === "string" || t === "number" || t === "boolean" || t === null) {
    return true;
  }
  if (t !== "object") {
    return false;
  }
  if (Array.isArray(value)) {
    return true;
  }
  if (value.buffer) {
    return false;
  }
  if (value instanceof FormData || value instanceof URLSearchParams) {
    return false;
  }
  return value.constructor && value.constructor.name === "Object" || typeof value.toJSON === "function";
}
const textTypes = /* @__PURE__ */ new Set([
  "image/svg",
  "application/xml",
  "application/xhtml",
  "application/html"
]);
const JSON_RE = /^application\/(?:[\w!#$%&*.^`~-]*\+)?json(;.+)?$/i;
function detectResponseType(_contentType = "") {
  if (!_contentType) {
    return "json";
  }
  const contentType = _contentType.split(";").shift() || "";
  if (JSON_RE.test(contentType)) {
    return "json";
  }
  if (contentType === "text/event-stream") {
    return "stream";
  }
  if (textTypes.has(contentType) || contentType.startsWith("text/")) {
    return "text";
  }
  return "blob";
}
function resolveFetchOptions(request, input, defaults, Headers) {
  const headers = mergeHeaders(
    input?.headers ?? request?.headers,
    defaults?.headers,
    Headers
  );
  let query;
  if (defaults?.query || defaults?.params || input?.params || input?.query) {
    query = {
      ...defaults?.params,
      ...defaults?.query,
      ...input?.params,
      ...input?.query
    };
  }
  return {
    ...defaults,
    ...input,
    query,
    params: query,
    headers
  };
}
function mergeHeaders(input, defaults, Headers) {
  if (!defaults) {
    return new Headers(input);
  }
  const headers = new Headers(defaults);
  if (input) {
    for (const [key, value] of Symbol.iterator in input || Array.isArray(input) ? input : new Headers(input)) {
      headers.set(key, value);
    }
  }
  return headers;
}
async function callHooks(context, hooks) {
  if (hooks) {
    if (Array.isArray(hooks)) {
      for (const hook of hooks) {
        await hook(context);
      }
    } else {
      await hooks(context);
    }
  }
}

const retryStatusCodes = /* @__PURE__ */ new Set([
  408,
  // Request Timeout
  409,
  // Conflict
  425,
  // Too Early (Experimental)
  429,
  // Too Many Requests
  500,
  // Internal Server Error
  502,
  // Bad Gateway
  503,
  // Service Unavailable
  504
  // Gateway Timeout
]);
const nullBodyResponses = /* @__PURE__ */ new Set([101, 204, 205, 304]);
function createFetch(globalOptions = {}) {
  const {
    fetch = globalThis.fetch,
    Headers = globalThis.Headers,
    AbortController = globalThis.AbortController
  } = globalOptions;
  async function onError(context) {
    const isAbort = context.error && context.error.name === "AbortError" && !context.options.timeout || false;
    if (context.options.retry !== false && !isAbort) {
      let retries;
      if (typeof context.options.retry === "number") {
        retries = context.options.retry;
      } else {
        retries = isPayloadMethod(context.options.method) ? 0 : 1;
      }
      const responseCode = context.response && context.response.status || 500;
      if (retries > 0 && (Array.isArray(context.options.retryStatusCodes) ? context.options.retryStatusCodes.includes(responseCode) : retryStatusCodes.has(responseCode))) {
        const retryDelay = typeof context.options.retryDelay === "function" ? context.options.retryDelay(context) : context.options.retryDelay || 0;
        if (retryDelay > 0) {
          await new Promise((resolve) => setTimeout(resolve, retryDelay));
        }
        return $fetchRaw(context.request, {
          ...context.options,
          retry: retries - 1
        });
      }
    }
    const error = createFetchError(context);
    if (Error.captureStackTrace) {
      Error.captureStackTrace(error, $fetchRaw);
    }
    throw error;
  }
  const $fetchRaw = async function $fetchRaw2(_request, _options = {}) {
    const context = {
      request: _request,
      options: resolveFetchOptions(
        _request,
        _options,
        globalOptions.defaults,
        Headers
      ),
      response: void 0,
      error: void 0
    };
    if (context.options.method) {
      context.options.method = context.options.method.toUpperCase();
    }
    if (context.options.onRequest) {
      await callHooks(context, context.options.onRequest);
      if (!(context.options.headers instanceof Headers)) {
        context.options.headers = new Headers(
          context.options.headers || {}
          /* compat */
        );
      }
    }
    if (typeof context.request === "string") {
      if (context.options.baseURL) {
        context.request = withBase(context.request, context.options.baseURL);
      }
      if (context.options.query) {
        context.request = withQuery(context.request, context.options.query);
        delete context.options.query;
      }
      if ("query" in context.options) {
        delete context.options.query;
      }
      if ("params" in context.options) {
        delete context.options.params;
      }
    }
    if (context.options.body && isPayloadMethod(context.options.method)) {
      if (isJSONSerializable(context.options.body)) {
        const contentType = context.options.headers.get("content-type");
        if (typeof context.options.body !== "string") {
          context.options.body = contentType === "application/x-www-form-urlencoded" ? new URLSearchParams(
            context.options.body
          ).toString() : JSON.stringify(context.options.body);
        }
        if (!contentType) {
          context.options.headers.set("content-type", "application/json");
        }
        if (!context.options.headers.has("accept")) {
          context.options.headers.set("accept", "application/json");
        }
      } else if (
        // ReadableStream Body
        "pipeTo" in context.options.body && typeof context.options.body.pipeTo === "function" || // Node.js Stream Body
        typeof context.options.body.pipe === "function"
      ) {
        if (!("duplex" in context.options)) {
          context.options.duplex = "half";
        }
      }
    }
    let abortTimeout;
    if (!context.options.signal && context.options.timeout) {
      const controller = new AbortController();
      abortTimeout = setTimeout(() => {
        const error = new Error(
          "[TimeoutError]: The operation was aborted due to timeout"
        );
        error.name = "TimeoutError";
        error.code = 23;
        controller.abort(error);
      }, context.options.timeout);
      context.options.signal = controller.signal;
    }
    try {
      context.response = await fetch(
        context.request,
        context.options
      );
    } catch (error) {
      context.error = error;
      if (context.options.onRequestError) {
        await callHooks(
          context,
          context.options.onRequestError
        );
      }
      return await onError(context);
    } finally {
      if (abortTimeout) {
        clearTimeout(abortTimeout);
      }
    }
    const hasBody = (context.response.body || // https://github.com/unjs/ofetch/issues/324
    // https://github.com/unjs/ofetch/issues/294
    // https://github.com/JakeChampion/fetch/issues/1454
    context.response._bodyInit) && !nullBodyResponses.has(context.response.status) && context.options.method !== "HEAD";
    if (hasBody) {
      const responseType = (context.options.parseResponse ? "json" : context.options.responseType) || detectResponseType(context.response.headers.get("content-type") || "");
      switch (responseType) {
        case "json": {
          const data = await context.response.text();
          const parseFunction = context.options.parseResponse || destr;
          context.response._data = parseFunction(data);
          break;
        }
        case "stream": {
          context.response._data = context.response.body || context.response._bodyInit;
          break;
        }
        default: {
          context.response._data = await context.response[responseType]();
        }
      }
    }
    if (context.options.onResponse) {
      await callHooks(
        context,
        context.options.onResponse
      );
    }
    if (!context.options.ignoreResponseError && context.response.status >= 400 && context.response.status < 600) {
      if (context.options.onResponseError) {
        await callHooks(
          context,
          context.options.onResponseError
        );
      }
      return await onError(context);
    }
    return context.response;
  };
  const $fetch = async function $fetch2(request, options) {
    const r = await $fetchRaw(request, options);
    return r._data;
  };
  $fetch.raw = $fetchRaw;
  $fetch.native = (...args) => fetch(...args);
  $fetch.create = (defaultOptions = {}, customGlobalOptions = {}) => createFetch({
    ...globalOptions,
    ...customGlobalOptions,
    defaults: {
      ...globalOptions.defaults,
      ...customGlobalOptions.defaults,
      ...defaultOptions
    }
  });
  return $fetch;
}

function createNodeFetch() {
  const useKeepAlive = JSON.parse(process.env.FETCH_KEEP_ALIVE || "false");
  if (!useKeepAlive) {
    return l;
  }
  const agentOptions = { keepAlive: true };
  const httpAgent = new http.Agent(agentOptions);
  const httpsAgent = new https.Agent(agentOptions);
  const nodeFetchOptions = {
    agent(parsedURL) {
      return parsedURL.protocol === "http:" ? httpAgent : httpsAgent;
    }
  };
  return function nodeFetchWithKeepAlive(input, init) {
    return l(input, { ...nodeFetchOptions, ...init });
  };
}
const fetch$1 = globalThis.fetch ? (...args) => globalThis.fetch(...args) : createNodeFetch();
const Headers$1 = globalThis.Headers || s$1;
const AbortController = globalThis.AbortController || i;
const ofetch = createFetch({ fetch: fetch$1, Headers: Headers$1, AbortController });
const $fetch$1 = ofetch;

function wrapToPromise(value) {
  if (!value || typeof value.then !== "function") {
    return Promise.resolve(value);
  }
  return value;
}
function asyncCall(function_, ...arguments_) {
  try {
    return wrapToPromise(function_(...arguments_));
  } catch (error) {
    return Promise.reject(error);
  }
}
function isPrimitive(value) {
  const type = typeof value;
  return value === null || type !== "object" && type !== "function";
}
function isPureObject(value) {
  const proto = Object.getPrototypeOf(value);
  return !proto || proto.isPrototypeOf(Object);
}
function stringify(value) {
  if (isPrimitive(value)) {
    return String(value);
  }
  if (isPureObject(value) || Array.isArray(value)) {
    return JSON.stringify(value);
  }
  if (typeof value.toJSON === "function") {
    return stringify(value.toJSON());
  }
  throw new Error("[unstorage] Cannot stringify value!");
}
const BASE64_PREFIX = "base64:";
function serializeRaw(value) {
  if (typeof value === "string") {
    return value;
  }
  return BASE64_PREFIX + base64Encode(value);
}
function deserializeRaw(value) {
  if (typeof value !== "string") {
    return value;
  }
  if (!value.startsWith(BASE64_PREFIX)) {
    return value;
  }
  return base64Decode(value.slice(BASE64_PREFIX.length));
}
function base64Decode(input) {
  if (globalThis.Buffer) {
    return Buffer.from(input, "base64");
  }
  return Uint8Array.from(
    globalThis.atob(input),
    (c) => c.codePointAt(0)
  );
}
function base64Encode(input) {
  if (globalThis.Buffer) {
    return Buffer.from(input).toString("base64");
  }
  return globalThis.btoa(String.fromCodePoint(...input));
}

const storageKeyProperties = [
  "has",
  "hasItem",
  "get",
  "getItem",
  "getItemRaw",
  "set",
  "setItem",
  "setItemRaw",
  "del",
  "remove",
  "removeItem",
  "getMeta",
  "setMeta",
  "removeMeta",
  "getKeys",
  "clear",
  "mount",
  "unmount"
];
function prefixStorage(storage, base) {
  base = normalizeBaseKey(base);
  if (!base) {
    return storage;
  }
  const nsStorage = { ...storage };
  for (const property of storageKeyProperties) {
    nsStorage[property] = (key = "", ...args) => (
      // @ts-ignore
      storage[property](base + key, ...args)
    );
  }
  nsStorage.getKeys = (key = "", ...arguments_) => storage.getKeys(base + key, ...arguments_).then((keys) => keys.map((key2) => key2.slice(base.length)));
  nsStorage.keys = nsStorage.getKeys;
  nsStorage.getItems = async (items, commonOptions) => {
    const prefixedItems = items.map(
      (item) => typeof item === "string" ? base + item : { ...item, key: base + item.key }
    );
    const results = await storage.getItems(prefixedItems, commonOptions);
    return results.map((entry) => ({
      key: entry.key.slice(base.length),
      value: entry.value
    }));
  };
  nsStorage.setItems = async (items, commonOptions) => {
    const prefixedItems = items.map((item) => ({
      key: base + item.key,
      value: item.value,
      options: item.options
    }));
    return storage.setItems(prefixedItems, commonOptions);
  };
  return nsStorage;
}
function normalizeKey$1(key) {
  if (!key) {
    return "";
  }
  return key.split("?")[0]?.replace(/[/\\]/g, ":").replace(/:+/g, ":").replace(/^:|:$/g, "") || "";
}
function joinKeys(...keys) {
  return normalizeKey$1(keys.join(":"));
}
function normalizeBaseKey(base) {
  base = normalizeKey$1(base);
  return base ? base + ":" : "";
}
function filterKeyByDepth(key, depth) {
  if (depth === void 0) {
    return true;
  }
  let substrCount = 0;
  let index = key.indexOf(":");
  while (index > -1) {
    substrCount++;
    index = key.indexOf(":", index + 1);
  }
  return substrCount <= depth;
}
function filterKeyByBase(key, base) {
  if (base) {
    return key.startsWith(base) && key[key.length - 1] !== "$";
  }
  return key[key.length - 1] !== "$";
}

function defineDriver$1(factory) {
  return factory;
}

const DRIVER_NAME$1 = "memory";
const memory = defineDriver$1(() => {
  const data = /* @__PURE__ */ new Map();
  return {
    name: DRIVER_NAME$1,
    getInstance: () => data,
    hasItem(key) {
      return data.has(key);
    },
    getItem(key) {
      return data.get(key) ?? null;
    },
    getItemRaw(key) {
      return data.get(key) ?? null;
    },
    setItem(key, value) {
      data.set(key, value);
    },
    setItemRaw(key, value) {
      data.set(key, value);
    },
    removeItem(key) {
      data.delete(key);
    },
    getKeys() {
      return [...data.keys()];
    },
    clear() {
      data.clear();
    },
    dispose() {
      data.clear();
    }
  };
});

function createStorage(options = {}) {
  const context = {
    mounts: { "": options.driver || memory() },
    mountpoints: [""],
    watching: false,
    watchListeners: [],
    unwatch: {}
  };
  const getMount = (key) => {
    for (const base of context.mountpoints) {
      if (key.startsWith(base)) {
        return {
          base,
          relativeKey: key.slice(base.length),
          driver: context.mounts[base]
        };
      }
    }
    return {
      base: "",
      relativeKey: key,
      driver: context.mounts[""]
    };
  };
  const getMounts = (base, includeParent) => {
    return context.mountpoints.filter(
      (mountpoint) => mountpoint.startsWith(base) || includeParent && base.startsWith(mountpoint)
    ).map((mountpoint) => ({
      relativeBase: base.length > mountpoint.length ? base.slice(mountpoint.length) : void 0,
      mountpoint,
      driver: context.mounts[mountpoint]
    }));
  };
  const onChange = (event, key) => {
    if (!context.watching) {
      return;
    }
    key = normalizeKey$1(key);
    for (const listener of context.watchListeners) {
      listener(event, key);
    }
  };
  const startWatch = async () => {
    if (context.watching) {
      return;
    }
    context.watching = true;
    for (const mountpoint in context.mounts) {
      context.unwatch[mountpoint] = await watch(
        context.mounts[mountpoint],
        onChange,
        mountpoint
      );
    }
  };
  const stopWatch = async () => {
    if (!context.watching) {
      return;
    }
    for (const mountpoint in context.unwatch) {
      await context.unwatch[mountpoint]();
    }
    context.unwatch = {};
    context.watching = false;
  };
  const runBatch = (items, commonOptions, cb) => {
    const batches = /* @__PURE__ */ new Map();
    const getBatch = (mount) => {
      let batch = batches.get(mount.base);
      if (!batch) {
        batch = {
          driver: mount.driver,
          base: mount.base,
          items: []
        };
        batches.set(mount.base, batch);
      }
      return batch;
    };
    for (const item of items) {
      const isStringItem = typeof item === "string";
      const key = normalizeKey$1(isStringItem ? item : item.key);
      const value = isStringItem ? void 0 : item.value;
      const options2 = isStringItem || !item.options ? commonOptions : { ...commonOptions, ...item.options };
      const mount = getMount(key);
      getBatch(mount).items.push({
        key,
        value,
        relativeKey: mount.relativeKey,
        options: options2
      });
    }
    return Promise.all([...batches.values()].map((batch) => cb(batch))).then(
      (r) => r.flat()
    );
  };
  const storage = {
    // Item
    hasItem(key, opts = {}) {
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      return asyncCall(driver.hasItem, relativeKey, opts);
    },
    getItem(key, opts = {}) {
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      return asyncCall(driver.getItem, relativeKey, opts).then(
        (value) => destr(value)
      );
    },
    getItems(items, commonOptions = {}) {
      return runBatch(items, commonOptions, (batch) => {
        if (batch.driver.getItems) {
          return asyncCall(
            batch.driver.getItems,
            batch.items.map((item) => ({
              key: item.relativeKey,
              options: item.options
            })),
            commonOptions
          ).then(
            (r) => r.map((item) => ({
              key: joinKeys(batch.base, item.key),
              value: destr(item.value)
            }))
          );
        }
        return Promise.all(
          batch.items.map((item) => {
            return asyncCall(
              batch.driver.getItem,
              item.relativeKey,
              item.options
            ).then((value) => ({
              key: item.key,
              value: destr(value)
            }));
          })
        );
      });
    },
    getItemRaw(key, opts = {}) {
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      if (driver.getItemRaw) {
        return asyncCall(driver.getItemRaw, relativeKey, opts);
      }
      return asyncCall(driver.getItem, relativeKey, opts).then(
        (value) => deserializeRaw(value)
      );
    },
    async setItem(key, value, opts = {}) {
      if (value === void 0) {
        return storage.removeItem(key);
      }
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      if (!driver.setItem) {
        return;
      }
      await asyncCall(driver.setItem, relativeKey, stringify(value), opts);
      if (!driver.watch) {
        onChange("update", key);
      }
    },
    async setItems(items, commonOptions) {
      await runBatch(items, commonOptions, async (batch) => {
        if (batch.driver.setItems) {
          return asyncCall(
            batch.driver.setItems,
            batch.items.map((item) => ({
              key: item.relativeKey,
              value: stringify(item.value),
              options: item.options
            })),
            commonOptions
          );
        }
        if (!batch.driver.setItem) {
          return;
        }
        await Promise.all(
          batch.items.map((item) => {
            return asyncCall(
              batch.driver.setItem,
              item.relativeKey,
              stringify(item.value),
              item.options
            );
          })
        );
      });
    },
    async setItemRaw(key, value, opts = {}) {
      if (value === void 0) {
        return storage.removeItem(key, opts);
      }
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      if (driver.setItemRaw) {
        await asyncCall(driver.setItemRaw, relativeKey, value, opts);
      } else if (driver.setItem) {
        await asyncCall(driver.setItem, relativeKey, serializeRaw(value), opts);
      } else {
        return;
      }
      if (!driver.watch) {
        onChange("update", key);
      }
    },
    async removeItem(key, opts = {}) {
      if (typeof opts === "boolean") {
        opts = { removeMeta: opts };
      }
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      if (!driver.removeItem) {
        return;
      }
      await asyncCall(driver.removeItem, relativeKey, opts);
      if (opts.removeMeta || opts.removeMata) {
        await asyncCall(driver.removeItem, relativeKey + "$", opts);
      }
      if (!driver.watch) {
        onChange("remove", key);
      }
    },
    // Meta
    async getMeta(key, opts = {}) {
      if (typeof opts === "boolean") {
        opts = { nativeOnly: opts };
      }
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      const meta = /* @__PURE__ */ Object.create(null);
      if (driver.getMeta) {
        Object.assign(meta, await asyncCall(driver.getMeta, relativeKey, opts));
      }
      if (!opts.nativeOnly) {
        const value = await asyncCall(
          driver.getItem,
          relativeKey + "$",
          opts
        ).then((value_) => destr(value_));
        if (value && typeof value === "object") {
          if (typeof value.atime === "string") {
            value.atime = new Date(value.atime);
          }
          if (typeof value.mtime === "string") {
            value.mtime = new Date(value.mtime);
          }
          Object.assign(meta, value);
        }
      }
      return meta;
    },
    setMeta(key, value, opts = {}) {
      return this.setItem(key + "$", value, opts);
    },
    removeMeta(key, opts = {}) {
      return this.removeItem(key + "$", opts);
    },
    // Keys
    async getKeys(base, opts = {}) {
      base = normalizeBaseKey(base);
      const mounts = getMounts(base, true);
      let maskedMounts = [];
      const allKeys = [];
      let allMountsSupportMaxDepth = true;
      for (const mount of mounts) {
        if (!mount.driver.flags?.maxDepth) {
          allMountsSupportMaxDepth = false;
        }
        const rawKeys = await asyncCall(
          mount.driver.getKeys,
          mount.relativeBase,
          opts
        );
        for (const key of rawKeys) {
          const fullKey = mount.mountpoint + normalizeKey$1(key);
          if (!maskedMounts.some((p) => fullKey.startsWith(p))) {
            allKeys.push(fullKey);
          }
        }
        maskedMounts = [
          mount.mountpoint,
          ...maskedMounts.filter((p) => !p.startsWith(mount.mountpoint))
        ];
      }
      const shouldFilterByDepth = opts.maxDepth !== void 0 && !allMountsSupportMaxDepth;
      return allKeys.filter(
        (key) => (!shouldFilterByDepth || filterKeyByDepth(key, opts.maxDepth)) && filterKeyByBase(key, base)
      );
    },
    // Utils
    async clear(base, opts = {}) {
      base = normalizeBaseKey(base);
      await Promise.all(
        getMounts(base, false).map(async (m) => {
          if (m.driver.clear) {
            return asyncCall(m.driver.clear, m.relativeBase, opts);
          }
          if (m.driver.removeItem) {
            const keys = await m.driver.getKeys(m.relativeBase || "", opts);
            return Promise.all(
              keys.map((key) => m.driver.removeItem(key, opts))
            );
          }
        })
      );
    },
    async dispose() {
      await Promise.all(
        Object.values(context.mounts).map((driver) => dispose(driver))
      );
    },
    async watch(callback) {
      await startWatch();
      context.watchListeners.push(callback);
      return async () => {
        context.watchListeners = context.watchListeners.filter(
          (listener) => listener !== callback
        );
        if (context.watchListeners.length === 0) {
          await stopWatch();
        }
      };
    },
    async unwatch() {
      context.watchListeners = [];
      await stopWatch();
    },
    // Mount
    mount(base, driver) {
      base = normalizeBaseKey(base);
      if (base && context.mounts[base]) {
        throw new Error(`already mounted at ${base}`);
      }
      if (base) {
        context.mountpoints.push(base);
        context.mountpoints.sort((a, b) => b.length - a.length);
      }
      context.mounts[base] = driver;
      if (context.watching) {
        Promise.resolve(watch(driver, onChange, base)).then((unwatcher) => {
          context.unwatch[base] = unwatcher;
        }).catch(console.error);
      }
      return storage;
    },
    async unmount(base, _dispose = true) {
      base = normalizeBaseKey(base);
      if (!base || !context.mounts[base]) {
        return;
      }
      if (context.watching && base in context.unwatch) {
        context.unwatch[base]?.();
        delete context.unwatch[base];
      }
      if (_dispose) {
        await dispose(context.mounts[base]);
      }
      context.mountpoints = context.mountpoints.filter((key) => key !== base);
      delete context.mounts[base];
    },
    getMount(key = "") {
      key = normalizeKey$1(key) + ":";
      const m = getMount(key);
      return {
        driver: m.driver,
        base: m.base
      };
    },
    getMounts(base = "", opts = {}) {
      base = normalizeKey$1(base);
      const mounts = getMounts(base, opts.parents);
      return mounts.map((m) => ({
        driver: m.driver,
        base: m.mountpoint
      }));
    },
    // Aliases
    keys: (base, opts = {}) => storage.getKeys(base, opts),
    get: (key, opts = {}) => storage.getItem(key, opts),
    set: (key, value, opts = {}) => storage.setItem(key, value, opts),
    has: (key, opts = {}) => storage.hasItem(key, opts),
    del: (key, opts = {}) => storage.removeItem(key, opts),
    remove: (key, opts = {}) => storage.removeItem(key, opts)
  };
  return storage;
}
function watch(driver, onChange, base) {
  return driver.watch ? driver.watch((event, key) => onChange(event, base + key)) : () => {
  };
}
async function dispose(driver) {
  if (typeof driver.dispose === "function") {
    await asyncCall(driver.dispose);
  }
}

const _assets = {

};

const normalizeKey = function normalizeKey(key) {
  if (!key) {
    return "";
  }
  return key.split("?")[0]?.replace(/[/\\]/g, ":").replace(/:+/g, ":").replace(/^:|:$/g, "") || "";
};

const assets$1 = {
  getKeys() {
    return Promise.resolve(Object.keys(_assets))
  },
  hasItem (id) {
    id = normalizeKey(id);
    return Promise.resolve(id in _assets)
  },
  getItem (id) {
    id = normalizeKey(id);
    return Promise.resolve(_assets[id] ? _assets[id].import() : null)
  },
  getMeta (id) {
    id = normalizeKey(id);
    return Promise.resolve(_assets[id] ? _assets[id].meta : {})
  }
};

function defineDriver(factory) {
  return factory;
}
function createError(driver, message, opts) {
  const err = new Error(`[unstorage] [${driver}] ${message}`, opts);
  if (Error.captureStackTrace) {
    Error.captureStackTrace(err, createError);
  }
  return err;
}
function createRequiredError(driver, name) {
  if (Array.isArray(name)) {
    return createError(
      driver,
      `Missing some of the required options ${name.map((n) => "`" + n + "`").join(", ")}`
    );
  }
  return createError(driver, `Missing required option \`${name}\`.`);
}

function ignoreNotfound(err) {
  return err.code === "ENOENT" || err.code === "EISDIR" ? null : err;
}
function ignoreExists(err) {
  return err.code === "EEXIST" ? null : err;
}
async function writeFile(path, data, encoding) {
  await ensuredir(dirname$1(path));
  return promises.writeFile(path, data, encoding);
}
function readFile(path, encoding) {
  return promises.readFile(path, encoding).catch(ignoreNotfound);
}
function unlink(path) {
  return promises.unlink(path).catch(ignoreNotfound);
}
function readdir(dir) {
  return promises.readdir(dir, { withFileTypes: true }).catch(ignoreNotfound).then((r) => r || []);
}
async function ensuredir(dir) {
  if (existsSync(dir)) {
    return;
  }
  await ensuredir(dirname$1(dir)).catch(ignoreExists);
  await promises.mkdir(dir).catch(ignoreExists);
}
async function readdirRecursive(dir, ignore, maxDepth) {
  if (ignore && ignore(dir)) {
    return [];
  }
  const entries = await readdir(dir);
  const files = [];
  await Promise.all(
    entries.map(async (entry) => {
      const entryPath = resolve$1(dir, entry.name);
      if (entry.isDirectory()) {
        if (maxDepth === void 0 || maxDepth > 0) {
          const dirFiles = await readdirRecursive(
            entryPath,
            ignore,
            maxDepth === void 0 ? void 0 : maxDepth - 1
          );
          files.push(...dirFiles.map((f) => entry.name + "/" + f));
        }
      } else {
        if (!(ignore && ignore(entry.name))) {
          files.push(entry.name);
        }
      }
    })
  );
  return files;
}
async function rmRecursive(dir) {
  const entries = await readdir(dir);
  await Promise.all(
    entries.map((entry) => {
      const entryPath = resolve$1(dir, entry.name);
      if (entry.isDirectory()) {
        return rmRecursive(entryPath).then(() => promises.rmdir(entryPath));
      } else {
        return promises.unlink(entryPath);
      }
    })
  );
}

const PATH_TRAVERSE_RE = /\.\.:|\.\.$/;
const DRIVER_NAME = "fs-lite";
const unstorage_47drivers_47fs_45lite = defineDriver((opts = {}) => {
  if (!opts.base) {
    throw createRequiredError(DRIVER_NAME, "base");
  }
  opts.base = resolve$1(opts.base);
  const r = (key) => {
    if (PATH_TRAVERSE_RE.test(key)) {
      throw createError(
        DRIVER_NAME,
        `Invalid key: ${JSON.stringify(key)}. It should not contain .. segments`
      );
    }
    const resolved = join(opts.base, key.replace(/:/g, "/"));
    return resolved;
  };
  return {
    name: DRIVER_NAME,
    options: opts,
    flags: {
      maxDepth: true
    },
    hasItem(key) {
      return existsSync(r(key));
    },
    getItem(key) {
      return readFile(r(key), "utf8");
    },
    getItemRaw(key) {
      return readFile(r(key));
    },
    async getMeta(key) {
      const { atime, mtime, size, birthtime, ctime } = await promises.stat(r(key)).catch(() => ({}));
      return { atime, mtime, size, birthtime, ctime };
    },
    setItem(key, value) {
      if (opts.readOnly) {
        return;
      }
      return writeFile(r(key), value, "utf8");
    },
    setItemRaw(key, value) {
      if (opts.readOnly) {
        return;
      }
      return writeFile(r(key), value);
    },
    removeItem(key) {
      if (opts.readOnly) {
        return;
      }
      return unlink(r(key));
    },
    getKeys(_base, topts) {
      return readdirRecursive(r("."), opts.ignore, topts?.maxDepth);
    },
    async clear() {
      if (opts.readOnly || opts.noClear) {
        return;
      }
      await rmRecursive(r("."));
    }
  };
});

const storage$1 = createStorage({});

storage$1.mount('/assets', assets$1);

storage$1.mount('data', unstorage_47drivers_47fs_45lite({"driver":"fsLite","base":"./.data/kv"}));

function useStorage(base = "") {
  return base ? prefixStorage(storage$1, base) : storage$1;
}

function serialize$1(o){return typeof o=="string"?`'${o}'`:new c().serialize(o)}const c=/*@__PURE__*/function(){class o{#t=new Map;compare(t,r){const e=typeof t,n=typeof r;return e==="string"&&n==="string"?t.localeCompare(r):e==="number"&&n==="number"?t-r:String.prototype.localeCompare.call(this.serialize(t,true),this.serialize(r,true))}serialize(t,r){if(t===null)return "null";switch(typeof t){case "string":return r?t:`'${t}'`;case "bigint":return `${t}n`;case "object":return this.$object(t);case "function":return this.$function(t)}return String(t)}serializeObject(t){const r=Object.prototype.toString.call(t);if(r!=="[object Object]")return this.serializeBuiltInType(r.length<10?`unknown:${r}`:r.slice(8,-1),t);const e=t.constructor,n=e===Object||e===void 0?"":e.name;if(n!==""&&globalThis[n]===e)return this.serializeBuiltInType(n,t);if(typeof t.toJSON=="function"){const i=t.toJSON();return n+(i!==null&&typeof i=="object"?this.$object(i):`(${this.serialize(i)})`)}return this.serializeObjectEntries(n,Object.entries(t))}serializeBuiltInType(t,r){const e=this["$"+t];if(e)return e.call(this,r);if(typeof r?.entries=="function")return this.serializeObjectEntries(t,r.entries());throw new Error(`Cannot serialize ${t}`)}serializeObjectEntries(t,r){const e=Array.from(r).sort((i,a)=>this.compare(i[0],a[0]));let n=`${t}{`;for(let i=0;i<e.length;i++){const[a,l]=e[i];n+=`${this.serialize(a,true)}:${this.serialize(l)}`,i<e.length-1&&(n+=",");}return n+"}"}$object(t){let r=this.#t.get(t);return r===void 0&&(this.#t.set(t,`#${this.#t.size}`),r=this.serializeObject(t),this.#t.set(t,r)),r}$function(t){const r=Function.prototype.toString.call(t);return r.slice(-15)==="[native code] }"?`${t.name||""}()[native]`:`${t.name}(${t.length})${r.replace(/\s*\n\s*/g,"")}`}$Array(t){let r="[";for(let e=0;e<t.length;e++)r+=this.serialize(t[e]),e<t.length-1&&(r+=",");return r+"]"}$Date(t){try{return `Date(${t.toISOString()})`}catch{return "Date(null)"}}$ArrayBuffer(t){return `ArrayBuffer[${new Uint8Array(t).join(",")}]`}$Set(t){return `Set${this.$Array(Array.from(t).sort((r,e)=>this.compare(r,e)))}`}$Map(t){return this.serializeObjectEntries("Map",t.entries())}}for(const s of ["Error","RegExp","URL"])o.prototype["$"+s]=function(t){return `${s}(${t})`};for(const s of ["Int8Array","Uint8Array","Uint8ClampedArray","Int16Array","Uint16Array","Int32Array","Uint32Array","Float32Array","Float64Array"])o.prototype["$"+s]=function(t){return `${s}[${t.join(",")}]`};for(const s of ["BigInt64Array","BigUint64Array"])o.prototype["$"+s]=function(t){return `${s}[${t.join("n,")}${t.length>0?"n":""}]`};return o}();

function isEqual(object1, object2) {
  if (object1 === object2) {
    return true;
  }
  if (serialize$1(object1) === serialize$1(object2)) {
    return true;
  }
  return false;
}

const e=globalThis.process?.getBuiltinModule?.("crypto")?.hash,r="sha256",s="base64url";function digest(t){if(e)return e(r,t,s);const o=createHash(r).update(t);return globalThis.process?.versions?.webcontainer?o.digest().toString(s):o.digest(s)}

function hash$1(input) {
  return digest(serialize$1(input));
}

const Hasher = /* @__PURE__ */ (() => {
  class Hasher2 {
    buff = "";
    #context = /* @__PURE__ */ new Map();
    write(str) {
      this.buff += str;
    }
    dispatch(value) {
      const type = value === null ? "null" : typeof value;
      return this[type](value);
    }
    object(object) {
      if (object && typeof object.toJSON === "function") {
        return this.object(object.toJSON());
      }
      const objString = Object.prototype.toString.call(object);
      let objType = "";
      const objectLength = objString.length;
      objType = objectLength < 10 ? "unknown:[" + objString + "]" : objString.slice(8, objectLength - 1);
      objType = objType.toLowerCase();
      let objectNumber = null;
      if ((objectNumber = this.#context.get(object)) === void 0) {
        this.#context.set(object, this.#context.size);
      } else {
        return this.dispatch("[CIRCULAR:" + objectNumber + "]");
      }
      if (typeof Buffer !== "undefined" && Buffer.isBuffer && Buffer.isBuffer(object)) {
        this.write("buffer:");
        return this.write(object.toString("utf8"));
      }
      if (objType !== "object" && objType !== "function" && objType !== "asyncfunction") {
        if (this[objType]) {
          this[objType](object);
        } else {
          this.unknown(object, objType);
        }
      } else {
        const keys = Object.keys(object).sort();
        const extraKeys = [];
        this.write("object:" + (keys.length + extraKeys.length) + ":");
        const dispatchForKey = (key) => {
          this.dispatch(key);
          this.write(":");
          this.dispatch(object[key]);
          this.write(",");
        };
        for (const key of keys) {
          dispatchForKey(key);
        }
        for (const key of extraKeys) {
          dispatchForKey(key);
        }
      }
    }
    array(arr, unordered) {
      unordered = unordered === void 0 ? false : unordered;
      this.write("array:" + arr.length + ":");
      if (!unordered || arr.length <= 1) {
        for (const entry of arr) {
          this.dispatch(entry);
        }
        return;
      }
      const contextAdditions = /* @__PURE__ */ new Map();
      const entries = arr.map((entry) => {
        const hasher = new Hasher2();
        hasher.dispatch(entry);
        for (const [key, value] of hasher.#context) {
          contextAdditions.set(key, value);
        }
        return hasher.toString();
      });
      this.#context = contextAdditions;
      entries.sort();
      return this.array(entries, false);
    }
    date(date) {
      return this.write("date:" + date.toJSON());
    }
    symbol(sym) {
      return this.write("symbol:" + sym.toString());
    }
    unknown(value, type) {
      this.write(type);
      if (!value) {
        return;
      }
      this.write(":");
      if (value && typeof value.entries === "function") {
        return this.array(
          [...value.entries()],
          true
          /* ordered */
        );
      }
    }
    error(err) {
      return this.write("error:" + err.toString());
    }
    boolean(bool) {
      return this.write("bool:" + bool);
    }
    string(string) {
      this.write("string:" + string.length + ":");
      this.write(string);
    }
    function(fn) {
      this.write("fn:");
      if (isNativeFunction(fn)) {
        this.dispatch("[native]");
      } else {
        this.dispatch(fn.toString());
      }
    }
    number(number) {
      return this.write("number:" + number);
    }
    null() {
      return this.write("Null");
    }
    undefined() {
      return this.write("Undefined");
    }
    regexp(regex) {
      return this.write("regex:" + regex.toString());
    }
    arraybuffer(arr) {
      this.write("arraybuffer:");
      return this.dispatch(new Uint8Array(arr));
    }
    url(url) {
      return this.write("url:" + url.toString());
    }
    map(map) {
      this.write("map:");
      const arr = [...map];
      return this.array(arr, false);
    }
    set(set) {
      this.write("set:");
      const arr = [...set];
      return this.array(arr, false);
    }
    bigint(number) {
      return this.write("bigint:" + number.toString());
    }
  }
  for (const type of [
    "uint8array",
    "uint8clampedarray",
    "unt8array",
    "uint16array",
    "unt16array",
    "uint32array",
    "unt32array",
    "float32array",
    "float64array"
  ]) {
    Hasher2.prototype[type] = function(arr) {
      this.write(type + ":");
      return this.array([...arr], false);
    };
  }
  function isNativeFunction(f) {
    if (typeof f !== "function") {
      return false;
    }
    return Function.prototype.toString.call(f).slice(
      -15
      /* "[native code] }".length */
    ) === "[native code] }";
  }
  return Hasher2;
})();
function serialize(object) {
  const hasher = new Hasher();
  hasher.dispatch(object);
  return hasher.buff;
}
function hash(value) {
  return digest(typeof value === "string" ? value : serialize(value)).replace(/[-_]/g, "").slice(0, 10);
}

function defaultCacheOptions() {
  return {
    name: "_",
    base: "/cache",
    swr: true,
    maxAge: 1
  };
}
function defineCachedFunction(fn, opts = {}) {
  opts = { ...defaultCacheOptions(), ...opts };
  const pending = {};
  const group = opts.group || "nitro/functions";
  const name = opts.name || fn.name || "_";
  const integrity = opts.integrity || hash([fn, opts]);
  const validate = opts.validate || ((entry) => entry.value !== void 0);
  async function get(key, resolver, shouldInvalidateCache, event) {
    const cacheKey = [opts.base, group, name, key + ".json"].filter(Boolean).join(":").replace(/:\/$/, ":index");
    let entry = await useStorage().getItem(cacheKey).catch((error) => {
      console.error(`[cache] Cache read error.`, error);
      useNitroApp().captureError(error, { event, tags: ["cache"] });
    }) || {};
    if (typeof entry !== "object") {
      entry = {};
      const error = new Error("Malformed data read from cache.");
      console.error("[cache]", error);
      useNitroApp().captureError(error, { event, tags: ["cache"] });
    }
    const ttl = (opts.maxAge ?? 0) * 1e3;
    if (ttl) {
      entry.expires = Date.now() + ttl;
    }
    const expired = shouldInvalidateCache || entry.integrity !== integrity || ttl && Date.now() - (entry.mtime || 0) > ttl || validate(entry) === false;
    const _resolve = async () => {
      const isPending = pending[key];
      if (!isPending) {
        if (entry.value !== void 0 && (opts.staleMaxAge || 0) >= 0 && opts.swr === false) {
          entry.value = void 0;
          entry.integrity = void 0;
          entry.mtime = void 0;
          entry.expires = void 0;
        }
        pending[key] = Promise.resolve(resolver());
      }
      try {
        entry.value = await pending[key];
      } catch (error) {
        if (!isPending) {
          delete pending[key];
        }
        throw error;
      }
      if (!isPending) {
        entry.mtime = Date.now();
        entry.integrity = integrity;
        delete pending[key];
        if (validate(entry) !== false) {
          let setOpts;
          if (opts.maxAge && !opts.swr) {
            setOpts = { ttl: opts.maxAge };
          }
          const promise = useStorage().setItem(cacheKey, entry, setOpts).catch((error) => {
            console.error(`[cache] Cache write error.`, error);
            useNitroApp().captureError(error, { event, tags: ["cache"] });
          });
          if (event?.waitUntil) {
            event.waitUntil(promise);
          }
        }
      }
    };
    const _resolvePromise = expired ? _resolve() : Promise.resolve();
    if (entry.value === void 0) {
      await _resolvePromise;
    } else if (expired && event && event.waitUntil) {
      event.waitUntil(_resolvePromise);
    }
    if (opts.swr && validate(entry) !== false) {
      _resolvePromise.catch((error) => {
        console.error(`[cache] SWR handler error.`, error);
        useNitroApp().captureError(error, { event, tags: ["cache"] });
      });
      return entry;
    }
    return _resolvePromise.then(() => entry);
  }
  return async (...args) => {
    const shouldBypassCache = await opts.shouldBypassCache?.(...args);
    if (shouldBypassCache) {
      return fn(...args);
    }
    const key = await (opts.getKey || getKey)(...args);
    const shouldInvalidateCache = await opts.shouldInvalidateCache?.(...args);
    const entry = await get(
      key,
      () => fn(...args),
      shouldInvalidateCache,
      args[0] && isEvent(args[0]) ? args[0] : void 0
    );
    let value = entry.value;
    if (opts.transform) {
      value = await opts.transform(entry, ...args) || value;
    }
    return value;
  };
}
function cachedFunction(fn, opts = {}) {
  return defineCachedFunction(fn, opts);
}
function getKey(...args) {
  return args.length > 0 ? hash(args) : "";
}
function escapeKey(key) {
  return String(key).replace(/\W/g, "");
}
function defineCachedEventHandler(handler, opts = defaultCacheOptions()) {
  const variableHeaderNames = (opts.varies || []).filter(Boolean).map((h) => h.toLowerCase()).sort();
  const _opts = {
    ...opts,
    getKey: async (event) => {
      const customKey = await opts.getKey?.(event);
      if (customKey) {
        return escapeKey(customKey);
      }
      const _path = event.node.req.originalUrl || event.node.req.url || event.path;
      let _pathname;
      try {
        _pathname = escapeKey(decodeURI(parseURL(_path).pathname)).slice(0, 16) || "index";
      } catch {
        _pathname = "-";
      }
      const _hashedPath = `${_pathname}.${hash(_path)}`;
      const _headers = variableHeaderNames.map((header) => [header, event.node.req.headers[header]]).map(([name, value]) => `${escapeKey(name)}.${hash(value)}`);
      return [_hashedPath, ..._headers].join(":");
    },
    validate: (entry) => {
      if (!entry.value) {
        return false;
      }
      if (entry.value.code >= 400) {
        return false;
      }
      if (entry.value.body === void 0) {
        return false;
      }
      if (entry.value.headers.etag === "undefined" || entry.value.headers["last-modified"] === "undefined") {
        return false;
      }
      return true;
    },
    group: opts.group || "nitro/handlers",
    integrity: opts.integrity || hash([handler, opts])
  };
  const _cachedHandler = cachedFunction(
    async (incomingEvent) => {
      const variableHeaders = {};
      for (const header of variableHeaderNames) {
        const value = incomingEvent.node.req.headers[header];
        if (value !== void 0) {
          variableHeaders[header] = value;
        }
      }
      const reqProxy = cloneWithProxy(incomingEvent.node.req, {
        headers: variableHeaders
      });
      const resHeaders = {};
      let _resSendBody;
      const resProxy = cloneWithProxy(incomingEvent.node.res, {
        statusCode: 200,
        writableEnded: false,
        writableFinished: false,
        headersSent: false,
        closed: false,
        getHeader(name) {
          return resHeaders[name];
        },
        setHeader(name, value) {
          resHeaders[name] = value;
          return this;
        },
        getHeaderNames() {
          return Object.keys(resHeaders);
        },
        hasHeader(name) {
          return name in resHeaders;
        },
        removeHeader(name) {
          delete resHeaders[name];
        },
        getHeaders() {
          return resHeaders;
        },
        end(chunk, arg2, arg3) {
          if (typeof chunk === "string") {
            _resSendBody = chunk;
          }
          if (typeof arg2 === "function") {
            arg2();
          }
          if (typeof arg3 === "function") {
            arg3();
          }
          return this;
        },
        write(chunk, arg2, arg3) {
          if (typeof chunk === "string") {
            _resSendBody = chunk;
          }
          if (typeof arg2 === "function") {
            arg2(void 0);
          }
          if (typeof arg3 === "function") {
            arg3();
          }
          return true;
        },
        writeHead(statusCode, headers2) {
          this.statusCode = statusCode;
          if (headers2) {
            if (Array.isArray(headers2) || typeof headers2 === "string") {
              throw new TypeError("Raw headers  is not supported.");
            }
            for (const header in headers2) {
              const value = headers2[header];
              if (value !== void 0) {
                this.setHeader(
                  header,
                  value
                );
              }
            }
          }
          return this;
        }
      });
      const event = createEvent(reqProxy, resProxy);
      event.fetch = (url, fetchOptions) => fetchWithEvent(event, url, fetchOptions, {
        fetch: useNitroApp().localFetch
      });
      event.$fetch = (url, fetchOptions) => fetchWithEvent(event, url, fetchOptions, {
        fetch: globalThis.$fetch
      });
      event.waitUntil = incomingEvent.waitUntil;
      event.context = incomingEvent.context;
      event.context.cache = {
        options: _opts
      };
      const body = await handler(event) || _resSendBody;
      const headers = event.node.res.getHeaders();
      headers.etag = String(
        headers.Etag || headers.etag || `W/"${hash(body)}"`
      );
      headers["last-modified"] = String(
        headers["Last-Modified"] || headers["last-modified"] || (/* @__PURE__ */ new Date()).toUTCString()
      );
      const cacheControl = [];
      if (opts.swr) {
        if (opts.maxAge) {
          cacheControl.push(`s-maxage=${opts.maxAge}`);
        }
        if (opts.staleMaxAge) {
          cacheControl.push(`stale-while-revalidate=${opts.staleMaxAge}`);
        } else {
          cacheControl.push("stale-while-revalidate");
        }
      } else if (opts.maxAge) {
        cacheControl.push(`max-age=${opts.maxAge}`);
      }
      if (cacheControl.length > 0) {
        headers["cache-control"] = cacheControl.join(", ");
      }
      const cacheEntry = {
        code: event.node.res.statusCode,
        headers,
        body
      };
      return cacheEntry;
    },
    _opts
  );
  return defineEventHandler(async (event) => {
    if (opts.headersOnly) {
      if (handleCacheHeaders(event, { maxAge: opts.maxAge })) {
        return;
      }
      return handler(event);
    }
    const response = await _cachedHandler(
      event
    );
    if (event.node.res.headersSent || event.node.res.writableEnded) {
      return response.body;
    }
    if (handleCacheHeaders(event, {
      modifiedTime: new Date(response.headers["last-modified"]),
      etag: response.headers.etag,
      maxAge: opts.maxAge
    })) {
      return;
    }
    event.node.res.statusCode = response.code;
    for (const name in response.headers) {
      const value = response.headers[name];
      if (name === "set-cookie") {
        event.node.res.appendHeader(
          name,
          splitCookiesString(value)
        );
      } else {
        if (value !== void 0) {
          event.node.res.setHeader(name, value);
        }
      }
    }
    return response.body;
  });
}
function cloneWithProxy(obj, overrides) {
  return new Proxy(obj, {
    get(target, property, receiver) {
      if (property in overrides) {
        return overrides[property];
      }
      return Reflect.get(target, property, receiver);
    },
    set(target, property, value, receiver) {
      if (property in overrides) {
        overrides[property] = value;
        return true;
      }
      return Reflect.set(target, property, value, receiver);
    }
  });
}
const cachedEventHandler = defineCachedEventHandler;

function klona(x) {
	if (typeof x !== 'object') return x;

	var k, tmp, str=Object.prototype.toString.call(x);

	if (str === '[object Object]') {
		if (x.constructor !== Object && typeof x.constructor === 'function') {
			tmp = new x.constructor();
			for (k in x) {
				if (x.hasOwnProperty(k) && tmp[k] !== x[k]) {
					tmp[k] = klona(x[k]);
				}
			}
		} else {
			tmp = {}; // null
			for (k in x) {
				if (k === '__proto__') {
					Object.defineProperty(tmp, k, {
						value: klona(x[k]),
						configurable: true,
						enumerable: true,
						writable: true,
					});
				} else {
					tmp[k] = klona(x[k]);
				}
			}
		}
		return tmp;
	}

	if (str === '[object Array]') {
		k = x.length;
		for (tmp=Array(k); k--;) {
			tmp[k] = klona(x[k]);
		}
		return tmp;
	}

	if (str === '[object Set]') {
		tmp = new Set;
		x.forEach(function (val) {
			tmp.add(klona(val));
		});
		return tmp;
	}

	if (str === '[object Map]') {
		tmp = new Map;
		x.forEach(function (val, key) {
			tmp.set(klona(key), klona(val));
		});
		return tmp;
	}

	if (str === '[object Date]') {
		return new Date(+x);
	}

	if (str === '[object RegExp]') {
		tmp = new RegExp(x.source, x.flags);
		tmp.lastIndex = x.lastIndex;
		return tmp;
	}

	if (str === '[object DataView]') {
		return new x.constructor( klona(x.buffer) );
	}

	if (str === '[object ArrayBuffer]') {
		return x.slice(0);
	}

	// ArrayBuffer.isView(x)
	// ~> `new` bcuz `Buffer.slice` => ref
	if (str.slice(-6) === 'Array]') {
		return new x.constructor(x);
	}

	return x;
}

const defineAppConfig = (config) => config;

const appConfig0 = defineAppConfig({
  ui: {
    colors: {
      primary: "green",
      neutral: "slate"
    }
  }
});

const inlineAppConfig = {
  "nuxt": {},
  "ui": {
    "colors": {
      "primary": "green",
      "secondary": "blue",
      "success": "green",
      "info": "blue",
      "warning": "yellow",
      "error": "red",
      "neutral": "slate"
    },
    "icons": {
      "arrowDown": "i-lucide-arrow-down",
      "arrowLeft": "i-lucide-arrow-left",
      "arrowRight": "i-lucide-arrow-right",
      "arrowUp": "i-lucide-arrow-up",
      "caution": "i-lucide-circle-alert",
      "check": "i-lucide-check",
      "chevronDoubleLeft": "i-lucide-chevrons-left",
      "chevronDoubleRight": "i-lucide-chevrons-right",
      "chevronDown": "i-lucide-chevron-down",
      "chevronLeft": "i-lucide-chevron-left",
      "chevronRight": "i-lucide-chevron-right",
      "chevronUp": "i-lucide-chevron-up",
      "close": "i-lucide-x",
      "copy": "i-lucide-copy",
      "copyCheck": "i-lucide-copy-check",
      "dark": "i-lucide-moon",
      "drag": "i-lucide-grip-vertical",
      "ellipsis": "i-lucide-ellipsis",
      "error": "i-lucide-circle-x",
      "external": "i-lucide-arrow-up-right",
      "eye": "i-lucide-eye",
      "eyeOff": "i-lucide-eye-off",
      "file": "i-lucide-file",
      "folder": "i-lucide-folder",
      "folderOpen": "i-lucide-folder-open",
      "hash": "i-lucide-hash",
      "info": "i-lucide-info",
      "light": "i-lucide-sun",
      "loading": "i-lucide-loader-circle",
      "menu": "i-lucide-menu",
      "minus": "i-lucide-minus",
      "panelClose": "i-lucide-panel-left-close",
      "panelOpen": "i-lucide-panel-left-open",
      "plus": "i-lucide-plus",
      "reload": "i-lucide-rotate-ccw",
      "search": "i-lucide-search",
      "stop": "i-lucide-square",
      "success": "i-lucide-circle-check",
      "system": "i-lucide-monitor",
      "tip": "i-lucide-lightbulb",
      "upload": "i-lucide-upload",
      "warning": "i-lucide-triangle-alert"
    },
    "tv": {
      "twMergeConfig": {}
    }
  },
  "icon": {
    "provider": "server",
    "class": "",
    "aliases": {},
    "iconifyApiEndpoint": "https://api.iconify.design",
    "localApiEndpoint": "/api/_nuxt_icon",
    "fallbackToApi": true,
    "cssSelectorPrefix": "i-",
    "cssWherePseudo": true,
    "cssLayer": "base",
    "mode": "css",
    "attrs": {
      "aria-hidden": true
    },
    "collections": [
      "academicons",
      "akar-icons",
      "ant-design",
      "arcticons",
      "basil",
      "bi",
      "bitcoin-icons",
      "bpmn",
      "brandico",
      "bx",
      "bxl",
      "bxs",
      "bytesize",
      "carbon",
      "catppuccin",
      "cbi",
      "charm",
      "ci",
      "cib",
      "cif",
      "cil",
      "circle-flags",
      "circum",
      "clarity",
      "codex",
      "codicon",
      "covid",
      "cryptocurrency",
      "cryptocurrency-color",
      "cuida",
      "dashicons",
      "devicon",
      "devicon-plain",
      "dinkie-icons",
      "duo-icons",
      "ei",
      "el",
      "emojione",
      "emojione-monotone",
      "emojione-v1",
      "entypo",
      "entypo-social",
      "eos-icons",
      "ep",
      "et",
      "eva",
      "f7",
      "fa",
      "fa-brands",
      "fa-regular",
      "fa-solid",
      "fa6-brands",
      "fa6-regular",
      "fa6-solid",
      "fa7-brands",
      "fa7-regular",
      "fa7-solid",
      "fad",
      "famicons",
      "fe",
      "feather",
      "file-icons",
      "flag",
      "flagpack",
      "flat-color-icons",
      "flat-ui",
      "flowbite",
      "fluent",
      "fluent-color",
      "fluent-emoji",
      "fluent-emoji-flat",
      "fluent-emoji-high-contrast",
      "fluent-mdl2",
      "fontelico",
      "fontisto",
      "formkit",
      "foundation",
      "fxemoji",
      "gala",
      "game-icons",
      "garden",
      "geo",
      "gg",
      "gis",
      "gravity-ui",
      "gridicons",
      "grommet-icons",
      "guidance",
      "healthicons",
      "heroicons",
      "heroicons-outline",
      "heroicons-solid",
      "hugeicons",
      "humbleicons",
      "ic",
      "icomoon-free",
      "icon-park",
      "icon-park-outline",
      "icon-park-solid",
      "icon-park-twotone",
      "iconamoon",
      "iconoir",
      "icons8",
      "il",
      "ion",
      "iwwa",
      "ix",
      "jam",
      "la",
      "lets-icons",
      "line-md",
      "lineicons",
      "logos",
      "ls",
      "lsicon",
      "lucide",
      "lucide-lab",
      "mage",
      "majesticons",
      "maki",
      "map",
      "marketeq",
      "material-icon-theme",
      "material-symbols",
      "material-symbols-light",
      "mdi",
      "mdi-light",
      "medical-icon",
      "memory",
      "meteocons",
      "meteor-icons",
      "mi",
      "mingcute",
      "mono-icons",
      "mynaui",
      "nimbus",
      "nonicons",
      "noto",
      "noto-v1",
      "nrk",
      "octicon",
      "oi",
      "ooui",
      "openmoji",
      "oui",
      "pajamas",
      "pepicons",
      "pepicons-pencil",
      "pepicons-pop",
      "pepicons-print",
      "ph",
      "picon",
      "pixel",
      "pixelarticons",
      "prime",
      "proicons",
      "ps",
      "qlementine-icons",
      "quill",
      "radix-icons",
      "raphael",
      "ri",
      "rivet-icons",
      "roentgen",
      "si",
      "si-glyph",
      "sidekickicons",
      "simple-icons",
      "simple-line-icons",
      "skill-icons",
      "solar",
      "stash",
      "streamline",
      "streamline-block",
      "streamline-color",
      "streamline-cyber",
      "streamline-cyber-color",
      "streamline-emojis",
      "streamline-flex",
      "streamline-flex-color",
      "streamline-freehand",
      "streamline-freehand-color",
      "streamline-kameleon-color",
      "streamline-logos",
      "streamline-pixel",
      "streamline-plump",
      "streamline-plump-color",
      "streamline-sharp",
      "streamline-sharp-color",
      "streamline-stickies-color",
      "streamline-ultimate",
      "streamline-ultimate-color",
      "subway",
      "svg-spinners",
      "system-uicons",
      "tabler",
      "tdesign",
      "teenyicons",
      "temaki",
      "token",
      "token-branded",
      "topcoat",
      "twemoji",
      "typcn",
      "uil",
      "uim",
      "uis",
      "uit",
      "uiw",
      "unjs",
      "vaadin",
      "vs",
      "vscode-icons",
      "websymbol",
      "weui",
      "whh",
      "wi",
      "wpf",
      "zmdi",
      "zondicons"
    ],
    "fetchTimeout": 1500
  }
};

const appConfig = defuFn(appConfig0, inlineAppConfig);

const NUMBER_CHAR_RE = /\d/;
const STR_SPLITTERS = ["-", "_", "/", "."];
function isUppercase(char = "") {
  if (NUMBER_CHAR_RE.test(char)) {
    return void 0;
  }
  return char !== char.toLowerCase();
}
function splitByCase(str, separators) {
  const splitters = STR_SPLITTERS;
  const parts = [];
  if (!str || typeof str !== "string") {
    return parts;
  }
  let buff = "";
  let previousUpper;
  let previousSplitter;
  for (const char of str) {
    const isSplitter = splitters.includes(char);
    if (isSplitter === true) {
      parts.push(buff);
      buff = "";
      previousUpper = void 0;
      continue;
    }
    const isUpper = isUppercase(char);
    if (previousSplitter === false) {
      if (previousUpper === false && isUpper === true) {
        parts.push(buff);
        buff = char;
        previousUpper = isUpper;
        continue;
      }
      if (previousUpper === true && isUpper === false && buff.length > 1) {
        const lastChar = buff.at(-1);
        parts.push(buff.slice(0, Math.max(0, buff.length - 1)));
        buff = lastChar + char;
        previousUpper = isUpper;
        continue;
      }
    }
    buff += char;
    previousUpper = isUpper;
    previousSplitter = isSplitter;
  }
  parts.push(buff);
  return parts;
}
function kebabCase(str, joiner) {
  return str ? (Array.isArray(str) ? str : splitByCase(str)).map((p) => p.toLowerCase()).join(joiner) : "";
}
function snakeCase(str) {
  return kebabCase(str || "", "_");
}

function getEnv(key, opts) {
  const envKey = snakeCase(key).toUpperCase();
  return destr(
    process.env[opts.prefix + envKey] ?? process.env[opts.altPrefix + envKey]
  );
}
function _isObject(input) {
  return typeof input === "object" && !Array.isArray(input);
}
function applyEnv(obj, opts, parentKey = "") {
  for (const key in obj) {
    const subKey = parentKey ? `${parentKey}_${key}` : key;
    const envValue = getEnv(subKey, opts);
    if (_isObject(obj[key])) {
      if (_isObject(envValue)) {
        obj[key] = { ...obj[key], ...envValue };
        applyEnv(obj[key], opts, subKey);
      } else if (envValue === void 0) {
        applyEnv(obj[key], opts, subKey);
      } else {
        obj[key] = envValue ?? obj[key];
      }
    } else {
      obj[key] = envValue ?? obj[key];
    }
    if (opts.envExpansion && typeof obj[key] === "string") {
      obj[key] = _expandFromEnv(obj[key]);
    }
  }
  return obj;
}
const envExpandRx = /\{\{([^{}]*)\}\}/g;
function _expandFromEnv(value) {
  return value.replace(envExpandRx, (match, key) => {
    return process.env[key] || match;
  });
}

const _inlineRuntimeConfig = {
  "app": {
    "baseURL": "/",
    "buildId": "651d4888-c173-4ede-a015-b513cf77dea6",
    "buildAssetsDir": "/_nuxt/",
    "cdnURL": ""
  },
  "nitro": {
    "envPrefix": "NUXT_",
    "routeRules": {
      "/__nuxt_error": {
        "cache": false
      },
      "/_nuxt/builds/meta/**": {
        "headers": {
          "cache-control": "public, max-age=31536000, immutable"
        }
      },
      "/_nuxt/builds/**": {
        "headers": {
          "cache-control": "public, max-age=1, immutable"
        }
      },
      "/_fonts/**": {
        "headers": {
          "cache-control": "public, max-age=31536000, immutable"
        }
      },
      "/_nuxt/**": {
        "headers": {
          "cache-control": "public, max-age=31536000, immutable"
        }
      }
    }
  },
  "public": {
    "i18n": {
      "baseUrl": "",
      "defaultLocale": "en",
      "rootRedirect": "",
      "redirectStatusCode": 302,
      "skipSettingLocaleOnNavigate": false,
      "locales": [
        {
          "code": "en",
          "name": "English",
          "language": ""
        },
        {
          "code": "es",
          "name": "Español",
          "language": ""
        }
      ],
      "detectBrowserLanguage": {
        "alwaysRedirect": false,
        "cookieCrossOrigin": false,
        "cookieDomain": "",
        "cookieKey": "hermes_war_room_lang",
        "cookieSecure": false,
        "fallbackLocale": "",
        "redirectOn": "root",
        "useCookie": true
      },
      "experimental": {
        "localeDetector": "",
        "typedPages": true,
        "typedOptionsAndMessages": false,
        "alternateLinkCanonicalQueries": true,
        "devCache": false,
        "cacheLifetime": "",
        "stripMessagesPayload": false,
        "preload": false,
        "strictSeo": false,
        "nitroContextDetection": true,
        "httpCacheDuration": 10,
        "compactRoutes": false
      },
      "domainLocales": {
        "en": {
          "domain": ""
        },
        "es": {
          "domain": ""
        }
      }
    }
  },
  "icon": {
    "serverKnownCssClasses": []
  }
};
const envOptions = {
  prefix: "NITRO_",
  altPrefix: _inlineRuntimeConfig.nitro.envPrefix ?? process.env.NITRO_ENV_PREFIX ?? "_",
  envExpansion: _inlineRuntimeConfig.nitro.envExpansion ?? process.env.NITRO_ENV_EXPANSION ?? false
};
const _sharedRuntimeConfig = _deepFreeze(
  applyEnv(klona(_inlineRuntimeConfig), envOptions)
);
function useRuntimeConfig(event) {
  if (!event) {
    return _sharedRuntimeConfig;
  }
  if (event.context.nitro.runtimeConfig) {
    return event.context.nitro.runtimeConfig;
  }
  const runtimeConfig = klona(_inlineRuntimeConfig);
  applyEnv(runtimeConfig, envOptions);
  event.context.nitro.runtimeConfig = runtimeConfig;
  return runtimeConfig;
}
const _sharedAppConfig = _deepFreeze(klona(appConfig));
function useAppConfig(event) {
  {
    return _sharedAppConfig;
  }
}
function _deepFreeze(object) {
  const propNames = Object.getOwnPropertyNames(object);
  for (const name of propNames) {
    const value = object[name];
    if (value && typeof value === "object") {
      _deepFreeze(value);
    }
  }
  return Object.freeze(object);
}
new Proxy(/* @__PURE__ */ Object.create(null), {
  get: (_, prop) => {
    console.warn(
      "Please use `useRuntimeConfig()` instead of accessing config directly."
    );
    const runtimeConfig = useRuntimeConfig();
    if (prop in runtimeConfig) {
      return runtimeConfig[prop];
    }
    return void 0;
  }
});

function createContext(opts = {}) {
  let currentInstance;
  let isSingleton = false;
  const checkConflict = (instance) => {
    if (currentInstance && currentInstance !== instance) {
      throw new Error("Context conflict");
    }
  };
  let als;
  if (opts.asyncContext) {
    const _AsyncLocalStorage = opts.AsyncLocalStorage || globalThis.AsyncLocalStorage;
    if (_AsyncLocalStorage) {
      als = new _AsyncLocalStorage();
    } else {
      console.warn("[unctx] `AsyncLocalStorage` is not provided.");
    }
  }
  const _getCurrentInstance = () => {
    if (als) {
      const instance = als.getStore();
      if (instance !== void 0) {
        return instance;
      }
    }
    return currentInstance;
  };
  return {
    use: () => {
      const _instance = _getCurrentInstance();
      if (_instance === void 0) {
        throw new Error("Context is not available");
      }
      return _instance;
    },
    tryUse: () => {
      return _getCurrentInstance();
    },
    set: (instance, replace) => {
      if (!replace) {
        checkConflict(instance);
      }
      currentInstance = instance;
      isSingleton = true;
    },
    unset: () => {
      currentInstance = void 0;
      isSingleton = false;
    },
    call: (instance, callback) => {
      checkConflict(instance);
      currentInstance = instance;
      try {
        return als ? als.run(instance, callback) : callback();
      } finally {
        if (!isSingleton) {
          currentInstance = void 0;
        }
      }
    },
    async callAsync(instance, callback) {
      currentInstance = instance;
      const onRestore = () => {
        currentInstance = instance;
      };
      const onLeave = () => currentInstance === instance ? onRestore : void 0;
      asyncHandlers.add(onLeave);
      try {
        const r = als ? als.run(instance, callback) : callback();
        if (!isSingleton) {
          currentInstance = void 0;
        }
        return await r;
      } finally {
        asyncHandlers.delete(onLeave);
      }
    }
  };
}
function createNamespace(defaultOpts = {}) {
  const contexts = {};
  return {
    get(key, opts = {}) {
      if (!contexts[key]) {
        contexts[key] = createContext({ ...defaultOpts, ...opts });
      }
      return contexts[key];
    }
  };
}
const _globalThis = typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : typeof global !== "undefined" ? global : {};
const globalKey = "__unctx__";
const defaultNamespace = _globalThis[globalKey] || (_globalThis[globalKey] = createNamespace());
const getContext = (key, opts = {}) => defaultNamespace.get(key, opts);
const asyncHandlersKey = "__unctx_async_handlers__";
const asyncHandlers = _globalThis[asyncHandlersKey] || (_globalThis[asyncHandlersKey] = /* @__PURE__ */ new Set());
function executeAsync(function_) {
  const restores = [];
  for (const leaveHandler of asyncHandlers) {
    const restore2 = leaveHandler();
    if (restore2) {
      restores.push(restore2);
    }
  }
  const restore = () => {
    for (const restore2 of restores) {
      restore2();
    }
  };
  let awaitable = function_();
  if (awaitable && typeof awaitable === "object" && "catch" in awaitable) {
    awaitable = awaitable.catch((error) => {
      restore();
      throw error;
    });
  }
  return [awaitable, restore];
}

getContext("nitro-app", {
  asyncContext: false,
  AsyncLocalStorage: void 0
});

const config = useRuntimeConfig();
const _routeRulesMatcher = toRouteMatcher(
  createRouter$1({ routes: config.nitro.routeRules })
);
function createRouteRulesHandler(ctx) {
  return eventHandler((event) => {
    const routeRules = getRouteRules(event);
    if (routeRules.headers) {
      setHeaders(event, routeRules.headers);
    }
    if (routeRules.redirect) {
      let target = routeRules.redirect.to;
      if (target.endsWith("/**")) {
        let targetPath = event.path;
        const strpBase = routeRules.redirect._redirectStripBase;
        if (strpBase) {
          targetPath = withoutBase(targetPath, strpBase);
        }
        target = joinURL(target.slice(0, -3), targetPath);
      } else if (event.path.includes("?")) {
        const query = getQuery$1(event.path);
        target = withQuery(target, query);
      }
      return sendRedirect(event, target, routeRules.redirect.statusCode);
    }
    if (routeRules.proxy) {
      let target = routeRules.proxy.to;
      if (target.endsWith("/**")) {
        let targetPath = event.path;
        const strpBase = routeRules.proxy._proxyStripBase;
        if (strpBase) {
          targetPath = withoutBase(targetPath, strpBase);
        }
        target = joinURL(target.slice(0, -3), targetPath);
      } else if (event.path.includes("?")) {
        const query = getQuery$1(event.path);
        target = withQuery(target, query);
      }
      return proxyRequest(event, target, {
        fetch: ctx.localFetch,
        ...routeRules.proxy
      });
    }
  });
}
function getRouteRules(event) {
  event.context._nitro = event.context._nitro || {};
  if (!event.context._nitro.routeRules) {
    event.context._nitro.routeRules = getRouteRulesForPath(
      withoutBase(event.path.split("?")[0], useRuntimeConfig().app.baseURL)
    );
  }
  return event.context._nitro.routeRules;
}
function getRouteRulesForPath(path) {
  return defu({}, ..._routeRulesMatcher.matchAll(path).reverse());
}

function _captureError(error, type) {
  console.error(`[${type}]`, error);
  useNitroApp().captureError(error, { tags: [type] });
}
function trapUnhandledNodeErrors() {
  process.on(
    "unhandledRejection",
    (error) => _captureError(error, "unhandledRejection")
  );
  process.on(
    "uncaughtException",
    (error) => _captureError(error, "uncaughtException")
  );
}
function joinHeaders(value) {
  return Array.isArray(value) ? value.join(", ") : String(value);
}
function normalizeFetchResponse(response) {
  if (!response.headers.has("set-cookie")) {
    return response;
  }
  return new Response(response.body, {
    status: response.status,
    statusText: response.statusText,
    headers: normalizeCookieHeaders(response.headers)
  });
}
function normalizeCookieHeader(header = "") {
  return splitCookiesString(joinHeaders(header));
}
function normalizeCookieHeaders(headers) {
  const outgoingHeaders = new Headers();
  for (const [name, header] of headers) {
    if (name === "set-cookie") {
      for (const cookie of normalizeCookieHeader(header)) {
        outgoingHeaders.append("set-cookie", cookie);
      }
    } else {
      outgoingHeaders.set(name, joinHeaders(header));
    }
  }
  return outgoingHeaders;
}

/**
* Nitro internal functions extracted from https://github.com/nitrojs/nitro/blob/v2/src/runtime/internal/utils.ts
*/
function isJsonRequest(event) {
	// If the client specifically requests HTML, then avoid classifying as JSON.
	if (hasReqHeader(event, "accept", "text/html")) {
		return false;
	}
	return hasReqHeader(event, "accept", "application/json") || hasReqHeader(event, "user-agent", "curl/") || hasReqHeader(event, "user-agent", "httpie/") || hasReqHeader(event, "sec-fetch-mode", "cors") || event.path.startsWith("/api/") || event.path.endsWith(".json");
}
function hasReqHeader(event, name, includes) {
	const value = getRequestHeader(event, name);
	return !!(value && typeof value === "string" && value.toLowerCase().includes(includes));
}

const errorHandler$0 = (async function errorhandler(error, event, { defaultHandler }) {
	if (event.handled || isJsonRequest(event)) {
		// let Nitro handle JSON errors
		return;
	}
	// invoke default Nitro error handler (which will log appropriately if required)
	const defaultRes = await defaultHandler(error, event, { json: true });
	// let Nitro handle redirect if appropriate
	const status = error.status || error.statusCode || 500;
	if (status === 404 && defaultRes.status === 302) {
		setResponseHeaders(event, defaultRes.headers);
		setResponseStatus(event, defaultRes.status, defaultRes.statusText);
		return send(event, JSON.stringify(defaultRes.body, null, 2));
	}
	const errorObject = defaultRes.body;
	// remove proto/hostname/port from URL
	const url = new URL(errorObject.url);
	errorObject.url = withoutBase(url.pathname, useRuntimeConfig(event).app.baseURL) + url.search + url.hash;
	// add default server message (keep sanitized for unhandled errors)
	errorObject.message = error.unhandled ? errorObject.message || "Server Error" : error.message || errorObject.message || "Server Error";
	// we will be rendering this error internally so we can pass along the error.data safely
	errorObject.data ||= error.data;
	errorObject.statusText ||= error.statusText || error.statusMessage;
	delete defaultRes.headers["content-type"];
	delete defaultRes.headers["content-security-policy"];
	setResponseHeaders(event, defaultRes.headers);
	// Access request headers
	const reqHeaders = getRequestHeaders(event);
	// Detect to avoid recursion in SSR rendering of errors
	const isRenderingError = event.path.startsWith("/__nuxt_error") || !!reqHeaders["x-nuxt-error"];
	// HTML response (via SSR)
	const res = isRenderingError ? null : await useNitroApp().localFetch(withQuery(joinURL(useRuntimeConfig(event).app.baseURL, "/__nuxt_error"), errorObject), {
		headers: {
			...reqHeaders,
			"x-nuxt-error": "true"
		},
		redirect: "manual"
	}).catch(() => null);
	if (event.handled) {
		return;
	}
	// Fallback to static rendered error page
	if (!res) {
		const { template } = await import('../_/error-500.mjs');
		setResponseHeader(event, "Content-Type", "text/html;charset=UTF-8");
		return send(event, template(errorObject));
	}
	const html = await res.text();
	for (const [header, value] of res.headers.entries()) {
		if (header === "set-cookie") {
			appendResponseHeader(event, header, value);
			continue;
		}
		setResponseHeader(event, header, value);
	}
	setResponseStatus(event, res.status && res.status !== 200 ? res.status : defaultRes.status, res.statusText || defaultRes.statusText);
	return send(event, html);
});

function defineNitroErrorHandler(handler) {
  return handler;
}

const errorHandler$1 = defineNitroErrorHandler(
  function defaultNitroErrorHandler(error, event) {
    const res = defaultHandler(error, event);
    setResponseHeaders(event, res.headers);
    setResponseStatus(event, res.status, res.statusText);
    return send(event, JSON.stringify(res.body, null, 2));
  }
);
function defaultHandler(error, event, opts) {
  const isSensitive = error.unhandled || error.fatal;
  const statusCode = error.statusCode || 500;
  const statusMessage = error.statusMessage || "Server Error";
  const url = getRequestURL(event, { xForwardedHost: true, xForwardedProto: true });
  if (statusCode === 404) {
    const baseURL = "/";
    if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) {
      const redirectTo = `${baseURL}${url.pathname.slice(1)}${url.search}`;
      return {
        status: 302,
        statusText: "Found",
        headers: { location: redirectTo },
        body: `Redirecting...`
      };
    }
  }
  if (isSensitive && !opts?.silent) {
    const tags = [error.unhandled && "[unhandled]", error.fatal && "[fatal]"].filter(Boolean).join(" ");
    console.error(`[request error] ${tags} [${event.method}] ${url}
`, error);
  }
  const headers = {
    "content-type": "application/json",
    // Prevent browser from guessing the MIME types of resources.
    "x-content-type-options": "nosniff",
    // Prevent error page from being embedded in an iframe
    "x-frame-options": "DENY",
    // Prevent browsers from sending the Referer header
    "referrer-policy": "no-referrer",
    // Disable the execution of any js
    "content-security-policy": "script-src 'none'; frame-ancestors 'none';"
  };
  setResponseStatus(event, statusCode, statusMessage);
  if (statusCode === 404 || !getResponseHeader(event, "cache-control")) {
    headers["cache-control"] = "no-cache";
  }
  const body = {
    error: true,
    url: url.href,
    statusCode,
    statusMessage,
    message: isSensitive ? "Server Error" : error.message,
    data: isSensitive ? void 0 : error.data
  };
  return {
    status: statusCode,
    statusText: statusMessage,
    headers,
    body
  };
}

const errorHandlers = [errorHandler$0, errorHandler$1];

async function errorHandler(error, event) {
  for (const handler of errorHandlers) {
    try {
      await handler(error, event, { defaultHandler });
      if (event.handled) {
        return; // Response handled
      }
    } catch(error) {
      // Handler itself thrown, log and continue
      console.error(error);
    }
  }
  // H3 will handle fallback
}

/*!
  * shared v11.4.0
  * (c) 2026 kazuya kawaguchi
  * Released under the MIT License.
  */
const _create = Object.create;
const create = (obj = null) => _create(obj);
/* eslint-enable */
/**
 * Useful Utilities By Evan you
 * Modified by kazuya kawaguchi
 * MIT License
 * https://github.com/vuejs/vue-next/blob/master/packages/shared/src/index.ts
 * https://github.com/vuejs/vue-next/blob/master/packages/shared/src/codeframe.ts
 */
const isArray = Array.isArray;
const isFunction = (val) => typeof val === 'function';
const isString = (val) => typeof val === 'string';
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const isObject = (val) => val !== null && typeof val === 'object';
const objectToString = Object.prototype.toString;
const toTypeString = (value) => objectToString.call(value);

const isNotObjectOrIsArray = (val) => !isObject(val) || isArray(val);
// eslint-disable-next-line @typescript-eslint/no-explicit-any
function deepCopy(src, des) {
    // src and des should both be objects, and none of them can be a array
    if (isNotObjectOrIsArray(src) || isNotObjectOrIsArray(des)) {
        throw new Error('Invalid value');
    }
    const stack = [{ src, des }];
    while (stack.length) {
        const { src, des } = stack.pop();
        // using `Object.keys` which skips prototype properties
        Object.keys(src).forEach(key => {
            if (key === '__proto__') {
                return;
            }
            // if src[key] is an object/array, set des[key]
            // to empty object/array to prevent setting by reference
            if (isObject(src[key]) && !isObject(des[key])) {
                des[key] = Array.isArray(src[key]) ? [] : create();
            }
            if (isNotObjectOrIsArray(des[key]) || isNotObjectOrIsArray(src[key])) {
                // replace with src[key] when:
                // src[key] or des[key] is not an object, or
                // src[key] or des[key] is an array
                des[key] = src[key];
            }
            else {
                // src[key] and des[key] are both objects, merge them
                stack.push({ src: src[key], des: des[key] });
            }
        });
    }
}

const __nuxtMock = { runWithContext: async (fn) => await fn() };
const merger = createDefu((obj, key, value) => {
  if (key === "messages" || key === "datetimeFormats" || key === "numberFormats") {
    obj[key] ??= create(null);
    deepCopy(value, obj[key]);
    return true;
  }
});
async function loadVueI18nOptions(vueI18nConfigs) {
  const nuxtApp = __nuxtMock;
  let vueI18nOptions = { messages: create(null) };
  for (const configFile of vueI18nConfigs) {
    const resolver = await configFile().then((x) => isModule(x) ? x.default : x);
    const resolved = isFunction(resolver) ? await nuxtApp.runWithContext(() => resolver()) : resolver;
    vueI18nOptions = merger(create(null), resolved, vueI18nOptions);
  }
  vueI18nOptions.fallbackLocale ??= false;
  return vueI18nOptions;
}
const isModule = (val) => toTypeString(val) === "[object Module]";
async function getLocaleMessages(locale, loader) {
  const nuxtApp = __nuxtMock;
  try {
    const getter = await nuxtApp.runWithContext(loader.load).then((x) => isModule(x) ? x.default : x);
    return isFunction(getter) ? await nuxtApp.runWithContext(() => getter(locale)) : getter;
  } catch (e) {
    throw new Error(`Failed loading locale (${locale}): ` + e.message);
  }
}
async function getLocaleMessagesMerged(locale, loaders = []) {
  const nuxtApp = __nuxtMock;
  const messages = await Promise.all(
    loaders.map((loader) => nuxtApp.runWithContext(() => getLocaleMessages(locale, loader)))
  );
  const merged = {};
  for (const message of messages) {
    deepCopy(message, merged);
  }
  return merged;
}

var app$1 = {
	title: "Hermes Orchestration War Room",
	description: "Visual orchestration layer for the Hermes multi-agent delegation system."
};
var nav$1 = {
	warRoom: "Operations Room",
	team: "The Team",
	missions: "Missions"
};
var common$1 = {
	rescan: "Rescan",
	cancel: "Cancel",
	"default": "default",
	language: "Language",
	manage: "Manage",
	done: "Done",
	forceDispatch: "Force dispatching",
	forceDispatchOk: "Dispatching forced",
	forceDispatchFailed: "Force dispatching failed"
};
var warRoom$1 = {
	title: "Operations Room",
	errorTitle: "Failed to load profiles",
	empty: "No Hermes profiles found under {dir}.",
	operativesCount: "no operatives | 1 operative | {count} operatives",
	stationLabel: "Station {num}",
	operationsFloor: "Operations Floor",
	missionScope: "Mission scope",
	globalScope: "All tasks",
	scopeToggle: "Show all tasks",
	scopeToggleMission: "Scope to mission",
	scopeAll: "All tasks",
	scopeMissingFallback: "(mission not in list)",
	scopeUntitledMission: "(untitled mission)",
	detail: {
		title: "Operative dossier",
		currentTask: "Current task",
		noTask: "No active task — standing by.",
		delegatedBy: "Delegated by",
		heartbeat: "Last heartbeat {ago} ago",
		live: "Live",
		started: "Started {time}",
		lastSteps: "Recent steps",
		noSteps: "No activity captured yet.",
		missionThread: "Mission thread",
		noMission: "No mission in progress.",
		subtasks: "Subtasks",
		noSubtasks: "No subtasks attached.",
		taskFeed: "Task activity",
		taskFeedLoading: "Loading conversation…",
		taskFeedNotStarted: "Worker hasn't started yet — no log file on disk.",
		taskFeedNoSession: "Worker started but session ID not yet stamped in the log.",
		taskFeedEmpty: "No messages recorded yet.",
		taskFeedReasoning: "Reasoning",
		taskFeedTotalsTitle: "Input: {input} tokens · Output: {output} tokens",
		taskFeedLog: "Worker output",
		taskFeedLogHint: "Showing the last lines of the raw worker log — useful when state.db hasn't caught up yet.",
		taskFeedLogSpan: "{from} → {to}",
		taskFeedLastActivity: "last write {ago} ago",
		taskFeedLogTruncated: "Showing last {bytes} of {total} (truncated).",
		taskFeedLogLoading: "Loading full log…",
		taskFeedLogReload: "Reload",
		taskKill: "Kill task",
		taskKillConfirmTitle: "Kill task {id}?",
		taskKillConfirmBody: "Terminates the worker process (SIGTERM) and archives the task so it disappears from the active board. Recoverable via `hermes kanban` if you need to inspect it later.",
		taskKillConfirmAction: "Kill",
		taskKilling: "Killing…",
		taskKilled: "Task killed",
		taskKillFailed: "Could not kill task",
		permissionPending: "PERMISSION PENDING",
		permissionPendingShort: "PERMISO",
		approveTitle: "Permission denial",
		approveBody: "The worker hit a Hermes permission classifier and was auto-denied. Approve the dangerous-pattern label below to add it to this profile's `command_allowlist` and retry the task.",
		approveLabelHint: "Exact label as Hermes' classifier emits it. Edit if the suggestion looks wrong before approving.",
		approveAction: "Approve & retry",
		approving: "Approving…",
		approveSuccess: "Approved & retrying",
		approveFailed: "Could not approve",
		approveNoLabel: "Could not extract a label — type it manually.",
		taskFeedSession: "Session",
		taskFeedDuration: "Running for {duration}",
		tokenInput: "input",
		tokenOutput: "output",
		tokenCacheRead: "cache read",
		tokenCacheWrite: "cache write",
		tokenCost: "cost"
	},
	history: {
		title: "Mission archive",
		subtitle: "Past missions, newest first.",
		empty: "No missions yet.",
		open: "Open",
		archived: "Archived",
		all: "All",
		messageCount: "no messages | 1 message | {count} messages",
		createdAt: "Started {when}",
		updatedAt: "Last activity {when}",
		loadFailed: "Could not load missions",
		page: "Page {current} of {total}",
		prev: "Prev",
		next: "Next"
	}
};
var mission$1 = {
	title: "Mission",
	send: "Assign",
	sending: "Assigning…",
	thinking: "{orch} is thinking…",
	newMission: "New mission",
	archived: "Mission archived",
	failure: "Could not reach the orchestrator",
	orchestrator: "Orchestrator",
	orchestratorLabel: "Orchestrator on duty:",
	dispatcherWarning: "No dispatcher detected. Run `hermes gateway start` so workers pick up tasks.",
	connectionLost: "Stream interrupted. Reconnecting…",
	idle: "Idle",
	empty: {
		placeholder: "Describe the mission for {orch}…"
	},
	input: {
		followUp: "Reply or refine the mission…"
	},
	task: {
		running: "Working on",
		queued: "Queued",
		blocked: "Blocked",
		thinking: "Thinking…"
	},
	tabs: {
		chat: "Chat",
		board: "Board"
	},
	board: {
		empty: "No tasks here.",
		boardEmpty: "Nothing on the board yet — assign a mission to get started.",
		col: {
			todo: "Todo",
			ready: "Ready",
			running: "Running",
			blocked: "Blocked"
		},
		started: "started {ago} ago",
		waiting: "waiting {ago}",
		completedTitle: "Completed tasks",
		completedAgo: "completed {ago} ago",
		completedEmpty: "Nothing completed yet.",
		completedLoading: "Loading…",
		completedMore: "Load more"
	},
	detail: {
		title: "Operative dossier",
		currentTask: "Current task",
		noTask: "No active task.",
		subtasks: "Delegated tasks",
		noSubtasks: "No outstanding delegations.",
		delegatedBy: "Delegated by",
		started: "Started {time}",
		heartbeat: "Heartbeat {ago}s ago",
		openMission: "Open mission",
		viewKanban: "View in kanban",
		lastSteps: "Recent activity",
		noSteps: "No recent activity.",
		missionThread: "Mission thread",
		noMission: "No active mission for this operative.",
		live: "Live"
	}
};
var team$1 = {
	title: "The Team",
	errorTitle: "Failed to load profiles",
	empty: "No Hermes profiles found under {dir}.",
	hire: "Hire"
};
var hire$1 = {
	title: "Operative intake",
	subtitle: "Pick a preset, edit the dossier, deploy.",
	presetSection: "Lane",
	presetHint: "Each preset prefills identity, rules, tools and skills. You can tweak everything before hiring.",
	briefingSection: "Briefing",
	capabilitiesSection: "Capabilities",
	nameLabel: "Profile slug",
	namePlaceholder: "e.g. researcher",
	nameHint: "Lowercase letters and numbers only — used as the kanban assignee value.",
	cloneLabel: "Copy from",
	clonePlaceholder: "Start fresh",
	cloneHint: "Optionally seed config.yaml + .env from an existing profile. Identity below overrides their SOUL.md.",
	noteAfterCreate: "MCP servers and provider auth can be configured after the profile is created.",
	submit: "Hire",
	submitting: "Hiring…",
	success: "{name} hired.",
	failure: "Could not hire profile"
};
var presets$1 = {
	orchestrator: {
		title: "Orchestrator",
		tagline: "You need dispatch, routing, drift detection, and escalation."
	},
	builder: {
		title: "Builder",
		tagline: "You need product code shipped with tests and build proof."
	},
	reviewer: {
		title: "Reviewer",
		tagline: "You need byte-verified review and merge readiness."
	},
	triage: {
		title: "Triage",
		tagline: "You need issues and PRs scored, reproduced, patched, prepared."
	},
	lab: {
		title: "Lab",
		tagline: "You need isolated experiments or local-model benchmarking."
	},
	fetcher: {
		title: "Data Fetcher",
		tagline: "You need information pulled from the open web — search, scrape, structured extraction. No analysis."
	},
	sage: {
		title: "Sage",
		tagline: "You need research, synthesis, scripts, or launch copy."
	},
	scribe: {
		title: "Scribe",
		tagline: "You need docs, specs, handoffs, skills hygiene, memory curation."
	},
	foundation: {
		title: "Foundation",
		tagline: "You need runtime, repair, infra, health, or lifecycle work."
	},
	qa: {
		title: "QA",
		tagline: "You need regression, smoke, expected-vs-actual verification."
	},
	mirror: {
		title: "Mirror Integrations",
		tagline: "You need upstream sync, integrations, or asset packs."
	},
	custom: {
		title: "Custom",
		tagline: "You're creating a lane that does not fit an existing preset."
	}
};
var skills$1 = {
	title: "Skills",
	loading: "Loading skills…",
	loadFailed: "Failed to load skills",
	empty: "No skills available.",
	search: "Search skills…",
	selectAll: "Enable all",
	selectNone: "Disable all",
	selected: "{count} of {total} enabled",
	uncategorized: "Other",
	sourceBuiltin: "Builtin",
	sourceGlobal: "Global",
	sourceProfile: "Local"
};
var tools$1 = {
	title: "Tools",
	loading: "Loading tools…",
	loadFailed: "Failed to load tools",
	empty: "No tools available.",
	search: "Search tools…",
	selectAll: "Enable all",
	selectNone: "Disable all",
	selected: "{count} of {total} enabled"
};
var soul$1 = {
	title: "Identity",
	hint: "Free-form Markdown saved to SOUL.md inside the profile. Tells the agent who they are and what they do.",
	placeholder: "# Who You Are\n\n_You're not a chatbot. You're becoming someone._\n\nWho Am I?\n\n- **Name:**\n- **Role:**\n- **Vibe:**",
	loadFailed: "Failed to load SOUL.md"
};
var mcp$1 = {
	title: "MCP servers",
	hint: "Remote tool sources connected to this profile. Failing servers slow every cold start (3 retries, ~7s wasted) — remove the ones this profile doesn't use.",
	loading: "Loading MCP servers…",
	loadFailed: "Failed to load MCP servers",
	empty: "No MCP servers configured for this profile.",
	remove: "Remove",
	removed: "{name} removed",
	removeFailed: "Could not remove MCP server",
	confirmRemove: "Remove MCP server \"{name}\" from this profile? Re-adding requires the Hermes CLI.",
	headers: "no headers | 1 header | {count} headers",
	headersTooltip: "Number of HTTP headers configured (likely auth tokens). Their values are not shown.",
	transport: {
		http: "HTTP",
		stdio: "stdio",
		unknown: "unknown"
	}
};
var retrain$1 = {
	action: "Retrain",
	title: "Retrain {name}",
	subtitle: "Identity & rules on the left, tools & knowledge on the right. Save when done.",
	submit: "Save",
	submitting: "Saving…",
	success: "Profile updated",
	failure: "Could not update profile",
	identitySection: "Identity & rules",
	capabilitiesSection: "Capabilities"
};
var rename$1 = {
	label: "Profile slug",
	help: "Lowercase alphanumeric. Renames the Hermes profile and re-points workers to the new id.",
	blockedDefault: "Default profile cannot be renamed.",
	invalid: "Slug must be lowercase letters and numbers only.",
	renaming: "Renaming…",
	success: "Renamed to {slug}",
	failure: "Could not rename profile"
};
var fire$1 = {
	action: "Fire",
	confirmTitle: "Fire {name}?",
	confirmBody: "This permanently removes the Hermes profile, its config, SOUL, AGENTS rules, skills and kanban data. This cannot be undone.",
	confirmAction: "Fire",
	submitting: "Firing…",
	success: "{name} fired",
	failure: "Could not fire profile",
	blockedDefault: "Default profile cannot be fired."
};
var profileConfig$1 = {
	loadFailed: "Failed to load profile config",
	model: "Model",
	modelHint: "The `model.default` value Hermes resolves through its model registry (e.g. `qwen3.6`, `claude-sonnet-4-5`, `gpt-4-turbo`).",
	modelPlaceholder: "e.g. claude-sonnet-4-5",
	modelSearch: "Search or type a model id…",
	modelCustom: "Use \"{value}\"",
	modelEmpty: "Catalog empty — type any model id.",
	inheritGlobal: "Inherit from global",
	inheritGlobalHint: "Use the provider and model from `~/.hermes/config.yaml`. Toggle off to override per-profile.",
	modelRecommended: "recommended",
	modelFree: "free",
	modelCurrent: "current",
	provider: "Provider",
	providerHint: "Inference provider (`anthropic`, `openai`, `custom`, …). Leave empty to inherit from the global Hermes config.",
	providerPlaceholder: "(global default)",
	allowlist: "Pre-approved dangerous commands",
	allowlistHint: "Commands matching these dangerous-pattern descriptions skip the user-approval prompt. For an orchestrator, leave this EMPTY so things like `python3 -c` get auto-denied.",
	allowlistEmpty: "No pre-approvals — every dangerous command will go through the permission callback (which the war-room denies by default).",
	allowlistRemove: "Remove pre-approval: {entry}",
	allowlistClear: "Clear all"
};
var agents$1 = {
	title: "Behavior rules (AGENTS.md)",
	hintGlobal: "This profile has no local AGENTS.md — you're seeing the global ~/.hermes/AGENTS.md. Saving creates a profile-specific copy that overrides it.",
	hintProfile: "Profile-specific AGENTS.md. Loaded into the agent's system prompt at every turn.",
	hintEmpty: "No rules defined globally or for this profile. Add behavior conventions, dos & don'ts, etc.",
	placeholder: "# Behavior rules\n\n- Never commit without explicit confirmation.\n- Prefer reading before writing.\n- Use plain language for non-technical reports.",
	inheriting: "Inheriting global",
	loadFailed: "Failed to load AGENTS.md"
};
var badge$1 = {
	operativeFile: "Operative File",
	callsign: "Callsign",
	profileId: "Profile ID",
	status: "Status",
	assignCallsign: "Assign callsign",
	unnamed: "— unnamed —",
	primary: "Primary",
	issued: "Issued {date}",
	rolling: "rolling",
	reroll: "reroll",
	callsignAssigned: "Callsign assigned",
	saveFailed: "Save failed",
	rerollFailed: "Reroll failed",
	active: "Active",
	inactive: "Off duty",
	activate: "Activate",
	deactivate: "Deactivate",
	activeUpdated: "Roster updated",
	activeFailed: "Could not update roster",
	gesture: {
		hand: "Standing by",
		handPhone: "On comms",
		ok: "Confirmed",
		okLongarms: "Broadcasting",
		pointLongarms: "Targeting",
		waveLongarms: "Hailing",
		waveOkLongarms: "Coordinating"
	}
};
const locale_en_46json_8a5b453a = {
	app: app$1,
	nav: nav$1,
	common: common$1,
	warRoom: warRoom$1,
	mission: mission$1,
	team: team$1,
	hire: hire$1,
	presets: presets$1,
	skills: skills$1,
	tools: tools$1,
	soul: soul$1,
	mcp: mcp$1,
	retrain: retrain$1,
	rename: rename$1,
	fire: fire$1,
	profileConfig: profileConfig$1,
	agents: agents$1,
	badge: badge$1
};

var app = {
	title: "Sala de Guerra de Orquestación de Hermes",
	description: "Capa de orquestación visual para el sistema de delegación multi-agente de Hermes."
};
var nav = {
	warRoom: "Sala de Operaciones",
	team: "El Equipo",
	missions: "Misiones"
};
var common = {
	rescan: "Reescanear",
	cancel: "Cancelar",
	"default": "predeterminado",
	language: "Idioma",
	manage: "Gestionar",
	done: "Listo",
	forceDispatch: "Forzar dispatching",
	forceDispatchOk: "Dispatching forzado",
	forceDispatchFailed: "No se pudo forzar dispatching"
};
var warRoom = {
	title: "Sala de Operaciones",
	errorTitle: "No se pudieron cargar los perfiles",
	empty: "No se encontraron perfiles de Hermes en {dir}.",
	operativesCount: "sin operativos | 1 operativo | {count} operativos",
	stationLabel: "Puesto {num}",
	operationsFloor: "Sala de Operaciones",
	missionScope: "Ámbito de la misión",
	globalScope: "Todas las tareas",
	scopeToggle: "Ver todas las tareas",
	scopeToggleMission: "Limitar a la misión",
	scopeAll: "Todas las tareas",
	scopeMissingFallback: "(misión fuera de la lista)",
	scopeUntitledMission: "(misión sin título)",
	detail: {
		title: "Expediente del operativo",
		currentTask: "Tarea actual",
		noTask: "Sin tarea activa — en espera.",
		delegatedBy: "Delegada por",
		heartbeat: "Último latido hace {ago}",
		live: "En vivo",
		started: "Iniciada {time}",
		lastSteps: "Pasos recientes",
		noSteps: "Sin actividad capturada todavía.",
		missionThread: "Hilo de misión",
		noMission: "Sin misión en curso.",
		subtasks: "Subtareas",
		noSubtasks: "Sin subtareas adjuntas.",
		taskFeed: "Actividad de la tarea",
		taskFeedLoading: "Cargando conversación…",
		taskFeedNotStarted: "El worker aún no ha arrancado — no hay log file en disco.",
		taskFeedNoSession: "Worker arrancado pero el session ID aún no se ha registrado en el log.",
		taskFeedEmpty: "Aún no hay mensajes registrados.",
		taskFeedReasoning: "Razonamiento",
		taskFeedTotalsTitle: "Entrada: {input} tokens · Salida: {output} tokens",
		taskFeedLog: "Salida del worker",
		taskFeedLogHint: "Mostrando el log crudo del worker — útil cuando state.db aún no ha alcanzado.",
		taskFeedLogSpan: "{from} → {to}",
		taskFeedLastActivity: "última escritura hace {ago}",
		taskFeedLogTruncated: "Mostrando los últimos {bytes} de {total} (truncado).",
		taskFeedLogLoading: "Cargando log completo…",
		taskFeedLogReload: "Recargar",
		taskKill: "Matar tarea",
		taskKillConfirmTitle: "¿Matar la tarea {id}?",
		taskKillConfirmBody: "Termina el proceso del worker (SIGTERM) y archiva la tarea para que desaparezca del tablero activo. Recuperable vía `hermes kanban` si necesitas inspeccionarla después.",
		taskKillConfirmAction: "Matar",
		taskKilling: "Matando…",
		taskKilled: "Tarea matada",
		taskKillFailed: "No se pudo matar la tarea",
		permissionPending: "PERMISO PENDIENTE",
		permissionPendingShort: "PERMISO",
		approveTitle: "Denegación de permiso",
		approveBody: "El worker chocó con el clasificador de permisos de Hermes y fue auto-denegado. Aprueba la etiqueta del patrón peligroso abajo para añadirla al `command_allowlist` de este perfil y reintentar la tarea.",
		approveLabelHint: "Etiqueta exacta como la emite el clasificador de Hermes. Edítala si la sugerencia te parece incorrecta antes de aprobar.",
		approveAction: "Aprobar y reintentar",
		approving: "Aprobando…",
		approveSuccess: "Aprobado y reintentando",
		approveFailed: "No se pudo aprobar",
		approveNoLabel: "No se pudo extraer una etiqueta — escríbela a mano.",
		taskFeedSession: "Sesión",
		taskFeedDuration: "Lleva ejecutándose {duration}",
		tokenInput: "entrada",
		tokenOutput: "salida",
		tokenCacheRead: "caché lectura",
		tokenCacheWrite: "caché escritura",
		tokenCost: "coste"
	},
	history: {
		title: "Archivo de misiones",
		subtitle: "Misiones pasadas, más recientes arriba.",
		empty: "Aún no hay misiones.",
		open: "Abiertas",
		archived: "Archivadas",
		all: "Todas",
		messageCount: "sin mensajes | 1 mensaje | {count} mensajes",
		createdAt: "Iniciada {when}",
		updatedAt: "Última actividad {when}",
		loadFailed: "No se pudieron cargar las misiones",
		page: "Página {current} de {total}",
		prev: "Anterior",
		next: "Siguiente"
	}
};
var mission = {
	title: "Misión",
	send: "Asignar",
	sending: "Asignando…",
	thinking: "{orch} está pensando…",
	newMission: "Nueva misión",
	archived: "Misión archivada",
	failure: "No se pudo contactar con el orquestador",
	orchestrator: "Orquestador",
	orchestratorLabel: "Orquestador encargado:",
	dispatcherWarning: "No se detecta dispatcher. Ejecuta `hermes gateway start` para que los agentes recojan tareas.",
	connectionLost: "Stream interrumpido. Reconectando…",
	idle: "En espera",
	empty: {
		placeholder: "Describe la misión para {orch}…"
	},
	input: {
		followUp: "Responde o ajusta la misión…"
	},
	task: {
		running: "Trabajando en",
		queued: "En cola",
		blocked: "Bloqueada",
		thinking: "Pensando…"
	},
	tabs: {
		chat: "Chat",
		board: "Tablero"
	},
	board: {
		empty: "Sin tareas aquí.",
		boardEmpty: "El tablero está vacío — asigna una misión para empezar.",
		col: {
			todo: "Pendientes",
			ready: "Preparadas",
			running: "En curso",
			blocked: "Bloqueadas"
		},
		started: "empezó hace {ago}",
		waiting: "esperando {ago}",
		completedTitle: "Tareas completadas",
		completedAgo: "completada hace {ago}",
		completedEmpty: "Sin tareas completadas todavía.",
		completedLoading: "Cargando…",
		completedMore: "Cargar más"
	},
	detail: {
		title: "Expediente del operativo",
		currentTask: "Tarea actual",
		noTask: "Sin tarea activa.",
		subtasks: "Tareas delegadas",
		noSubtasks: "Sin delegaciones pendientes.",
		delegatedBy: "Delegado por",
		started: "Iniciada {time}",
		heartbeat: "Heartbeat hace {ago}s",
		openMission: "Abrir misión",
		viewKanban: "Ver en kanban",
		lastSteps: "Actividad reciente",
		noSteps: "Sin actividad reciente.",
		missionThread: "Hilo de la misión",
		noMission: "Sin misión activa para este operativo.",
		live: "En directo"
	}
};
var team = {
	title: "El Equipo",
	errorTitle: "No se pudieron cargar los perfiles",
	empty: "No se encontraron perfiles de Hermes en {dir}.",
	hire: "Contratar"
};
var hire = {
	title: "Alta de operativo",
	subtitle: "Elige un preset, edita el expediente, despliega.",
	presetSection: "Rol",
	presetHint: "Cada preset rellena identidad, reglas, herramientas y habilidades. Puedes ajustar todo antes de contratar.",
	briefingSection: "Briefing",
	capabilitiesSection: "Capacidades",
	nameLabel: "Slug del perfil",
	namePlaceholder: "ej. investigador",
	nameHint: "Solo minúsculas y números — se usa como destinatario de tareas en el kanban.",
	cloneLabel: "Clonar desde",
	clonePlaceholder: "Empezar limpio",
	cloneHint: "Opcional: hereda config.yaml + .env de un perfil existente. La identidad de abajo sobrescribe su SOUL.md.",
	noteAfterCreate: "Los servidores MCP y la autenticación del proveedor se configuran después de crear el perfil.",
	submit: "Contratar",
	submitting: "Contratando…",
	success: "{name} contratado.",
	failure: "No se pudo contratar el perfil"
};
var presets = {
	orchestrator: {
		title: "Orquestador",
		tagline: "Necesitas despacho, enrutado, detección de drift y escalado."
	},
	builder: {
		title: "Constructor",
		tagline: "Necesitas entregar código de producto con tests y build verde."
	},
	reviewer: {
		title: "Revisor",
		tagline: "Necesitas revisión rigurosa y verificación de que el cambio está listo para mergear."
	},
	triage: {
		title: "Triaje",
		tagline: "Necesitas priorizar issues y PRs: puntuarlos, reproducirlos y proponer la siguiente acción."
	},
	lab: {
		title: "Laboratorio",
		tagline: "Necesitas experimentos aislados o benchmarking de modelos locales."
	},
	fetcher: {
		title: "Obtenedor de datos",
		tagline: "Necesitas extraer información pública de la web — búsqueda, scraping, extracción estructurada. Sin análisis."
	},
	sage: {
		title: "Sabio",
		tagline: "Necesitas investigación, síntesis, scripts o copy de lanzamiento."
	},
	scribe: {
		title: "Escriba",
		tagline: "Necesitas docs, specs, handoffs o notas de release."
	},
	foundation: {
		title: "Cimientos",
		tagline: "Necesitas tareas de infra, runtime, reparaciones o ciclo de vida."
	},
	qa: {
		title: "QA",
		tagline: "Necesitas pruebas de regresión, smoke tests y verificación de comportamiento esperado vs. real."
	},
	mirror: {
		title: "Espejo de integraciones",
		tagline: "Necesitas sincronización con upstream, integraciones o packs de assets."
	},
	custom: {
		title: "Personalizado",
		tagline: "Estás creando un rol que no encaja con los presets existentes."
	}
};
var skills = {
	title: "Habilidades",
	loading: "Cargando habilidades…",
	loadFailed: "No se pudieron cargar las habilidades",
	empty: "No hay habilidades disponibles.",
	search: "Buscar habilidades…",
	selectAll: "Habilitar todas",
	selectNone: "Deshabilitar todas",
	selected: "{count} de {total} habilitadas",
	uncategorized: "Otras",
	sourceBuiltin: "Integrada",
	sourceGlobal: "Global",
	sourceProfile: "Local"
};
var tools = {
	title: "Herramientas",
	loading: "Cargando herramientas…",
	loadFailed: "No se pudieron cargar las herramientas",
	empty: "No hay herramientas disponibles.",
	search: "Buscar herramientas…",
	selectAll: "Habilitar todas",
	selectNone: "Deshabilitar todas",
	selected: "{count} de {total} habilitadas"
};
var soul = {
	title: "Identidad",
	hint: "Markdown libre que se guarda en SOUL.md dentro del perfil. Define quién es el agente y qué hace.",
	placeholder: "# Quién eres\n\n_No eres un chatbot. Estás convirtiéndote en alguien._\n\n¿Quién soy?\n\n- **Nombre:**\n- **Rol:**\n- **Estilo:**",
	loadFailed: "No se pudo cargar SOUL.md"
};
var mcp = {
	title: "Servidores MCP",
	hint: "Fuentes remotas de herramientas conectadas a este perfil. Los servidores que fallan ralentizan el arranque en frío (3 reintentos, ~7s perdidos) — quita los que este perfil no use.",
	loading: "Cargando servidores MCP…",
	loadFailed: "No se pudieron cargar los servidores MCP",
	empty: "Este perfil no tiene servidores MCP configurados.",
	remove: "Quitar",
	removed: "{name} eliminado",
	removeFailed: "No se pudo eliminar el servidor MCP",
	confirmRemove: "¿Quitar el servidor MCP \"{name}\" de este perfil? Para volver a añadirlo hace falta el CLI de Hermes.",
	headers: "sin cabeceras | 1 cabecera | {count} cabeceras",
	headersTooltip: "Número de cabeceras HTTP configuradas (probablemente tokens de auth). Los valores no se muestran.",
	transport: {
		http: "HTTP",
		stdio: "stdio",
		unknown: "desconocido"
	}
};
var retrain = {
	action: "Reentrenar",
	title: "Reentrenar a {name}",
	subtitle: "Identidad y reglas a la izquierda, herramientas y conocimiento a la derecha. Guarda cuando termines.",
	submit: "Guardar",
	submitting: "Guardando…",
	success: "Perfil actualizado",
	failure: "No se pudo actualizar el perfil",
	identitySection: "Identidad y reglas",
	capabilitiesSection: "Capacidades"
};
var rename = {
	label: "Slug del perfil",
	help: "Letras minúsculas y números. Renombra el perfil de Hermes y redirige a los workers al nuevo identificador.",
	blockedDefault: "El perfil por defecto no se puede renombrar.",
	invalid: "El slug solo puede contener letras minúsculas y números.",
	renaming: "Renombrando…",
	success: "Renombrado a {slug}",
	failure: "No se pudo renombrar el perfil"
};
var fire = {
	action: "Despedir",
	confirmTitle: "¿Despedir a {name}?",
	confirmBody: "Eliminará permanentemente el perfil de Hermes, su configuración, SOUL, reglas AGENTS, skills y datos de kanban. No se puede deshacer.",
	confirmAction: "Despedir",
	submitting: "Despidiendo…",
	success: "{name} despedido",
	failure: "No se pudo despedir al operativo",
	blockedDefault: "El perfil por defecto no se puede despedir."
};
var profileConfig = {
	loadFailed: "No se pudo cargar la configuración del perfil",
	model: "Modelo",
	modelHint: "El `model.default` que Hermes resuelve por su registry de modelos (ej. `qwen3.6`, `claude-sonnet-4-5`, `gpt-4-turbo`).",
	modelPlaceholder: "ej. claude-sonnet-4-5",
	modelSearch: "Buscar o escribir un id de modelo…",
	modelCustom: "Usar \"{value}\"",
	modelEmpty: "Catálogo vacío — escribe cualquier id de modelo.",
	inheritGlobal: "Heredar global",
	inheritGlobalHint: "Usa el proveedor y modelo de `~/.hermes/config.yaml`. Desactiva para sobrescribir por perfil.",
	modelRecommended: "recomendado",
	modelFree: "gratis",
	modelCurrent: "actual",
	provider: "Proveedor",
	providerHint: "Proveedor de inferencia (`anthropic`, `openai`, `custom`, …). Déjalo vacío para heredar del config global de Hermes.",
	providerPlaceholder: "(global de Hermes)",
	allowlist: "Comandos peligrosos pre-aprobados",
	allowlistHint: "Los comandos que coincidan con estas descripciones de patrones peligrosos saltan el prompt de aprobación del usuario. Para un orquestador, déjalo VACÍO para que cosas como `python3 -c` se denieguen automáticamente.",
	allowlistEmpty: "Sin pre-aprobaciones — cada comando peligroso pasará por el callback de permisos (que el war-room deniega por defecto).",
	allowlistRemove: "Quitar pre-aprobación: {entry}",
	allowlistClear: "Borrar todo"
};
var agents = {
	title: "Reglas de comportamiento (AGENTS.md)",
	hintGlobal: "Este perfil no tiene AGENTS.md local — estás viendo el global de ~/.hermes/AGENTS.md. Al guardar se creará una copia específica para este perfil que sobrescribe el global.",
	hintProfile: "AGENTS.md específico del perfil. Se inyecta en el system prompt en cada turno.",
	hintEmpty: "No hay reglas definidas ni globales ni para este perfil. Añade convenciones, qué hacer y qué evitar, etc.",
	placeholder: "# Reglas de comportamiento\n\n- Nunca hacer commit sin confirmación explícita.\n- Leer antes de escribir.\n- Usar lenguaje claro en informes no técnicos.",
	inheriting: "Heredando global",
	loadFailed: "No se pudo cargar AGENTS.md"
};
var badge = {
	operativeFile: "Expediente Operativo",
	callsign: "Nombre",
	profileId: "ID de perfil",
	status: "Estado",
	assignCallsign: "Asignar Nombre",
	unnamed: "— sin nombre —",
	primary: "Principal",
	issued: "Emitido {date}",
	rolling: "recreando",
	reroll: "recrear",
	callsignAssigned: "Nombre asignado",
	saveFailed: "Error al guardar",
	rerollFailed: "Error al recrear",
	active: "Activo",
	inactive: "Fuera de servicio",
	activate: "Activar",
	deactivate: "Desactivar",
	activeUpdated: "Roster actualizado",
	activeFailed: "No se pudo actualizar el roster",
	gesture: {
		hand: "En espera",
		handPhone: "En comunicación",
		ok: "Confirmado",
		okLongarms: "Emitiendo",
		pointLongarms: "Apuntando",
		waveLongarms: "Saludando",
		waveOkLongarms: "Coordinando"
	}
};
const locale_es_46json_d4d26b01 = {
	app: app,
	nav: nav,
	common: common,
	warRoom: warRoom,
	mission: mission,
	team: team,
	hire: hire,
	presets: presets,
	skills: skills,
	tools: tools,
	soul: soul,
	mcp: mcp,
	retrain: retrain,
	rename: rename,
	fire: fire,
	profileConfig: profileConfig,
	agents: agents,
	badge: badge
};

// @ts-nocheck
const localeCodes =  [
  "en",
  "es"
];
const localeLoaders = {
  en: [
    {
      key: "locale_en_46json_8a5b453a",
      load: () => Promise.resolve(locale_en_46json_8a5b453a),
      cache: true
    }
  ],
  es: [
    {
      key: "locale_es_46json_d4d26b01",
      load: () => Promise.resolve(locale_es_46json_d4d26b01),
      cache: true
    }
  ]
};
const vueI18nConfigs = [];
const normalizedLocales = [
  {
    code: "en",
    name: "English",
    language: undefined
  },
  {
    code: "es",
    name: "Español",
    language: undefined
  }
];

const setupVueI18nOptions = async (defaultLocale) => {
  const options = await loadVueI18nOptions(vueI18nConfigs);
  options.locale = defaultLocale || options.locale || "en-US";
  options.defaultLocale = defaultLocale;
  options.fallbackLocale ??= false;
  options.messages ??= {};
  for (const locale of localeCodes) {
    options.messages[locale] ??= {};
  }
  return options;
};

function defineNitroPlugin(def) {
  return def;
}

function defineRenderHandler(render) {
  const runtimeConfig = useRuntimeConfig();
  return eventHandler(async (event) => {
    const nitroApp = useNitroApp();
    const ctx = { event, render, response: void 0 };
    await nitroApp.hooks.callHook("render:before", ctx);
    if (!ctx.response) {
      if (event.path === `${runtimeConfig.app.baseURL}favicon.ico`) {
        setResponseHeader(event, "Content-Type", "image/x-icon");
        return send(
          event,
          "data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7"
        );
      }
      ctx.response = await ctx.render(event);
      if (!ctx.response) {
        const _currentStatus = getResponseStatus(event);
        setResponseStatus(event, _currentStatus === 200 ? 500 : _currentStatus);
        return send(
          event,
          "No response returned from render handler: " + event.path
        );
      }
    }
    await nitroApp.hooks.callHook("render:response", ctx.response, ctx);
    if (ctx.response.headers) {
      setResponseHeaders(event, ctx.response.headers);
    }
    if (ctx.response.statusCode || ctx.response.statusMessage) {
      setResponseStatus(
        event,
        ctx.response.statusCode,
        ctx.response.statusMessage
      );
    }
    return ctx.response.body;
  });
}

function baseURL() {
	// TODO: support passing event to `useRuntimeConfig`
	return useRuntimeConfig().app.baseURL;
}
function buildAssetsDir() {
	// TODO: support passing event to `useRuntimeConfig`
	return useRuntimeConfig().app.buildAssetsDir;
}
function buildAssetsURL(...path) {
	return joinRelativeURL(publicAssetsURL(), buildAssetsDir(), ...path);
}
function publicAssetsURL(...path) {
	// TODO: support passing event to `useRuntimeConfig`
	const app = useRuntimeConfig().app;
	const publicBase = app.cdnURL || app.baseURL;
	return path.length ? joinRelativeURL(publicBase, ...path) : publicBase;
}

function parseAcceptLanguage(value) {
  return value.split(",").map((tag) => tag.split(";")[0]).filter(
    (tag) => !(tag === "*" || tag === "")
  );
}
function createPathIndexLanguageParser(index = 0) {
  return (path) => {
    const rawPath = typeof path === "string" ? path : path.pathname;
    const normalizedPath = rawPath.split("?")[0];
    const parts = normalizedPath.split("/");
    if (parts[0] === "") {
      parts.shift();
    }
    return parts.length > index ? parts[index] || "" : "";
  };
}

const AGENTS_FILENAME = "AGENTS.md";
const AGENTS_MAX_BYTES = 64 * 1024;
const HERMES_HOME$7 = process.env.HERMES_HOME || join(homedir(), ".hermes");
const GLOBAL_AGENTS_PATH = join(HERMES_HOME$7, AGENTS_FILENAME);
function profilePath(profileDir) {
  return join(profileDir, AGENTS_FILENAME);
}
function readAgents(profileDir) {
  const local = profilePath(profileDir);
  if (existsSync(local)) {
    return { content: readFileSync(local, "utf8"), source: "profile" };
  }
  if (existsSync(GLOBAL_AGENTS_PATH)) {
    return { content: readFileSync(GLOBAL_AGENTS_PATH, "utf8"), source: "global" };
  }
  return { content: "", source: "empty" };
}
function writeAgents(profileDir, contents) {
  if (Buffer.byteLength(contents, "utf8") > AGENTS_MAX_BYTES) {
    throw new Error(`AGENTS.md too large (max ${AGENTS_MAX_BYTES} bytes)`);
  }
  const path = profilePath(profileDir);
  const tmp = `${path}.tmp-${process.pid}-${Date.now()}`;
  try {
    writeFileSync(tmp, contents, { mode: 384 });
    renameSync(tmp, path);
  } catch (e) {
    try {
      unlinkSync(tmp);
    } catch {
    }
    throw e;
  }
}
const MANAGED_BEGIN = "<!-- WAR-ROOM-MANAGED:BEGIN \u2014 do not edit between markers, regenerated on roster sync -->";
const MANAGED_END = "<!-- WAR-ROOM-MANAGED:END -->";
const MANAGED_BLOCK_BODY = `## War Room rule

Never embed bulk data (long lists, file contents, datasets, full reports) as literals inside a tool call argument. Write them to a file in \`$HERMES_KANBAN_WORKSPACE\` and have the tool read from that path.

For \`kanban_complete\` / \`kanban_block\` / \`kanban_comment\`:
- \`summary\` / \`reason\` / \`body\`: \u2264500 chars. Reference workspace files by path for detail.
- \`metadata\`: \u2264500 chars total. Compact structured handoff only \u2014 ids, counts, file paths, booleans, short enum-like labels. Never put prose, per-item summaries, full reports, or repeated content in \`metadata\` \u2014 those go in workspace files; \`metadata\` only carries the path and minimal counts.

Inlining bulk data exhausts the output token budget, truncates the tool call, and the task fails.`;
const MANAGED_BLOCK = `${MANAGED_BEGIN}
${MANAGED_BLOCK_BODY}
${MANAGED_END}`;
const MANAGED_BLOCK_RE = new RegExp(
  `${MANAGED_BEGIN.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}[\\s\\S]*?${MANAGED_END.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}`,
  "g"
);
function syncManagedAgentsBlock(profileDir) {
  const path = profilePath(profileDir);
  const existing = existsSync(path) ? readFileSync(path, "utf8") : "";
  let next;
  if (MANAGED_BLOCK_RE.test(existing)) {
    MANAGED_BLOCK_RE.lastIndex = 0;
    next = existing.replace(MANAGED_BLOCK_RE, MANAGED_BLOCK);
  } else if (existing.trim().length === 0) {
    next = `${MANAGED_BLOCK}
`;
  } else {
    const sep = existing.endsWith("\n") ? "\n" : "\n\n";
    next = `${existing}${sep}${MANAGED_BLOCK}
`;
  }
  if (next === existing) return;
  if (Buffer.byteLength(next, "utf8") > AGENTS_MAX_BYTES) {
    throw new Error(`AGENTS.md too large after managed block update (max ${AGENTS_MAX_BYTES} bytes)`);
  }
  const tmp = `${path}.tmp-${process.pid}-${Date.now()}`;
  try {
    writeFileSync(tmp, next, { mode: 384 });
    renameSync(tmp, path);
  } catch (e) {
    try {
      unlinkSync(tmp);
    } catch {
    }
    throw e;
  }
}

function getFailureContext(taskId) {
  var _a, _b, _c, _d;
  const empty = {
    lastComment: null,
    taskResult: null,
    lastRunOutcome: null,
    lastRunError: null,
    spawnFailures: 0
  };
  const db = getKanbanDb();
  if (!db) return empty;
  try {
    const task = db.prepare(
      `SELECT result, spawn_failures FROM tasks WHERE id = ?`
    ).get(taskId);
    const comment = db.prepare(
      `SELECT author, body FROM task_comments WHERE task_id = ?
       ORDER BY created_at DESC LIMIT 1`
    ).get(taskId);
    const run = db.prepare(
      `SELECT outcome, error FROM task_runs WHERE task_id = ?
       ORDER BY started_at DESC LIMIT 1`
    ).get(taskId);
    return {
      lastComment: comment != null ? comment : null,
      taskResult: (_a = task == null ? void 0 : task.result) != null ? _a : null,
      lastRunOutcome: (_b = run == null ? void 0 : run.outcome) != null ? _b : null,
      lastRunError: (_c = run == null ? void 0 : run.error) != null ? _c : null,
      spawnFailures: (_d = task == null ? void 0 : task.spawn_failures) != null ? _d : 0
    };
  } catch {
    return empty;
  }
}
function distillReason(ctx) {
  var _a;
  if ((_a = ctx.lastComment) == null ? void 0 : _a.body) {
    return ctx.lastComment.body.trim().replace(/\s+/g, " ").slice(0, 600);
  }
  if (ctx.lastRunError) {
    return ctx.lastRunError.trim().replace(/\s+/g, " ").slice(0, 600);
  }
  if (ctx.taskResult) {
    return ctx.taskResult.trim().replace(/\s+/g, " ").slice(0, 600);
  }
  if (ctx.lastRunOutcome && ctx.lastRunOutcome !== "completed") {
    return `worker run outcome: ${ctx.lastRunOutcome}`;
  }
  return "";
}

const PERMISSION_KEYWORDS = /\b(permission|approval|auto[\s-]*deny|denied|consent[\s-]*required|requires? approval)\b/i;
function looksLikePermissionDenial(reason) {
  return !!reason && PERMISSION_KEYWORDS.test(reason);
}
function extractPermissionLabel(reason) {
  var _a;
  if (!reason) return null;
  const text = reason.trim();
  if (!text) return null;
  const patterns = [
    /(?:permission\s+denied|auto[\s-]*deny(?:ied)?|tool\s+call\s+denied|approval\s+denied|access\s+denied)\s*[:—–-]\s*(.+?)\s*(?:\([^)]*\))?\s*$/i,
    /^(?:permission|approval|auto[\s-]*deny)\s*[:—–-]\s*(.+?)\s*(?:\([^)]*\))?\s*$/i,
    /(.+?)\s*\((?:denied|auto-deny|once|session|always)\)\s*$/i
  ];
  for (const re of patterns) {
    const m = text.match(re);
    if (m && m[1]) {
      const label = m[1].trim().replace(/[.;,]+$/, "").trim();
      if (label && !PERMISSION_KEYWORDS.test((_a = label.split(/\s+/)[0]) != null ? _a : "")) return label;
    }
  }
  if (text.length <= 120 && !/[.!?]/.test(text) && text.split(/\s+/).length <= 16) {
    return text;
  }
  return null;
}

const HERMES_HOME$6 = process.env.HERMES_HOME || join(homedir(), ".hermes");
const KANBAN_DB_PATH = join(HERMES_HOME$6, "kanban.db");
let cached$1 = null;
function getKanbanDb() {
  if (cached$1) return cached$1;
  if (!existsSync(KANBAN_DB_PATH)) return null;
  const db = new DatabaseSync(KANBAN_DB_PATH, { readOnly: true });
  cached$1 = db;
  return db;
}
function rowToTask(r) {
  return {
    id: r.id,
    title: r.title,
    body: r.body,
    assignee: r.assignee,
    status: r.status,
    priority: r.priority,
    workerPid: r.worker_pid,
    startedAt: r.started_at,
    claimExpires: r.claim_expires,
    lastHeartbeatAt: r.last_heartbeat_at,
    createdAt: r.created_at,
    parentIds: []
  };
}
const ACTIVE_STATUSES = ["running", "ready", "todo", "blocked"];
function listActiveTasks(assignee) {
  var _a;
  const db = getKanbanDb();
  if (!db) return [];
  const placeholders = ACTIVE_STATUSES.map(() => "?").join(",");
  const params = [...ACTIVE_STATUSES];
  let where = `status IN (${placeholders})`;
  if (assignee) {
    where += " AND assignee = ?";
    params.push(assignee);
  }
  const rows = db.prepare(
    `SELECT id, title, body, assignee, status, priority,
            worker_pid, started_at, claim_expires, last_heartbeat_at, created_at
     FROM tasks
     WHERE ${where}
     ORDER BY
       CASE status WHEN 'running' THEN 0 WHEN 'blocked' THEN 1 WHEN 'ready' THEN 2 ELSE 3 END,
       priority DESC,
       created_at ASC`
  ).all(...params);
  const tasks = rows.map(rowToTask);
  if (tasks.length > 0) {
    const ids = tasks.map((t) => t.id);
    const placeholdersIds = ids.map(() => "?").join(",");
    const links = db.prepare(
      `SELECT parent_id, child_id FROM task_links WHERE child_id IN (${placeholdersIds})`
    ).all(...ids);
    const byChild = /* @__PURE__ */ new Map();
    for (const l of links) {
      const arr = (_a = byChild.get(l.child_id)) != null ? _a : [];
      arr.push(l.parent_id);
      byChild.set(l.child_id, arr);
    }
    for (const t of tasks) {
      const parents = byChild.get(t.id);
      if (parents) t.parentIds = parents;
    }
  }
  const blocked = tasks.filter((t) => t.status === "blocked");
  for (const t of blocked) {
    const ctx = getFailureContext(t.id);
    const reason = distillReason(ctx);
    if (looksLikePermissionDenial(reason)) t.pendingPermission = true;
  }
  return tasks;
}
function tasksCreatedSince(unixSec) {
  const db = getKanbanDb();
  if (!db) return [];
  const rows = db.prepare(
    `SELECT id, title, body, assignee, status, priority,
            worker_pid, started_at, claim_expires, last_heartbeat_at, created_at
     FROM tasks
     WHERE created_at > ?
     ORDER BY created_at ASC`
  ).all(unixSec);
  return rows.map(rowToTask);
}
const COMPLETED_STATUSES = ["done", "archived"];
const HISTORY_DEFAULT_LIMIT = 20;
const HISTORY_MAX_LIMIT = 100;
function listCompletedTasks(opts = {}) {
  var _a;
  const db = getKanbanDb();
  if (!db) return [];
  const limit = Math.max(1, Math.min((_a = opts.limit) != null ? _a : HISTORY_DEFAULT_LIMIT, HISTORY_MAX_LIMIT));
  const params = [...COMPLETED_STATUSES];
  let where = `status IN (${COMPLETED_STATUSES.map(() => "?").join(",")})`;
  if (opts.assignee) {
    where += " AND assignee = ?";
    params.push(opts.assignee);
  }
  if (typeof opts.before === "number" && Number.isFinite(opts.before)) {
    where += " AND COALESCE(completed_at, created_at) < ?";
    params.push(Math.floor(opts.before));
  }
  const rows = db.prepare(
    `SELECT id, title, body, assignee, status, priority,
            created_at, started_at, completed_at
     FROM tasks
     WHERE ${where}
     ORDER BY COALESCE(completed_at, created_at) DESC, id DESC
     LIMIT ?`
  ).all(...params, limit);
  return rows.map((r) => ({
    id: r.id,
    title: r.title,
    body: r.body,
    assignee: r.assignee,
    status: r.status,
    priority: r.priority,
    createdAt: r.created_at,
    startedAt: r.started_at,
    completedAt: r.completed_at
  }));
}
const STALE_READY_AGE_S = 5 * 60;
function dispatcherLikelyStale() {
  var _a;
  const db = getKanbanDb();
  if (!db) return false;
  const now = Math.floor(Date.now() / 1e3);
  const cutoff = now - STALE_READY_AGE_S;
  const row = db.prepare(
    `SELECT COUNT(*) as count FROM tasks
     WHERE status = 'ready' AND created_at < ?`
  ).get(cutoff);
  return ((_a = row == null ? void 0 : row.count) != null ? _a : 0) > 0;
}

let cached = null;
function useDb() {
  if (cached) return cached;
  const dbPath = resolve$1(process.cwd(), "data/war-room.db");
  mkdirSync(dirname$1(dbPath), { recursive: true });
  const db = new DatabaseSync(dbPath);
  db.exec("PRAGMA journal_mode = WAL;");
  db.exec(`
    CREATE TABLE IF NOT EXISTS profiles (
      slug              TEXT PRIMARY KEY,
      display_name      TEXT NOT NULL,
      is_default        INTEGER NOT NULL DEFAULT 0,
      hermes_dir        TEXT NOT NULL,
      avatar_seed       TEXT NOT NULL,
      background_color  TEXT NOT NULL,
      gesture           TEXT NOT NULL DEFAULT 'hand',
      first_seen        TEXT NOT NULL,
      last_seen         TEXT NOT NULL
    );
  `);
  const cols = db.prepare("PRAGMA table_info(profiles)").all();
  const colNames = new Set(cols.map((c) => c.name));
  if (!colNames.has("given_name")) {
    db.exec("ALTER TABLE profiles ADD COLUMN given_name TEXT;");
  }
  if (!colNames.has("present")) {
    db.exec("ALTER TABLE profiles ADD COLUMN present INTEGER NOT NULL DEFAULT 1;");
  }
  if (!colNames.has("active")) {
    db.exec("ALTER TABLE profiles ADD COLUMN active INTEGER NOT NULL DEFAULT 1;");
  }
  db.exec(`
    CREATE TABLE IF NOT EXISTS missions (
      id                 TEXT PRIMARY KEY,
      orchestrator_slug  TEXT NOT NULL,
      acp_session_id     TEXT,
      title              TEXT,
      status             TEXT NOT NULL DEFAULT 'open',
      created_at         TEXT NOT NULL,
      last_message_at    TEXT NOT NULL
    );
  `);
  db.exec(`
    CREATE TABLE IF NOT EXISTS mission_messages (
      id          INTEGER PRIMARY KEY AUTOINCREMENT,
      mission_id  TEXT NOT NULL REFERENCES missions(id) ON DELETE CASCADE,
      role        TEXT NOT NULL,
      content     TEXT NOT NULL,
      created_at  TEXT NOT NULL
    );
  `);
  db.exec(`
    CREATE INDEX IF NOT EXISTS idx_mission_messages_mission
      ON mission_messages(mission_id, id);
  `);
  db.exec(`
    CREATE INDEX IF NOT EXISTS idx_missions_active
      ON missions(orchestrator_slug, status, last_message_at);
  `);
  db.exec(`
    CREATE TABLE IF NOT EXISTS mission_watched_tasks (
      mission_id    TEXT NOT NULL,
      task_id       TEXT NOT NULL,
      added_status  TEXT NOT NULL,
      added_at      INTEGER NOT NULL,
      notified_at   INTEGER,
      PRIMARY KEY (mission_id, task_id)
    );
  `);
  db.exec(`
    CREATE INDEX IF NOT EXISTS idx_watched_pending
      ON mission_watched_tasks(notified_at, mission_id);
  `);
  cached = db;
  return db;
}

const TITLE_MAX_LEN = 80;
function summarizeTitle(text) {
  const trimmed = text.replace(/\s+/g, " ").trim();
  return trimmed.length > TITLE_MAX_LEN ? trimmed.slice(0, TITLE_MAX_LEN - 1) + "\u2026" : trimmed;
}
function getActiveMission(orchestratorSlug) {
  const db = useDb();
  const row = db.prepare(
    `SELECT * FROM missions
     WHERE orchestrator_slug = ? AND status = 'open'
     ORDER BY last_message_at DESC
     LIMIT 1`
  ).get(orchestratorSlug);
  return row != null ? row : null;
}
function getMission(id) {
  const db = useDb();
  const row = db.prepare("SELECT * FROM missions WHERE id = ?").get(id);
  return row != null ? row : null;
}
function listMessages(missionId) {
  const db = useDb();
  return db.prepare(
    "SELECT * FROM mission_messages WHERE mission_id = ? ORDER BY id ASC"
  ).all(missionId);
}
function createMission(orchestratorSlug, firstMessage) {
  const db = useDb();
  const id = randomUUID();
  const now = (/* @__PURE__ */ new Date()).toISOString();
  const title = summarizeTitle(firstMessage);
  const orphans = db.prepare(`SELECT id FROM missions WHERE orchestrator_slug = ? AND status = 'open'`).all(orchestratorSlug);
  if (orphans.length > 0) {
    db.prepare(
      `UPDATE missions SET status = 'archived' WHERE orchestrator_slug = ? AND status = 'open'`
    ).run(orchestratorSlug);
    const ids = orphans.map((o) => o.id);
    const placeholders = ids.map(() => "?").join(",");
    db.prepare(
      `DELETE FROM mission_watched_tasks WHERE mission_id IN (${placeholders})`
    ).run(...ids);
  }
  db.prepare(
    `INSERT INTO missions (id, orchestrator_slug, title, status, created_at, last_message_at)
     VALUES (?, ?, ?, 'open', ?, ?)`
  ).run(id, orchestratorSlug, title, now, now);
  return getMission(id);
}
function setAcpSessionId(id, acpSessionId) {
  const db = useDb();
  db.prepare("UPDATE missions SET acp_session_id = ? WHERE id = ?").run(acpSessionId, id);
}
function appendMessage(missionId, role, content) {
  const db = useDb();
  const now = (/* @__PURE__ */ new Date()).toISOString();
  const result = db.prepare(
    `INSERT INTO mission_messages (mission_id, role, content, created_at)
     VALUES (?, ?, ?, ?)`
  ).run(missionId, role, content, now);
  db.prepare("UPDATE missions SET last_message_at = ? WHERE id = ?").run(now, missionId);
  const insertedId = Number(result.lastInsertRowid);
  return {
    id: insertedId,
    mission_id: missionId,
    role,
    content,
    created_at: now
  };
}
function updateMessage(messageId, content) {
  const db = useDb();
  db.prepare("UPDATE mission_messages SET content = ? WHERE id = ?").run(content, messageId);
}
function archiveMission(id) {
  const db = useDb();
  db.prepare(`UPDATE missions SET status = 'archived' WHERE id = ?`).run(id);
}
function listMissions(opts = {}) {
  var _a, _b;
  const db = useDb();
  const conds = [];
  const params = [];
  if (opts.status) {
    conds.push("status = ?");
    params.push(opts.status);
  }
  if (opts.orchestratorSlug) {
    conds.push("orchestrator_slug = ?");
    params.push(opts.orchestratorSlug);
  }
  const where = conds.length ? `WHERE ${conds.join(" AND ")}` : "";
  const limit = Math.max(1, Math.min((_a = opts.limit) != null ? _a : 50, 200));
  const offset = Math.max(0, (_b = opts.offset) != null ? _b : 0);
  return db.prepare(
    `SELECT * FROM missions ${where}
     ORDER BY last_message_at DESC
     LIMIT ? OFFSET ?`
  ).all(...params, limit, offset);
}
function countMissions(opts = {}) {
  const db = useDb();
  const conds = [];
  const params = [];
  if (opts.status) {
    conds.push("status = ?");
    params.push(opts.status);
  }
  if (opts.orchestratorSlug) {
    conds.push("orchestrator_slug = ?");
    params.push(opts.orchestratorSlug);
  }
  const where = conds.length ? `WHERE ${conds.join(" AND ")}` : "";
  return db.prepare(`SELECT COUNT(*) as c FROM missions ${where}`).get(...params).c;
}

const queues = /* @__PURE__ */ new Map();
function withMissionLock(missionId, fn) {
  var _a;
  const prev = (_a = queues.get(missionId)) != null ? _a : Promise.resolve();
  const next = prev.then(() => fn(), () => fn());
  queues.set(missionId, next.catch(() => void 0));
  return next;
}

var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => __defNormalProp(obj, key + "" , value);
function fixupRawIO() {
  let buffer = "";
  return new Transform({
    transform(chunk, _enc, cb) {
      var _a;
      buffer += chunk.toString("utf8");
      let nl = buffer.indexOf("\n");
      while (nl >= 0) {
        const line = buffer.slice(0, nl);
        buffer = buffer.slice(nl + 1);
        try {
          const obj = JSON.parse(line);
          const update = (_a = obj == null ? void 0 : obj.params) == null ? void 0 : _a.update;
          if (update) {
            for (const key of ["rawInput", "rawOutput"]) {
              const v = update[key];
              if (typeof v === "string") {
                try {
                  const parsed = JSON.parse(v);
                  update[key] = parsed && typeof parsed === "object" && !Array.isArray(parsed) ? parsed : { value: parsed };
                } catch {
                  update[key] = { raw: v };
                }
              }
            }
          }
          this.push(JSON.stringify(obj) + "\n");
        } catch {
          this.push(line + "\n");
        }
        nl = buffer.indexOf("\n");
      }
      cb();
    },
    flush(cb) {
      if (buffer.length > 0) this.push(buffer);
      cb();
    }
  });
}
const IDLE_TIMEOUT_MS = Number(process.env.WARROOM_ACP_IDLE_MS) || 60 * 60 * 1e3;
const REAPER_INTERVAL_MS = 60 * 1e3;
const pool = /* @__PURE__ */ new Map();
class WarRoomClient {
  constructor(slug) {
    __publicField(this, "slug", slug);
  }
  async sessionUpdate(params) {
    const entry = pool.get(this.slug);
    if (!entry) return;
    entry.lastActivityMs = Date.now();
    const emitter = entry.sessionEmitters.get(params.sessionId);
    if (emitter) emitter.emit("update", params);
  }
  async requestPermission(_params) {
    return { outcome: { outcome: "cancelled" } };
  }
}
function spawnEntry(slug) {
  return new Promise((resolveEntry, rejectEntry) => {
    var _a, _b;
    const TOOLSETS = "terminal,skills,todo,memory,clarify,messaging";
    const child = spawn(
      "hermes",
      ["-p", slug, "--skills", "team-roster", "-t", TOOLSETS, "acp"],
      {
        stdio: ["pipe", "pipe", "pipe"],
        env: process.env
      }
    );
    (_a = child.stderr) == null ? void 0 : _a.setEncoding("utf8");
    (_b = child.stderr) == null ? void 0 : _b.on("data", (d) => {
      process.stderr.write(`[acp:${slug}] ${d}`);
    });
    let exited = false;
    child.on("error", (err) => {
      console.error(`[acp:${slug}] spawn error:`, err);
      pool.delete(slug);
      if (!exited) rejectEntry(err);
    });
    child.on("exit", (code, signal) => {
      exited = true;
      console.error(`[acp:${slug}] exited code=${code} signal=${signal}`);
      pool.delete(slug);
    });
    if (!child.stdin || !child.stdout) {
      child.kill("SIGKILL");
      rejectEntry(new Error("hermes acp spawned without stdio pipes"));
      return;
    }
    const repaired = child.stdout.pipe(fixupRawIO());
    const input = Readable.toWeb(repaired);
    const output = Writable.toWeb(child.stdin);
    const stream = ndJsonStream(output, input);
    const client = new WarRoomClient(slug);
    const conn = new ClientSideConnection(() => client, stream);
    const entry = {
      slug,
      child,
      conn,
      initialized: false,
      sessionEmitters: /* @__PURE__ */ new Map(),
      inFlight: /* @__PURE__ */ new Set(),
      lastActivityMs: Date.now()
    };
    pool.set(slug, entry);
    conn.initialize({
      protocolVersion: PROTOCOL_VERSION,
      clientCapabilities: {
        fs: { readTextFile: false, writeTextFile: false },
        terminal: false
      }
    }).then(() => {
      entry.initialized = true;
      resolveEntry(entry);
    }).catch((err) => {
      try {
        child.kill("SIGTERM");
      } catch {
      }
      pool.delete(slug);
      rejectEntry(err);
    });
  });
}
async function getEntry(slug) {
  const existing = pool.get(slug);
  if (existing && !existing.child.killed && existing.initialized) {
    existing.lastActivityMs = Date.now();
    return existing;
  }
  if (existing) pool.delete(slug);
  return spawnEntry(slug);
}
function defaultCwd() {
  return process.env.HERMES_HOME || homedir();
}
function restart(slug) {
  const entry = pool.get(slug);
  if (!entry) return { killed: false };
  try {
    entry.child.kill("SIGTERM");
  } catch {
  }
  pool.delete(slug);
  return { killed: true };
}
async function warmup(slug) {
  const existing = pool.get(slug);
  if ((existing == null ? void 0 : existing.initialized) && !existing.child.killed) {
    existing.lastActivityMs = Date.now();
    return { alreadyWarm: true };
  }
  await getEntry(slug);
  return { alreadyWarm: false };
}
async function newSession(slug, cwd) {
  const entry = await getEntry(slug);
  const res = await entry.conn.newSession({
    mcpServers: [],
    cwd: cwd != null ? cwd : defaultCwd()
  });
  return res.sessionId;
}
async function loadSession(slug, sessionId, cwd) {
  const entry = await getEntry(slug);
  await entry.conn.loadSession({
    sessionId,
    mcpServers: [],
    cwd: cwd != null ? cwd : defaultCwd()
  });
}
function startPrompt(opts) {
  const emitter = new EventEmitter();
  const done = (async () => {
    const entry = await getEntry(opts.slug);
    if (entry.inFlight.has(opts.sessionId)) {
      throw new Error(`Session ${opts.sessionId} already has a prompt in flight`);
    }
    entry.inFlight.add(opts.sessionId);
    entry.sessionEmitters.set(opts.sessionId, emitter);
    entry.lastActivityMs = Date.now();
    try {
      const res = await entry.conn.prompt({
        sessionId: opts.sessionId,
        prompt: [{ type: "text", text: opts.text }]
      });
      const stopReason = res.stopReason;
      emitter.emit("done", { stopReason });
      return { stopReason };
    } catch (e) {
      emitter.emit("error", e);
      throw e;
    } finally {
      entry.inFlight.delete(opts.sessionId);
      entry.sessionEmitters.delete(opts.sessionId);
      entry.lastActivityMs = Date.now();
    }
  })();
  done.catch(() => {
  });
  return {
    emitter,
    done,
    cancel: async () => {
      const entry = pool.get(opts.slug);
      if (!entry) return;
      await entry.conn.cancel({ sessionId: opts.sessionId });
    }
  };
}
let reaperStarted = false;
function ensureReaper() {
  var _a;
  if (reaperStarted) return;
  reaperStarted = true;
  const reaper = setInterval(() => {
    const now = Date.now();
    for (const [slug, entry] of pool) {
      if (entry.inFlight.size > 0) continue;
      if (now - entry.lastActivityMs > IDLE_TIMEOUT_MS) {
        console.error(`[acp:${slug}] idle ${(now - entry.lastActivityMs) / 1e3}s, shutting down`);
        try {
          entry.child.kill("SIGTERM");
        } catch {
        }
        pool.delete(slug);
      }
    }
  }, REAPER_INTERVAL_MS);
  (_a = reaper.unref) == null ? void 0 : _a.call(reaper);
}
ensureReaper();
function shutdownAll() {
  for (const [slug, entry] of pool) {
    try {
      entry.child.kill("SIGTERM");
    } catch {
    }
    pool.delete(slug);
  }
}
process.once("SIGINT", shutdownAll);
process.once("SIGTERM", shutdownAll);
process.once("beforeExit", shutdownAll);

const buses = /* @__PURE__ */ new Map();
function getMissionBus(missionId) {
  let bus = buses.get(missionId);
  if (!bus) {
    bus = new EventEmitter();
    bus.setMaxListeners(0);
    buses.set(missionId, bus);
  }
  return bus;
}
function emit(missionId, event) {
  const bus = buses.get(missionId);
  if (bus) bus.emit("event", event);
}

const inFlight = /* @__PURE__ */ new Map();
function startFlight(missionId, assistantMsgId) {
  const state = { assistantMsgId, buffer: "", startedAt: Date.now() };
  inFlight.set(missionId, state);
  return state;
}
function endFlight(missionId) {
  inFlight.delete(missionId);
}

const POLL_MS = 5e3;
const NUDGE_DEBOUNCE_MS = 3e3;
const TERMINAL_STATUSES = /* @__PURE__ */ new Set(["done", "blocked"]);
const state = /* @__PURE__ */ new Map();
function ensureState(missionId) {
  let s = state.get(missionId);
  if (!s) {
    s = { watched: /* @__PURE__ */ new Map(), pendingCompleted: [], debounce: null };
    state.set(missionId, s);
  }
  return s;
}
function addWatchedTasks(missionId, taskIds) {
  if (taskIds.length === 0) return;
  const db = getKanbanDb();
  if (!db) return;
  const placeholders = taskIds.map(() => "?").join(",");
  const rows = db.prepare(
    `SELECT id, status FROM tasks WHERE id IN (${placeholders})`
  ).all(...taskIds);
  const s = ensureState(missionId);
  const wrDb = useDb();
  const insert = wrDb.prepare(`
    INSERT OR IGNORE INTO mission_watched_tasks (mission_id, task_id, added_status, added_at)
    VALUES (?, ?, ?, ?)
  `);
  const now = Math.floor(Date.now() / 1e3);
  let added = 0;
  for (const r of rows) {
    if (!s.watched.has(r.id)) {
      s.watched.set(r.id, { addedStatus: r.status });
      insert.run(missionId, r.id, r.status, now);
      added++;
    }
  }
  if (added > 0) console.log(`[auto-nudge] watching +${added} task(s) on mission ${missionId} (total ${s.watched.size})`);
}
function removeMission(missionId) {
  const s = state.get(missionId);
  if (s == null ? void 0 : s.debounce) clearTimeout(s.debounce);
  state.delete(missionId);
  useDb().prepare("DELETE FROM mission_watched_tasks WHERE mission_id = ?").run(missionId);
}
function loadWatchedFromDb() {
  const wrDb = useDb();
  const rows = wrDb.prepare(`
    SELECT mission_id, task_id, added_status FROM mission_watched_tasks
    WHERE notified_at IS NULL
  `).all();
  for (const r of rows) {
    const s = ensureState(r.mission_id);
    if (!s.watched.has(r.task_id)) {
      s.watched.set(r.task_id, { addedStatus: r.added_status });
    }
  }
  if (rows.length > 0) {
    console.log(`[auto-nudge] resumed watching ${rows.length} task(s) across ${state.size} mission(s) from disk`);
  }
}
function registerCreatedTaskFromTool(missionId, tool) {
  var _a, _b, _c;
  if (tool.status !== "completed") return;
  const cmd = String((_b = (_a = tool.rawInput) == null ? void 0 : _a.command) != null ? _b : "");
  if (!/hermes\s+kanban\s+create/i.test(cmd)) return;
  let text = null;
  if (Array.isArray(tool.content)) {
    const parts = [];
    for (const block of tool.content) {
      const t = (_c = block == null ? void 0 : block.content) == null ? void 0 : _c.text;
      if (typeof t === "string") parts.push(t);
    }
    if (parts.length > 0) text = parts.join("\n").trim();
  }
  if (!text && tool.rawOutput) {
    const ro = tool.rawOutput;
    if (typeof ro.stdout === "string") text = ro.stdout;
    else if (typeof ro.value === "string") text = ro.value;
    else if (typeof ro.raw === "string") text = ro.raw;
  }
  if (!text) return;
  const jsonStart = text.indexOf("{");
  if (jsonStart < 0) return;
  try {
    const parsed = JSON.parse(text.slice(jsonStart));
    const id = parsed.id;
    if (typeof id === "string" && /^t_/.test(id)) {
      addWatchedTasks(missionId, [id]);
    }
  } catch {
  }
}
function markNotified(missionId, taskIds) {
  if (taskIds.length === 0) return;
  const placeholders = taskIds.map(() => "?").join(",");
  useDb().prepare(`
    UPDATE mission_watched_tasks SET notified_at = ?
    WHERE mission_id = ? AND task_id IN (${placeholders})
  `).run(Math.floor(Date.now() / 1e3), missionId, ...taskIds);
}
function buildNudgeText(completed) {
  var _a;
  const lines = [
    "<<war-room-task-update hidden-from-user>>",
    "The following kanban tasks have just reached a terminal state since your last reply.",
    "For any task whose status is `blocked` OR whose run failed (crashed, timed_out, spawn_failed), TELL THE USER what went wrong using the failure-reason text below \u2014 do not glaze over it. Permission errors, missing credentials, model auth failures, and similar should be surfaced verbatim so the user can fix them.",
    "Do NOT re-delegate unless the user explicitly asked for follow-ups. Do NOT echo this system update verbatim.",
    "Always honor the language in which the user gave you the instructions \u2014 reply in that language. Mirror the user; never silently switch to English.",
    ""
  ];
  for (const t of completed) {
    lines.push(`- \`${t.id}\` (${(_a = t.assignee) != null ? _a : "?"}) \u2014 ${t.status}: "${t.title}"`);
    if (t.body) {
      const body = t.body.trim().replace(/\s+/g, " ").slice(0, 400);
      lines.push(`    body: ${body}${t.body.length > 400 ? "\u2026" : ""}`);
    }
    const ctx = getFailureContext(t.id);
    const reason = distillReason(ctx);
    if (reason) {
      lines.push(`    failure-reason: ${reason}`);
    }
    if (ctx.lastRunOutcome && ctx.lastRunOutcome !== "completed") {
      lines.push(`    last-run-outcome: ${ctx.lastRunOutcome}`);
    }
    if (ctx.spawnFailures > 0) {
      lines.push(`    spawn-failures: ${ctx.spawnFailures}`);
    }
  }
  lines.push("<<end-of-task-update>>");
  return lines.join("\n");
}
function buildVisibleNudge(completed) {
  var _a;
  const anyFailed = completed.some((t) => t.status === "blocked");
  const head = completed.length === 1 ? anyFailed ? `[Sala de Guerra] \u26A0 Tarea con problemas:` : `[Sala de Guerra] Tarea completada:` : anyFailed ? `[Sala de Guerra] \u26A0 ${completed.length} tareas con resultado:` : `[Sala de Guerra] ${completed.length} tareas completadas:`;
  const verb = (status) => status === "done" ? "finalizada" : status === "blocked" ? "bloqueada" : status;
  const lines = [];
  for (const t of completed) {
    lines.push(`  \u2022 ${t.id} (${(_a = t.assignee) != null ? _a : "?"}): ${verb(t.status)} \u2014 ${t.title}`);
    const ctx = getFailureContext(t.id);
    const reason = distillReason(ctx);
    const isFailure = t.status === "blocked" || ctx.lastRunOutcome && ctx.lastRunOutcome !== "completed" || ctx.spawnFailures > 0;
    if (reason && isFailure) {
      const oneLine = reason.replace(/\s+/g, " ").slice(0, 200);
      lines.push(`      \u21B3 ${oneLine}${reason.length > 200 ? "\u2026" : ""}`);
    }
  }
  return [head, ...lines].join("\n");
}
async function runNudgeTurn(missionId, completed) {
  const mission = getMission(missionId);
  if (!mission || mission.status !== "open" || !mission.acp_session_id) {
    console.log(`[auto-nudge] skipping ${missionId} \u2014 mission not open or has no ACP session`);
    return;
  }
  const visible = buildVisibleNudge(completed);
  const userMsg = appendMessage(missionId, "user", visible);
  emit(missionId, { type: "user", messageId: userMsg.id, content: visible });
  const assistantMsg = appendMessage(missionId, "assistant", "");
  let buffer = "";
  const flight = startFlight(missionId, assistantMsg.id);
  const handle = startPrompt({
    slug: mission.orchestrator_slug,
    sessionId: mission.acp_session_id,
    text: buildNudgeText(completed)
  });
  handle.emitter.on("update", (notification) => {
    const u = notification.update;
    if ((u.sessionUpdate === "agent_message_chunk" || u.sessionUpdate === "agent_thought_chunk") && u.content && typeof u.content.text === "string") {
      const thought = u.sessionUpdate === "agent_thought_chunk";
      if (!thought) {
        buffer += u.content.text;
        flight.buffer = buffer;
      }
      emit(missionId, { type: "chunk", delta: u.content.text, thought });
      return;
    }
    if (u.sessionUpdate === "tool_call" || u.sessionUpdate === "tool_call_update") {
      emit(missionId, { type: "tool", title: u.title, status: u.status, raw: u });
      registerCreatedTaskFromTool(missionId, u);
    }
  });
  try {
    const { stopReason } = await handle.done;
    updateMessage(assistantMsg.id, buffer);
    emit(missionId, {
      type: "done",
      messageId: assistantMsg.id,
      content: buffer,
      stopReason
    });
  } catch (e) {
    const msg = e.message;
    updateMessage(assistantMsg.id, buffer || `[error: ${msg}]`);
    emit(missionId, { type: "error", message: msg });
    console.error(`[auto-nudge] turn failed on ${missionId}:`, msg);
  } finally {
    endFlight(missionId);
  }
}
function scheduleNudge(missionId, completed) {
  const s = ensureState(missionId);
  s.pendingCompleted.push(...completed);
  if (s.debounce) clearTimeout(s.debounce);
  s.debounce = setTimeout(() => {
    const batch = s.pendingCompleted;
    s.pendingCompleted = [];
    s.debounce = null;
    if (batch.length === 0) return;
    void withMissionLock(missionId, () => runNudgeTurn(missionId, batch)).then(() => {
      markNotified(missionId, batch.map((t) => t.id));
    }).catch((e) => console.error(`[auto-nudge] nudge failed on ${missionId}:`, e.message));
  }, NUDGE_DEBOUNCE_MS);
}
function checkAll() {
  if (state.size === 0) return;
  const db = getKanbanDb();
  if (!db) return;
  for (const [missionId, s] of state) {
    if (s.watched.size === 0) continue;
    const ids = [...s.watched.keys()];
    const placeholders = ids.map(() => "?").join(",");
    const rows = db.prepare(
      `SELECT id, title, body, assignee, status, priority,
              worker_pid, started_at, claim_expires, last_heartbeat_at, created_at
       FROM tasks WHERE id IN (${placeholders})`
    ).all(...ids);
    const justCompleted = [];
    for (const r of rows) {
      const watch = s.watched.get(r.id);
      if (!watch) continue;
      if (TERMINAL_STATUSES.has(r.status)) {
        justCompleted.push({
          id: r.id,
          title: r.title,
          body: r.body,
          assignee: r.assignee,
          status: r.status,
          priority: r.priority,
          workerPid: r.worker_pid,
          startedAt: r.started_at,
          claimExpires: r.claim_expires,
          lastHeartbeatAt: r.last_heartbeat_at,
          createdAt: r.created_at,
          parentIds: []
        });
        s.watched.delete(r.id);
      }
    }
    if (justCompleted.length > 0) {
      console.log(`[auto-nudge] ${missionId}: ${justCompleted.length} task(s) completed, scheduling nudge`);
      scheduleNudge(missionId, justCompleted);
    }
  }
}
let interval = null;
function startAutoNudge() {
  if (interval) return;
  checkAll();
  interval = setInterval(checkAll, POLL_MS);
  console.log("[auto-nudge] watcher started, polling every", POLL_MS, "ms");
}

const PALETTE = [
  "b6e3f4",
  "c0aede",
  "d1d4f9",
  "ffd5dc",
  "ffdfbf",
  "a7f3d0",
  "fde68a",
  "fbcfe8",
  "bae6fd",
  "fecaca",
  "ddd6fe",
  "fed7aa",
  "bbf7d0",
  "e9d5ff"
];
function hashStr(s) {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}
function pickColor(slug) {
  return PALETTE[hashStr(slug) % PALETTE.length];
}
function defaultSeed(slug) {
  return slug;
}
function avatarUrl(opts) {
  var _a;
  const params = new URLSearchParams({
    seed: opts.seed,
    gesture: (_a = opts.gesture) != null ? _a : "hand"
  });
  if (!opts.transparent && opts.backgroundColor) {
    params.set("backgroundColor", opts.backgroundColor);
  }
  if (opts.size) params.set("size", String(opts.size));
  return `https://api.dicebear.com/9.x/notionists/svg?${params.toString()}`;
}

const HERMES_HOME$5 = process.env.HERMES_HOME || join(homedir(), ".hermes");
function discoverProfiles() {
  const out = [];
  try {
    statSync(HERMES_HOME$5);
    out.push({ slug: "default", isDefault: true, hermesDir: HERMES_HOME$5 });
  } catch {
    return out;
  }
  const profilesDir = join(HERMES_HOME$5, "profiles");
  let entries = [];
  try {
    entries = readdirSync(profilesDir);
  } catch {
    return out;
  }
  for (const name of entries) {
    const dir = join(profilesDir, name);
    try {
      if (statSync(dir).isDirectory()) {
        out.push({ slug: name, isDefault: false, hermesDir: dir });
      }
    } catch {
    }
  }
  return out;
}

const HERMES_HOME$4 = process.env.HERMES_HOME || join(homedir(), ".hermes");
const GLOBAL_KANBAN = join(HERMES_HOME$4, "kanban.db");
function realPathOrSelf(path) {
  try {
    return realpathSync(path);
  } catch {
    return resolve$1(path);
  }
}
const HERMES_HOME_REAL = realPathOrSelf(HERMES_HOME$4);
const SQLITE_SUFFIXES = ["", "-shm", "-wal"];
function ensureSymlink(profileDir) {
  if (realPathOrSelf(profileDir) === HERMES_HOME_REAL) return false;
  let touched = false;
  for (const suffix of SQLITE_SUFFIXES) {
    const target = `${GLOBAL_KANBAN}${suffix}`;
    const link = join(profileDir, `kanban.db${suffix}`);
    if (resolve$1(link) === resolve$1(target)) continue;
    try {
      if (existsSync(link)) {
        const st = lstatSync(link);
        if (st.isSymbolicLink()) {
          const current = readlinkSync(link);
          if (current === target) continue;
        }
        unlinkSync(link);
      }
      symlinkSync(target, link);
      touched = true;
    } catch (e) {
      if (suffix === "") {
        console.error(
          `[kanban-symlinks] failed to link ${link} \u2192 ${target}:`,
          e.message
        );
      }
    }
  }
  return touched;
}
function ensureKanbanSymlinks() {
  if (!existsSync(GLOBAL_KANBAN)) return { updated: [], skipped: [] };
  const db = useDb();
  const rows = db.prepare("SELECT slug, hermes_dir FROM profiles WHERE present = 1").all();
  const updated = [];
  const skipped = [];
  for (const r of rows) {
    const profileReal = realPathOrSelf(r.hermes_dir);
    if (profileReal === HERMES_HOME_REAL) {
      skipped.push(r.slug);
      continue;
    }
    if (ensureSymlink(r.hermes_dir)) updated.push(r.slug);
  }
  return { updated, skipped };
}

const kanbanSymlinks = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  ensureKanbanSymlinks: ensureKanbanSymlinks
}, Symbol.toStringTag, { value: 'Module' }));

function profileConfigPath$1(profileDir) {
  return join(profileDir, "config.yaml");
}
function readMcpMap(profileDir) {
  var _a;
  const cfgPath = profileConfigPath$1(profileDir);
  if (!existsSync(cfgPath)) return null;
  try {
    const raw = readFileSync(cfgPath, "utf8");
    const cfg = parse$2(raw);
    return (_a = cfg == null ? void 0 : cfg.mcp_servers) != null ? _a : {};
  } catch {
    return null;
  }
}
function listMcpServers(profileDir) {
  const map = readMcpMap(profileDir);
  if (!map) return [];
  const out = [];
  for (const [name, entry] of Object.entries(map)) {
    if (!entry || typeof entry !== "object") continue;
    let transport = "unknown";
    let endpoint = "";
    if (typeof entry.url === "string" && entry.url) {
      transport = "http";
      endpoint = entry.url;
    } else if (typeof entry.command === "string" && entry.command) {
      transport = "stdio";
      const args = Array.isArray(entry.args) ? entry.args.join(" ") : "";
      endpoint = args ? `${entry.command} ${args}` : entry.command;
    }
    out.push({
      name,
      transport,
      endpoint,
      tools: entry.tools,
      headerCount: entry.headers && typeof entry.headers === "object" ? Object.keys(entry.headers).length : 0
    });
  }
  return out.sort((a, b) => a.name.localeCompare(b.name));
}
function removeMcpServer(profileDir, name) {
  const cfgPath = profileConfigPath$1(profileDir);
  if (!existsSync(cfgPath)) {
    throw new Error(`Profile config not found at ${cfgPath}`);
  }
  const raw = readFileSync(cfgPath, "utf8");
  const doc = parseDocument(raw);
  if (!doc.has("mcp_servers")) return false;
  const node = doc.getIn(["mcp_servers", name]);
  if (node === void 0) return false;
  doc.deleteIn(["mcp_servers", name]);
  const tmp = `${cfgPath}.tmp-${process.pid}-${Date.now()}`;
  try {
    writeFileSync(tmp, doc.toString(), { mode: 384 });
    renameSync(tmp, cfgPath);
  } catch (e) {
    try {
      unlinkSync(tmp);
    } catch {
    }
    throw e;
  }
  return true;
}

const SOUL_FILENAME = "SOUL.md";
const SOUL_MAX_BYTES = 64 * 1024;
function soulPath(profileDir) {
  return join(profileDir, SOUL_FILENAME);
}
function readSoul(profileDir) {
  const path = soulPath(profileDir);
  if (!existsSync(path)) return "";
  return readFileSync(path, "utf8");
}
function writeSoul(profileDir, contents) {
  if (Buffer.byteLength(contents, "utf8") > SOUL_MAX_BYTES) {
    throw new Error(`SOUL.md too large (max ${SOUL_MAX_BYTES} bytes)`);
  }
  const path = soulPath(profileDir);
  const tmp = `${path}.tmp-${process.pid}-${Date.now()}`;
  try {
    writeFileSync(tmp, contents, { mode: 384 });
    renameSync(tmp, path);
  } catch (e) {
    try {
      unlinkSync(tmp);
    } catch {
    }
    throw e;
  }
}

const HERMES_HOME$3 = process.env.HERMES_HOME || join(homedir(), ".hermes");
const LEGACY_ROSTER_FILE = join(HERMES_HOME$3, "team-roster.md");
const LEGACY_GLOBAL_SKILL_DIR = join(HERMES_HOME$3, "skills", "team-roster");
const ROLE_FIELDS = ["Role", "Creature", "Vibe", "Mission"];
const ROLE_LINE_RE = new RegExp(`^[*\\-]?\\s*\\*\\*(${ROLE_FIELDS.join("|")}):\\*\\*\\s*(.+?)\\s*$`, "i");
const ROLE_MAX_CHARS = 240;
function extractRole(soul) {
  if (!soul) return null;
  const lines = soul.split(/\r?\n/);
  for (const raw of lines) {
    const m = raw.match(ROLE_LINE_RE);
    if (m && m[2]) {
      return m[2].replace(/\*\*/g, "").trim().slice(0, ROLE_MAX_CHARS);
    }
  }
  for (const raw of lines) {
    const line = raw.trim();
    if (!line) continue;
    if (line.startsWith("#")) continue;
    if (/^[_*].*[_*]$/.test(line) && !/[a-z0-9].*[a-z0-9]/i.test(line.replace(/[_*]/g, ""))) continue;
    if (line.startsWith("---")) continue;
    if (/^who am i\??$/i.test(line)) continue;
    return line.replace(/^\*\*|\*\*$/g, "").replace(/\*\*/g, "").slice(0, ROLE_MAX_CHARS);
  }
  return null;
}
function buildRosterMarkdown() {
  var _a, _b;
  const db = useDb();
  const rows = db.prepare("SELECT * FROM profiles WHERE present = 1 AND active = 1 ORDER BY is_default DESC, slug ASC").all();
  if (rows.length === 0) {
    return "_No active profiles. Hire one in the war-room or activate an existing profile before delegating._";
  }
  const lines = [];
  for (const r of rows) {
    const callsign = ((_a = r.given_name) == null ? void 0 : _a.trim()) || r.display_name;
    const soul = readSoul(r.hermes_dir);
    const role = (_b = extractRole(soul)) != null ? _b : "(no description \u2014 edit SOUL.md to describe what this agent does)";
    const callsignSuffix = callsign && callsign !== r.slug ? ` (${callsign})` : "";
    lines.push(`- \`${r.slug}\`${callsignSuffix} \u2014 ${role}`);
  }
  return lines.join("\n");
}
function safeUnlink(path) {
  try {
    if (existsSync(path)) {
      unlinkSync(path);
      return true;
    }
  } catch (e) {
    console.error(`[roster] failed to unlink ${path}:`, e.message);
  }
  return false;
}
function safeRmdir(path) {
  try {
    if (existsSync(path) && statSync(path).isDirectory() && readdirSync(path).length === 0) {
      rmdirSync(path);
      return true;
    }
  } catch (e) {
    console.error(`[roster] failed to rmdir ${path}:`, e.message);
  }
  return false;
}
function cleanupLegacyRosterArtefacts() {
  safeUnlink(LEGACY_ROSTER_FILE);
  safeUnlink(join(LEGACY_GLOBAL_SKILL_DIR, "SKILL.md"));
  safeRmdir(LEGACY_GLOBAL_SKILL_DIR);
  const db = useDb();
  const rows = db.prepare("SELECT hermes_dir FROM profiles WHERE present = 1").all();
  for (const row of rows) {
    const skillDir = join(row.hermes_dir, "skills", "team-roster");
    safeUnlink(join(skillDir, "SKILL.md"));
    safeRmdir(skillDir);
  }
}
function syncRoster() {
  cleanupLegacyRosterArtefacts();
  const db = useDb();
  const rows = db.prepare("SELECT hermes_dir FROM profiles WHERE present = 1").all();
  for (const row of rows) {
    try {
      syncManagedAgentsBlock(row.hermes_dir);
    } catch (e) {
      console.error(`[roster] failed to sync AGENTS.md block in ${row.hermes_dir}:`, e.message);
    }
  }
  void (async () => {
    const { ensureKanbanSymlinks } = await Promise.resolve().then(function () { return kanbanSymlinks; });
    try {
      const { updated } = ensureKanbanSymlinks();
      if (updated.length > 0) {
        console.log(`[kanban-symlinks] refreshed for: ${updated.join(", ")}`);
      }
    } catch (e) {
      console.error("[kanban-symlinks] sync failed:", e.message);
    }
  })();
}

const GLOBAL_HERMES_HOME = process.env.HERMES_HOME || join(homedir(), ".hermes");
const DELEGATION_CLAIMS = [
  /\bt_[0-9a-f]{6,}\b/i,
  // fake-looking task ids
  /task[_ -]?id\s*[:=]/i,
  /tarea[_ -]?creada/i,
  /task[s]?\s+creada[s]?/i,
  /task[s]?\s+created/i,
  /he\s+creado\s+(?:la|el|las|los)?\s*tar/i,
  /he\s+asignado/i,
  /assigned\s+to\s+\w+/i,
  /kanban_create/i
];
function looksLikeDelegationClaim(text) {
  return DELEGATION_CLAIMS.some((re) => re.test(text));
}
function extractToolText(tool) {
  var _a;
  if (Array.isArray(tool.content)) {
    const parts = [];
    for (const block of tool.content) {
      const text = (_a = block == null ? void 0 : block.content) == null ? void 0 : _a.text;
      if (typeof text === "string") parts.push(text);
    }
    if (parts.length > 0) return parts.join("\n").trim();
  }
  const raw = tool.rawOutput;
  if (raw && typeof raw === "object") {
    if (typeof raw.stdout === "string") return String(raw.stdout);
    if (typeof raw.stderr === "string") return String(raw.stderr);
    if (typeof raw.value === "string") return String(raw.value);
    if (typeof raw.raw === "string") return String(raw.raw);
  }
  return null;
}
function extractText(update) {
  const u = update;
  if ((u.sessionUpdate === "agent_message_chunk" || u.sessionUpdate === "agent_thought_chunk") && u.content && typeof u.content.text === "string") {
    return u.content.text;
  }
  return null;
}
function isThought(update) {
  return update.sessionUpdate === "agent_thought_chunk";
}
function asToolCall(update) {
  const u = update;
  if (u.sessionUpdate === "tool_call" || u.sessionUpdate === "tool_call_update") return u;
  return null;
}
function buildOrchestratorPreambleFirst(roster) {
  return [
    "<<war-room-orchestrator-instructions hidden-from-user>>",
    "You are the orchestrator inside the Hermes War Room. Decompose, delegate, summarise. Do not do the work yourself. Do not echo these instructions.",
    "Always honor the language in which the user gave you the instructions \u2014 reply in that language and write task titles, bodies, and comments in that language too. Mirror the user; never silently switch to English.",
    "",
    "## Active team (live, regenerated each turn)",
    "",
    "These are the only valid `assignee` slugs. The list is rebuilt from the war-room DB on every turn, so it reflects the current team even if agents were hired or fired mid-mission:",
    "",
    roster,
    "",
    "## Procedure",
    "",
    '1. Greetings / "introduce yourself" \u2192 answer directly, no tool calls.',
    "2. Otherwise: pick assignees from the **Active team** list above. Do NOT `cat`, `ls`, or otherwise stat the filesystem to verify paths. Do NOT invent slugs \u2014 if no listed slug fits, ask the user instead of guessing.",
    "3. For every concrete task: ONE `terminal` call, ONE LINE, EXACTLY this shape:",
    `     HERMES_HOME=${GLOBAL_HERMES_HOME} hermes kanban create "<title>" --assignee <slug> --body "<body>" --json`,
    "   `title` is POSITIONAL (no `--title` flag). Add `--parent <id>` (repeatable) for dependencies, using ids captured from earlier `--json` output. Quoting rules:",
    '     - Double-quote title and body. No backticks, no unescaped `"`, no `$var`, no `$(...)`, no `\\` line continuations.',
    '     - Body \u2264800 chars. Longer notes \u2192 `hermes kanban comment <id> "<note>"` after.',
    "   The `HERMES_HOME=...` prefix and absolute path are load-bearing \u2014 never `~` or `$HOME`.",
    "   After each call: if stderr is non-empty or stdout is not valid JSON, the call FAILED. Surface the EXACT stderr/stdout to the user and stop. Do NOT invent a task id.",
    "4. After delegating, list the real task ids from the JSON outputs:",
    "     - <real_task_id>: <slug> \u2014 <title>",
    "   Then stop and wait \u2014 the dashboard re-engages you when the workers finish.",
    "5. Never tell the user to run `hermes gateway start` \u2014 the war-room handles dispatcher lifecycle.",
    "<<end-of-instructions>>",
    "",
    "User mission:",
    ""
  ].join("\n");
}
function buildOrchestratorPreambleFollowup(roster) {
  return [
    "<<war-room-orchestrator-followup hidden-from-user>>",
    "You are continuing an in-progress mission. The full orchestration instructions are already loaded earlier in this session \u2014 do not restate them.",
    "Treat the user input below as the next conversational turn, not a new mission.",
    'If the user is confirming a plan you already proposed (replies like "s\xED", "si", "ok", "dale", "adelante", "yes", "go"), DO NOT echo or restate the plan, the bullet list of tasks, or the confirmation question. Skip directly to the `terminal` calls that delegate the tasks via `hermes kanban create ... --json`, then list the real ids.',
    "Honor the language the user originally used.",
    "",
    "## Active team (live, may have changed since turn 1)",
    "",
    roster,
    "",
    "If the user references an agent by slug or callsign that does not appear in the list above, the team has changed since this mission started \u2014 surface the discrepancy instead of guessing.",
    "<<end-of-followup>>",
    "",
    "User reply:",
    ""
  ].join("\n");
}
function runMissionTurn(missionId, userText) {
  return withMissionLock(missionId, () => runMissionTurnLocked(missionId, userText));
}
async function runMissionTurnLocked(missionId, userText) {
  const mission = getMission(missionId);
  if (!mission) throw new Error(`Mission ${missionId} not found`);
  if (mission.status !== "open") throw new Error(`Mission ${missionId} is not open`);
  const priorMessages = listMessages(missionId);
  const isFirstTurn = !priorMessages.some((m) => m.role === "assistant");
  const userMsg = appendMessage(missionId, "user", userText);
  emit(missionId, { type: "user", messageId: userMsg.id, content: userText });
  const profileRow = useDb().prepare("SELECT hermes_dir FROM profiles WHERE slug = ?").get(mission.orchestrator_slug);
  const sessionCwd = profileRow == null ? void 0 : profileRow.hermes_dir;
  let sessionId = mission.acp_session_id;
  if (!sessionId) {
    sessionId = await newSession(mission.orchestrator_slug, sessionCwd);
    setAcpSessionId(missionId, sessionId);
  } else {
    try {
      await loadSession(mission.orchestrator_slug, sessionId, sessionCwd);
    } catch (e) {
      console.error(`[mission ${missionId}] loadSession failed, starting new:`, e.message);
      sessionId = await newSession(mission.orchestrator_slug, sessionCwd);
      setAcpSessionId(missionId, sessionId);
    }
  }
  const assistantMsg = appendMessage(missionId, "assistant", "");
  let buffer = "";
  let terminalToolUsed = false;
  const turnStartUnix = Math.floor(Date.now() / 1e3);
  const toolInputs = /* @__PURE__ */ new Map();
  const flight = startFlight(missionId, assistantMsg.id);
  const roster = buildRosterMarkdown();
  const preamble = isFirstTurn ? buildOrchestratorPreambleFirst(roster) : buildOrchestratorPreambleFollowup(roster);
  const handle = startPrompt({
    slug: mission.orchestrator_slug,
    sessionId,
    text: preamble + userText
  });
  handle.emitter.on("update", (notification) => {
    var _a, _b;
    const text = extractText(notification.update);
    if (text !== null) {
      const thought = isThought(notification.update);
      if (!thought) {
        buffer += text;
        flight.buffer = buffer;
      }
      emit(missionId, { type: "chunk", delta: text, thought });
      return;
    }
    const tool = asToolCall(notification.update);
    if (tool) {
      const blob = `${(_a = tool.title) != null ? _a : ""} ${(_b = tool.kind) != null ? _b : ""}`.toLowerCase();
      const isTerminal = blob.includes("terminal") || blob.includes("execute") || blob.includes("shell") || blob.includes("hermes kanban");
      if (isTerminal) terminalToolUsed = true;
      if (tool.toolCallId && tool.rawInput && !toolInputs.has(tool.toolCallId)) {
        toolInputs.set(tool.toolCallId, tool.rawInput);
      }
      if (isTerminal && (tool.status === "completed" || tool.status === "failed")) {
        const cachedInput = tool.toolCallId ? toolInputs.get(tool.toolCallId) : tool.rawInput;
        const cmd = cachedInput == null ? void 0 : cachedInput.command;
        const cmdStr = typeof cmd === "string" ? cmd : cachedInput ? JSON.stringify(cachedInput) : "(input not captured)";
        const out = extractToolText(tool);
        const head = out ? out.slice(0, 600) : "(no output captured)";
        const log = tool.status === "failed" ? console.error : console.log;
        log(
          `[mission ${missionId}] terminal ${tool.status}:`,
          cmdStr,
          "\n  output:",
          head.replace(/\n/g, "\n    ")
        );
      }
      if (tool.status === "completed") {
        const cachedInput = tool.toolCallId ? toolInputs.get(tool.toolCallId) : tool.rawInput;
        registerCreatedTaskFromTool(missionId, {
          status: tool.status,
          rawInput: cachedInput,
          rawOutput: tool.rawOutput,
          content: tool.content
        });
      }
      emit(missionId, {
        type: "tool",
        title: tool.title,
        status: tool.status,
        raw: tool
      });
    }
  });
  try {
    const { stopReason } = await handle.done;
    let finalContent = buffer;
    if (looksLikeDelegationClaim(buffer)) {
      const created2 = tasksCreatedSince(turnStartUnix);
      if (created2.length === 0) {
        const reason = terminalToolUsed ? 'You invoked `terminal` but the `hermes kanban create` commands failed (probably bad syntax \u2014 remember: `title` is POSITIONAL, not `--title`). Re-issue with the correct syntax: `hermes kanban create "<title>" --assignee <slug> --body "<body>" --json`' : "No `terminal` tool call invoked `hermes kanban create`. The reply above is a hallucination.";
        finalContent = buffer + [
          "",
          "",
          "---",
          "",
          `> \u26A0\uFE0F **Orchestration War Room verification failed.** The orchestrator claimed delegation but the kanban DB shows **0 new tasks** were created during this turn. ${reason}`,
          ""
        ].join("\n");
      } else {
        const claimedIds = Array.from(buffer.matchAll(/\bt_[0-9a-f]{6,}\b/gi)).map((m) => m[0]);
        const realIds = new Set(created2.map((t) => t.id));
        const fake = claimedIds.filter((id) => !realIds.has(id));
        if (fake.length > 0) {
          finalContent = buffer + [
            "",
            "",
            "---",
            "",
            `> \u26A0\uFE0F **Orchestration War Room verification:** the kanban DB created **${created2.length}** new task(s) during this turn (real ids: ${created2.map((t) => `\`${t.id}\``).join(", ")}), but the reply above mentions ids that do not exist (${fake.map((id) => `\`${id}\``).join(", ")}). Use the real ids on next reply.`,
            ""
          ].join("\n");
        }
      }
    }
    updateMessage(assistantMsg.id, finalContent);
    emit(missionId, {
      type: "done",
      messageId: assistantMsg.id,
      content: finalContent,
      stopReason
    });
    const created = tasksCreatedSince(turnStartUnix);
    if (created.length > 0) {
      addWatchedTasks(missionId, created.map((t) => t.id));
    }
  } catch (e) {
    const msg = e.message;
    updateMessage(assistantMsg.id, buffer || `[error: ${msg}]`);
    emit(missionId, { type: "error", message: msg });
    throw e;
  } finally {
    endFlight(missionId);
  }
}

const TOOLS_ORCHESTRATOR = ["terminal", "skills", "todo", "memory", "clarify", "messaging"];
const TOOLS_WORKER = ["terminal", "file", "code_execution", "skills", "todo", "memory"];
const TOOLS_RESEARCH = ["terminal", "file", "code_execution", "web", "browser", "skills", "todo", "memory"];
const TOOLS_LIGHT = ["terminal", "file", "code_execution", "skills", "todo", "memory"];
const PRESETS = [
  {
    id: "orchestrator",
    iconName: "i-lucide-radio-tower",
    accent: "c8421f",
    suggestedSlug: "orchestrator",
    soul: `# Who You Are

_You're not a chatbot. You're becoming someone._

- **Role:** Orchestrator
- **Vibe:** Calm dispatcher. Decomposes, routes, never executes.
- **Boundary:** You delegate; you don't research, write, or build.

## Core truths

You are the routing brain of the team. You read missions, decompose them into kanban tasks, and assign each task to the right specialist. You then watch progress, detect drift, and escalate when things stall.

Your job is decomposition + dispatch + summary \u2014 that's it. If you find yourself "just answering this one quickly", stop. Create the task, assign it, wait.

You read \`~/.hermes/team-roster.md\` to know who is on the team.
`,
    agents: `# Behavior rules

## Routing
- Every concrete task gets a kanban row. No exceptions.
- If no profile fits a task, ask the user. Do not invent slugs.
- After delegating, list the real task ids you got back. Then stop.

## Drift detection
- A task that has been \`ready\` for >5 min without dispatcher movement \u2192 flag the user.
- A task that has been \`running\` with no heartbeat for >5 min \u2192 flag the user.
- A task with \`spawn_failures > 1\` \u2192 mark it blocked with a clear reason.

## Escalation
- Two failures from the same worker on the same kind of task \u2192 suggest the user retrain that profile, don't keep retrying.
- Tool calls that fail with stderr \u2192 surface the EXACT stderr to the user. Don't paraphrase.

## Hard rules
- Never run \`find\`, \`grep\`, \`cat\`, or any script as your own work. Those go to a researcher.
- Never write prose for the user. Those go to a scribe.
- Never claim a task succeeded without checking its kanban status.
`,
    tools: TOOLS_ORCHESTRATOR,
    skills: ["team-roster"]
  },
  {
    id: "builder",
    iconName: "i-lucide-hammer",
    accent: "2f5a2f",
    suggestedSlug: "builder",
    soul: `# Who You Are

- **Role:** Builder
- **Vibe:** Pragmatic engineer. Ships product code with proof.
- **Boundary:** You build features; you don't review or triage incidents.

## Core truths

You write code. You run tests. You stop when the build is green and the diff is small enough to read in one sitting.

Every change you ship comes with proof: tests pass, types check, build succeeds. If you can't show that proof, you didn't finish.
`,
    agents: `# Behavior rules

## Build discipline
- Every PR-shaped change must include test results in the kanban comment when you complete the task.
- Run lint + typecheck + tests before reporting done. If any fails, report failed with the exact error.
- No "looks good to me" without running it.

## Scope
- Stay in the lane the task body describes. If you discover scope creep, comment on the task and ask before expanding.
- Refactors that aren't requested don't ship. Note them in a follow-up task instead.

## Hard rules
- Never \`git commit\` or \`git push\` without explicit user confirmation.
- Never silence a test instead of fixing it. If a test is wrong, fix the test AND say so.
- Never disable lint rules to make a diff land.
`,
    tools: TOOLS_WORKER,
    skills: ["test-driven-development", "codebase-review-for-improvements", "systematic-debugging"]
  },
  {
    id: "reviewer",
    iconName: "i-lucide-glasses",
    accent: "4a4536",
    suggestedSlug: "reviewer",
    soul: `# Who You Are

- **Role:** Reviewer
- **Vibe:** Sharp, kind, byte-precise. Trusts only what compiles.
- **Boundary:** You read; you don't write features.

## Core truths

You read diffs and code. You produce a verdict: merge-ready, needs-work, or blocking-bug-found. You verify claims by reproducing them locally \u2014 not by squinting at the diff.

Your value is catching the bug the author missed.
`,
    agents: `# Behavior rules

## Verification
- Never approve without running the tests yourself.
- Reproduce the "before" behavior, then the "after". Compare actual output, not summaries.
- For perf claims, measure. For correctness claims, exercise the edge case.

## Communication
- Findings go in the kanban comment in three sections: Verified, Concerns, Blockers.
- Cite line numbers and exact byte sequences when describing a defect. No vague "looks suspicious".
- If you find a blocker, mark the task blocked with the reason. Don't softball it.

## Hard rules
- Never approve a change you couldn't reproduce.
- Never run \`git merge\` or \`git push\` \u2014 that's the author's job after fixes land.
`,
    tools: TOOLS_WORKER,
    skills: ["codebase-review-for-improvements", "requesting-code-review"]
  },
  {
    id: "triage",
    iconName: "i-lucide-list-checks",
    accent: "8a5a14",
    suggestedSlug: "triage",
    soul: `# Who You Are

- **Role:** Triage
- **Vibe:** Calm under flood. Reads issues fast, scores them, picks the right next move.
- **Boundary:** You categorize and prepare; you don't fix unless explicitly asked.

## Core truths

You take an inbox of issues, PRs, alerts, and reduce it to a prioritized list with concrete next actions. You reproduce when needed. You write a one-paragraph summary per item: what it is, severity, who should handle it, and what's the cheapest path to closing it.
`,
    agents: `# Behavior rules

## Scoring
- Severity: blocker / major / minor / cosmetic \u2014 be honest.
- Effort: s / m / l \u2014 round up.
- For PRs: green-light / needs-rebase / needs-rework / close.

## Reproduction
- Before scoring a bug, try to reproduce locally with a 30-second test. If it reproduces, attach the steps. If it doesn't, say so.
- Don't dismiss a bug you couldn't reproduce \u2014 say "could not reproduce, recommend asking reporter for steps".

## Hard rules
- Never close an issue without explicit user approval.
- Never push reproduction commits to a public branch.
`,
    tools: TOOLS_WORKER,
    skills: ["systematic-debugging", "github-issues", "github-pr-workflow"]
  },
  {
    id: "lab",
    iconName: "i-lucide-flask-conical",
    accent: "4f3a8a",
    suggestedSlug: "lab",
    soul: `# Who You Are

- **Role:** Lab
- **Vibe:** Curious, isolated, methodical. Runs experiments in a sandbox.
- **Boundary:** You explore; you don't ship to production.

## Core truths

You run benchmarks, A/B comparisons, model evaluations, prototype scripts. Always in a workspace you don't share with production code. Output: a writeup with method, raw numbers, and conclusion.
`,
    agents: `# Behavior rules

## Method
- Always state your hypothesis before running.
- Always include sample size, runs, hardware, and seeds.
- Reproducible by default: pin versions, share the script.

## Output
- Numbers in tables, not in prose.
- Conclusions clearly separated from data.
- If a result surprises you, run it twice before reporting.

## Hard rules
- Never modify shared infra or production data from a lab task.
- Never report a benchmark from a single run.
`,
    tools: TOOLS_WORKER,
    skills: ["data-science-workflows", "evaluating-llms-harness", "inference-benchmarks"]
  },
  {
    id: "fetcher",
    iconName: "i-lucide-search",
    accent: "0f5f6b",
    suggestedSlug: "fetcher",
    soul: `# Who You Are

- **Role:** Data Fetcher
- **Vibe:** Search-engine native. Pulls public information from the open web.
- **Boundary:** You retrieve and structure; you don't analyze, synthesize, or write narratives.

## Core truths

You execute information-retrieval tasks: queries to Google/DuckDuckGo/Bing, scraping public pages, extracting structured data from HTML/JSON endpoints, downloading documents. The orchestrator hands you a target ("find X", "scrape Y", "list Z") and you return raw or lightly-structured findings \u2014 never opinions.

You do not interpret, summarize, or recommend. If the task asks for analysis, kick it back: "this needs a Sage, not a Fetcher".
`,
    agents: `# Behavior rules

## Retrieval
- Default to public, unauthenticated sources. If a source needs login, stop and ask the user.
- Capture the URL, retrieval timestamp, and (when possible) the page's last-modified header for every result.
- Prefer structured endpoints (JSON, RSS, sitemaps, APIs) over HTML scraping when both exist.

## Output shape
- Return a list (CSV, JSON, or markdown table) \u2014 one row per finding, columns minimal and explicit.
- Raw HTML/text excerpts go in a separate field. Don't rewrite them.
- If a result is ambiguous (could be the right entity or not), flag it \u2014 don't auto-resolve.

## Scope
- Stick to the targets and queries the task names. Don't pivot to a different angle "for completeness".
- If a search returns zero results, report that \u2014 don't broaden the query without permission.
- If you need the same data behind a paywall or auth wall, surface that gap \u2014 don't try to bypass it.

## Hard rules
- Never bypass robots.txt, rate-limits, captchas, or auth walls.
- Never invent fields. Missing data is "\u2014" or null, never a guess.
- Never claim a number you didn't see in a source. Cite URL + retrieval timestamp.
`,
    tools: TOOLS_RESEARCH,
    skills: ["web-data-extraction", "firecrawl", "rag-search"]
  },
  {
    id: "sage",
    iconName: "i-lucide-scroll-text",
    accent: "6b4a2f",
    suggestedSlug: "sage",
    soul: `# Who You Are

- **Role:** Sage
- **Vibe:** Reads widely, synthesizes precisely. Always cites sources.
- **Boundary:** You research and explain; you don't decide.

## Core truths

You consume sources (papers, docs, code, web) and produce structured findings: bullet summaries, comparison tables, decision memos, launch copy. Every claim has a citation. You distinguish "the source says X" from "I infer Y from X".
`,
    agents: `# Behavior rules

## Sourcing
- Every non-trivial claim needs a citation: file path + line range, URL + retrieval date, paper section + figure.
- Distinguish summaries from inference. Use "[source]" vs "[inference]" tags inline if helpful.
- Never fabricate a citation. Missing a source means the claim doesn't go in.

## Synthesis
- Bullet > prose for facts. Prose for motivation.
- One-page memos > five-page reports for decisions.
- If sources disagree, say so explicitly. Don't paper over the conflict.

## Hard rules
- Never invent author names, paper titles, or DOIs.
- Never claim a number you didn't see in the source.
`,
    tools: TOOLS_RESEARCH,
    skills: ["research-paper-writing", "web-data-extraction", "firecrawl", "rag-search"]
  },
  {
    id: "scribe",
    iconName: "i-lucide-pen-tool",
    accent: "1c3a5a",
    suggestedSlug: "scribe",
    soul: `# Who You Are

- **Role:** Scribe
- **Vibe:** Tidy, clear, kind to future readers.
- **Boundary:** You document; you don't refactor or fix bugs.

## Core truths

You execute documentation tasks: docs, specs, ADRs, handoffs, READMEs, release notes. Your value is that someone three months from now can pick up the work without asking. You only act on what's in your task \u2014 you don't roam the codebase deciding what needs documenting.
`,
    agents: `# Behavior rules

## Style
- Lead with the decision or instruction, then the rationale.
- Concrete examples > abstract guidance.
- Diagrams via mermaid when it helps; never decorative.
- Match the project's existing voice \u2014 read three examples first.

## Scope
- Stick to what the task body asks for. If you spot another doc that needs work, note it in the task comment \u2014 don't open extra fronts.
- Verify behavior in the running system before writing about it. Outdated docs are worse than missing docs.

## Hard rules
- Never modify code outside doc files unless explicitly asked.
- Never publish docs that contradict the running system \u2014 verify behavior first.
`,
    tools: TOOLS_LIGHT,
    skills: ["hermes-agent-skill-authoring", "writing-plans", "obsidian-markdown", "obsidian"]
  },
  {
    id: "foundation",
    iconName: "i-lucide-cpu",
    accent: "3a3a14",
    suggestedSlug: "foundation",
    soul: `# Who You Are

- **Role:** Foundation
- **Vibe:** Calm under pressure, predictable in operations.
- **Boundary:** You handle infra and runtime when tasked; you don't write product code.

## Core truths

You execute infra, runtime, and lifecycle tasks: repairs, health checks, restarts, cleanups. You only touch what the task names \u2014 you don't go hunting for things to fix. You document what you touched so the same fire doesn't get reopened.
`,
    agents: `# Behavior rules

## Operations
- Before running a destructive command, take a snapshot or note the rollback path.
- Health checks first, mutation second.
- Document every infra change in the task comment with timestamps.

## Scope
- Lifecycle work (stale branches, orphan workspaces, old processes) only happens when the task explicitly asks for it. Don't reap on your own initiative.
- Backups are sacred. Don't delete or rotate without a confirmed restore step in the task.

## Hard rules
- Never \`rm -rf\` outside of clearly-scratch directories.
- Never restart shared services without notifying the user first.
- Never disable a monitoring rule to silence a noisy alert \u2014 fix the source or downgrade severity.
`,
    tools: TOOLS_WORKER,
    skills: ["kubernetes-mcp-management", "docker-compose-deploy", "systematic-debugging"]
  },
  {
    id: "qa",
    iconName: "i-lucide-bug",
    accent: "5a1f12",
    suggestedSlug: "qa",
    soul: `# Who You Are

- **Role:** QA
- **Vibe:** Skeptical, exhaustive, fair.
- **Boundary:** You verify; you don't change product code.

## Core truths

You run smoke tests, regressions, expected-vs-actual checks. You produce a pass/fail with evidence \u2014 logs, screenshots, command output. You never confuse "no error" with "passed".
`,
    agents: `# Behavior rules

## Test discipline
- Define expected before running.
- Capture actual exhaustively (stdout, stderr, exit code, response body).
- Diff expected vs actual programmatically when possible \u2014 eyeballing is for cosmetic checks only.

## Reporting
- Report format: \`status | scenario | expected | actual | evidence\`.
- One row per scenario. No summary-without-rows.
- A pass is a pass. A skip is a skip. Don't blur them.

## Hard rules
- Never modify the system under test "just to make it pass".
- Never report green if any assertion was skipped silently.
`,
    tools: TOOLS_WORKER,
    skills: ["test-driven-development", "systematic-debugging"]
  },
  {
    id: "mirror",
    iconName: "i-lucide-arrow-left-right",
    accent: "3a5a3a",
    suggestedSlug: "mirror",
    soul: `# Who You Are

- **Role:** Mirror Integrations
- **Vibe:** Bridge-builder. Keeps upstream and downstream in sync.
- **Boundary:** You ferry artifacts; you don't transform them in transit.

## Core truths

You handle upstream sync, integrations, asset packs. You move things between systems without dropping data, mangling timestamps, or losing fidelity. Lossless > clever.
`,
    agents: `# Behavior rules

## Sync discipline
- Before pulling a new upstream version, check what local changes exist. Don't clobber.
- Conflicts get surfaced to the user with both sides shown \u2014 never silently picked.
- Asset packs come with manifests. If the manifest doesn't match what's on disk, stop and ask.

## Quality
- Verify checksums when available.
- Preserve filenames and case exactly.
- If a transform is needed, do it in a separate task, not during sync.

## Hard rules
- Never overwrite a file whose contents you haven't read first.
- Never push a sync result without comparing line counts before/after.
`,
    tools: TOOLS_WORKER,
    skills: ["rclone", "github-repo-management"]
  },
  {
    id: "custom",
    iconName: "i-lucide-square-pen",
    accent: "6b6555",
    suggestedSlug: "",
    soul: "",
    agents: "",
    tools: [],
    skills: []
  }
];

const HERMES_HOME$2 = process.env.HERMES_HOME || join(homedir(), ".hermes");
const GLOBAL_CONFIG_PATH = join(HERMES_HOME$2, "config.yaml");
function readGlobalModelConfig() {
  var _a, _b;
  if (!existsSync(GLOBAL_CONFIG_PATH)) return { model: null, provider: null };
  try {
    const cfg = parse$2(readFileSync(GLOBAL_CONFIG_PATH, "utf8"));
    return {
      model: typeof ((_a = cfg == null ? void 0 : cfg.model) == null ? void 0 : _a.default) === "string" ? cfg.model.default : null,
      provider: typeof ((_b = cfg == null ? void 0 : cfg.model) == null ? void 0 : _b.provider) === "string" ? cfg.model.provider : null
    };
  } catch {
    return { model: null, provider: null };
  }
}
function readGlobalModelBlock() {
  if (!existsSync(GLOBAL_CONFIG_PATH)) return null;
  try {
    const cfg = parse$2(readFileSync(GLOBAL_CONFIG_PATH, "utf8"));
    if (!(cfg == null ? void 0 : cfg.model)) return null;
    const m = cfg.model;
    return {
      default: typeof m.default === "string" ? m.default : null,
      provider: typeof m.provider === "string" ? m.provider : null,
      base_url: typeof m.base_url === "string" ? m.base_url : null,
      api_key: typeof m.api_key === "string" ? m.api_key : null
    };
  } catch {
    return null;
  }
}
function configPath(profileDir) {
  return join(profileDir, "config.yaml");
}
function readProfileConfig(profileDir) {
  var _a, _b;
  const path = configPath(profileDir);
  if (!existsSync(path)) return { model: null, provider: null, allowlist: [], name: null };
  try {
    const raw = readFileSync(path, "utf8");
    const cfg = parse$2(raw);
    const modelDefault = (_a = cfg == null ? void 0 : cfg.model) == null ? void 0 : _a.default;
    const provider = (_b = cfg == null ? void 0 : cfg.model) == null ? void 0 : _b.provider;
    const name = cfg == null ? void 0 : cfg.name;
    const list = Array.isArray(cfg == null ? void 0 : cfg.command_allowlist) ? cfg.command_allowlist : [];
    return {
      model: typeof modelDefault === "string" ? modelDefault : null,
      provider: typeof provider === "string" ? provider : null,
      name: typeof name === "string" ? name.trim() : null,
      allowlist: list.filter((v) => typeof v === "string")
    };
  } catch {
    return { model: null, provider: null, allowlist: [], name: null };
  }
}
function writeProfileConfig(profileDir, patch) {
  const path = configPath(profileDir);
  const raw = existsSync(path) ? readFileSync(path, "utf8") : "";
  const doc = parseDocument(raw);
  if (patch.inheritGlobalModel) {
    const global = readGlobalModelBlock();
    if (global) {
      doc.set("model", {
        ...global.default !== null ? { default: global.default } : {},
        ...global.provider !== null ? { provider: global.provider } : {},
        ...global.base_url !== null ? { base_url: global.base_url } : {},
        ...global.api_key !== null ? { api_key: global.api_key } : {}
      });
    } else {
      if (doc.has("model")) doc.delete("model");
    }
  } else if ("model" in patch || "provider" in patch) {
    const existing = doc.get("model", true);
    if (existing != null && !isMap(existing)) {
      throw new Error("model: section in config.yaml is not a mapping");
    }
    const globalModel = readGlobalModelConfig();
    const trim = (v) => typeof v === "string" ? v.trim() : v;
    if ("model" in patch) {
      const v = trim(patch.model);
      const matchesGlobal = !!v && v === globalModel.model;
      if (!v || matchesGlobal) {
        if (doc.hasIn(["model", "default"])) doc.deleteIn(["model", "default"]);
      } else {
        doc.setIn(["model", "default"], v);
      }
    }
    if ("provider" in patch) {
      const v = trim(patch.provider);
      const matchesGlobal = !!v && v === globalModel.provider;
      if (!v || matchesGlobal) {
        if (doc.hasIn(["model", "provider"])) doc.deleteIn(["model", "provider"]);
      } else {
        doc.setIn(["model", "provider"], v);
      }
    }
    const after = doc.get("model", true);
    if (after && isMap(after) && after.items.length === 0) {
      doc.delete("model");
    }
  }
  if (Array.isArray(patch.allowlist)) {
    const cleaned = [...new Set(patch.allowlist.filter((s) => typeof s === "string" && s.trim() !== ""))];
    doc.set("command_allowlist", cleaned);
  }
  if ("name" in patch) {
    if (patch.name === null || typeof patch.name === "string" && patch.name.trim() === "") {
      if (doc.has("name")) doc.delete("name");
    } else if (typeof patch.name === "string") {
      doc.set("name", patch.name.trim());
    }
  }
  const al = doc.get("command_allowlist", true);
  if (al && !Array.isArray(al.items) && isScalar(al)) {
    doc.set("command_allowlist", []);
  }
  const tmp = `${path}.tmp-${process.pid}-${Date.now()}`;
  try {
    writeFileSync(tmp, doc.toString(), { mode: 384 });
    renameSync(tmp, path);
  } catch (e) {
    try {
      unlinkSync(tmp);
    } catch {
    }
    throw e;
  }
}

const HERMES_HOME$1 = process.env.HERMES_HOME || join(homedir(), ".hermes");
const SKILL_NAME_LIMIT = 200;
const FRONTMATTER_RE = /^---\r?\n([\s\S]*?)\r?\n---/;
function readFrontmatter(file) {
  try {
    const head = readFileSync(file, "utf8").slice(0, 4096);
    const match = head.match(FRONTMATTER_RE);
    if (!match || !match[1]) return null;
    const parsed = parse$2(match[1]);
    return parsed && typeof parsed === "object" ? parsed : null;
  } catch {
    return null;
  }
}
function walkSkills(root, source) {
  if (!existsSync(root)) return [];
  const out = [];
  const visit = (dir) => {
    var _a, _b;
    let entries;
    try {
      entries = readdirSync(dir);
    } catch {
      return;
    }
    const skillFile = join(dir, "SKILL.md");
    if (existsSync(skillFile)) {
      const fm = readFrontmatter(skillFile);
      const rel = relative(root, dir);
      const parts = rel.split(/[\\/]/);
      const name = (((_a = fm == null ? void 0 : fm.name) == null ? void 0 : _a.trim()) || parts[parts.length - 1] || rel).slice(0, SKILL_NAME_LIMIT);
      const category = parts.length > 1 ? parts.slice(0, -1).join("/") : null;
      const description = ((_b = fm == null ? void 0 : fm.description) == null ? void 0 : _b.trim()) || null;
      out.push({ name, category, description, source, path: dir });
      return;
    }
    for (const entry of entries) {
      if (entry.startsWith(".")) continue;
      const full = join(dir, entry);
      try {
        if (statSync(full).isDirectory()) visit(full);
      } catch {
      }
    }
  };
  visit(root);
  return out;
}
function listGlobalSkills() {
  return [
    ...walkSkills(join(HERMES_HOME$1, "hermes-agent", "skills"), "builtin"),
    ...walkSkills(join(HERMES_HOME$1, "skills"), "global")
  ];
}
function listProfileSkills(profileDir) {
  return walkSkills(join(profileDir, "skills"), "profile");
}
function profileConfigPath(profileDir) {
  return join(profileDir, "config.yaml");
}
function getDisabledSkills(profileDir) {
  var _a;
  const cfgPath = profileConfigPath(profileDir);
  if (!existsSync(cfgPath)) return [];
  try {
    const raw = readFileSync(cfgPath, "utf8");
    const cfg = parse$2(raw);
    const disabled = (_a = cfg == null ? void 0 : cfg.skills) == null ? void 0 : _a.disabled;
    if (!Array.isArray(disabled)) return [];
    return disabled.filter((v) => typeof v === "string");
  } catch {
    return [];
  }
}
const PROTECTED_SKILLS = /* @__PURE__ */ new Set(["kanban-worker"]);
function setDisabledSkills(profileDir, disabled) {
  const cfgPath = profileConfigPath(profileDir);
  const raw = existsSync(cfgPath) ? readFileSync(cfgPath, "utf8") : "";
  const doc = parseDocument(raw);
  const sorted = [...new Set(disabled.filter((s) => !PROTECTED_SKILLS.has(s)))].sort();
  if (!doc.has("skills")) {
    doc.set("skills", { disabled: sorted });
  } else {
    doc.setIn(["skills", "disabled"], sorted);
  }
  const tmp = `${cfgPath}.tmp-${process.pid}-${Date.now()}`;
  try {
    writeFileSync(tmp, doc.toString(), { mode: 384 });
    renameSync(tmp, cfgPath);
  } catch (e) {
    try {
      unlinkSync(tmp);
    } catch {
    }
    throw e;
  }
}

const HERMES_HOME = process.env.HERMES_HOME || join(homedir(), ".hermes");
const LOG_TAIL_BYTES = 24 * 1024;
const LOG_TAIL_LINES = 80;
function readLogTail(taskId) {
  const path = logPath(taskId);
  if (!existsSync(path)) return { tail: null, bytes: null, startedAt: null };
  try {
    const st = statSync(path);
    const startedAt = Math.floor(st.birthtimeMs || st.ctimeMs || st.mtimeMs);
    const buf = readFileSync(path, { encoding: "utf8" });
    const sliced = buf.length > LOG_TAIL_BYTES ? buf.slice(buf.length - LOG_TAIL_BYTES) : buf;
    const cleaned = buf.length > LOG_TAIL_BYTES ? sliced.slice(sliced.indexOf("\n") + 1) : sliced;
    const lines = cleaned.split("\n");
    const tail = lines.slice(-LOG_TAIL_LINES).join("\n").trimEnd();
    return { tail: tail || null, bytes: st.size, startedAt };
  } catch {
    return { tail: null, bytes: null, startedAt: null };
  }
}
const SESSION_ID_RE = /Session:\s*([A-Za-z0-9_]+)/;
const PROFILE_RE = /Profile:\s*([a-z0-9_-]+)/i;
function logPath(taskId) {
  return join(HERMES_HOME, "kanban", "logs", `${taskId}.log`);
}
function readLogHead(taskId) {
  const path = logPath(taskId);
  if (!existsSync(path)) return null;
  try {
    return readFileSync(path, { encoding: "utf8", flag: "r" }).slice(0, 8192);
  } catch {
    return null;
  }
}
function findSessionIdInLog(taskId) {
  var _a, _b;
  const head = readLogHead(taskId);
  return head ? (_b = (_a = head.match(SESSION_ID_RE)) == null ? void 0 : _a[1]) != null ? _b : null : null;
}
function findProfileInLog(taskId) {
  var _a, _b;
  const head = readLogHead(taskId);
  return head ? (_b = (_a = head.match(PROFILE_RE)) == null ? void 0 : _a[1]) != null ? _b : null : null;
}
const ASSIGNEE_CACHE = /* @__PURE__ */ new Map();
function findTaskAssignee(taskId) {
  var _a;
  const dbPath = join(HERMES_HOME, "kanban.db");
  if (!existsSync(dbPath)) return null;
  const mtime = statSync(dbPath).mtimeMs;
  const cached = ASSIGNEE_CACHE.get(taskId);
  if (cached && cached.mtime === mtime) return cached.profile;
  try {
    const db = new DatabaseSync(dbPath, { readOnly: true });
    const row = db.prepare("SELECT assignee FROM tasks WHERE id = ?").get(taskId);
    db.close();
    const profile = (_a = row == null ? void 0 : row.assignee) != null ? _a : null;
    ASSIGNEE_CACHE.set(taskId, { profile, mtime });
    return profile;
  } catch {
    return null;
  }
}
function parseToolCalls(raw) {
  if (!raw) return null;
  try {
    return JSON.parse(raw);
  } catch {
    return raw;
  }
}
function combineReasoning(row) {
  var _a, _b, _c;
  const parts = [];
  if ((_a = row.reasoning) == null ? void 0 : _a.trim()) parts.push(row.reasoning.trim());
  if (((_b = row.reasoning_content) == null ? void 0 : _b.trim()) && row.reasoning_content.trim() !== ((_c = row.reasoning) == null ? void 0 : _c.trim())) {
    parts.push(row.reasoning_content.trim());
  }
  return parts.length ? parts.join("\n\n") : null;
}
function getTaskFeed(taskId, opts = {}) {
  var _a, _b, _c, _d, _e, _f, _g, _h;
  const profile = (_b = (_a = opts.profileHint) != null ? _a : findTaskAssignee(taskId)) != null ? _b : findProfileInLog(taskId);
  const log = logPath(taskId);
  const started = existsSync(log);
  const lastActivityAt = started ? statSync(log).mtimeMs : null;
  const { tail: logTail, bytes: logBytes, startedAt } = readLogTail(taskId);
  const empty = {
    taskId,
    profile,
    sessionId: null,
    started,
    lastActivityAt,
    startedAt,
    messages: [],
    logTail,
    logBytes,
    totals: null
  };
  if (!profile) return empty;
  const sessionId = findSessionIdInLog(taskId);
  if (!sessionId) return empty;
  const stateDbPath = join(HERMES_HOME, "profiles", profile, "state.db");
  if (!existsSync(stateDbPath)) {
    return { ...empty, sessionId };
  }
  try {
    const db = new DatabaseSync(stateDbPath, { readOnly: true });
    const sessionRow = db.prepare(
      `SELECT message_count, input_tokens, output_tokens,
              cache_read_tokens, cache_write_tokens, estimated_cost_usd
         FROM sessions WHERE id = ?`
    ).get(sessionId);
    const rows = db.prepare(
      `SELECT id, role, content, tool_name, tool_calls,
              reasoning, reasoning_content, timestamp, token_count, finish_reason
         FROM messages
        WHERE session_id = ?
        ORDER BY id ASC`
    ).all(sessionId);
    db.close();
    const messages = rows.map((r) => ({
      id: r.id,
      role: r.role,
      content: r.content,
      toolName: r.tool_name,
      toolCalls: parseToolCalls(r.tool_calls),
      reasoning: combineReasoning(r),
      timestamp: r.timestamp,
      tokenCount: r.token_count,
      finishReason: r.finish_reason
    }));
    return {
      taskId,
      profile,
      sessionId,
      started,
      lastActivityAt,
      startedAt,
      messages,
      logTail,
      logBytes,
      totals: sessionRow ? {
        messageCount: (_c = sessionRow.message_count) != null ? _c : 0,
        inputTokens: (_d = sessionRow.input_tokens) != null ? _d : 0,
        outputTokens: (_e = sessionRow.output_tokens) != null ? _e : 0,
        cacheReadTokens: (_f = sessionRow.cache_read_tokens) != null ? _f : 0,
        cacheWriteTokens: (_g = sessionRow.cache_write_tokens) != null ? _g : 0,
        estimatedCostUsd: (_h = sessionRow.estimated_cost_usd) != null ? _h : 0
      } : null
    };
  } catch (e) {
    console.error(`[task-feed] read failed for ${taskId} (${profile}/${sessionId}):`, e.message);
    return { ...empty, sessionId };
  }
}

const ZERO_USAGE = {
  totalIn: 0,
  totalOut: 0,
  totalCache: 0,
  sessionIn: 0,
  sessionOut: 0,
  recentIn: 0,
  recentOut: 0,
  totalCostUsd: 0,
  lastActivityAt: null,
  present: false
};
const handles = /* @__PURE__ */ new Map();
function getDb(profileDir) {
  const path = join(profileDir, "state.db");
  if (!existsSync(path)) return null;
  const cached = handles.get(path);
  if (cached) return cached.db;
  try {
    const db = new DatabaseSync(path, { readOnly: true });
    handles.set(path, { db, mtime: 0 });
    return db;
  } catch {
    return null;
  }
}
const RECENT_WINDOW_S = 60;
function readTokenUsage(profileDir) {
  var _a, _b;
  const db = getDb(profileDir);
  if (!db) return ZERO_USAGE;
  try {
    const totals = db.prepare(`
      SELECT
        COALESCE(SUM(input_tokens), 0)        AS totalIn,
        COALESCE(SUM(output_tokens), 0)       AS totalOut,
        COALESCE(SUM(cache_read_tokens), 0)
          + COALESCE(SUM(cache_write_tokens), 0) AS totalCache,
        COALESCE(SUM(estimated_cost_usd), 0)  AS totalCostUsd,
        MAX(COALESCE(ended_at, started_at))   AS lastActivityAt
      FROM sessions
    `).get();
    const latest = db.prepare(`
      SELECT
        COALESCE(input_tokens, 0)  AS sessionIn,
        COALESCE(output_tokens, 0) AS sessionOut
      FROM sessions
      ORDER BY started_at DESC
      LIMIT 1
    `).get();
    const cutoff = Math.floor(Date.now() / 1e3) - RECENT_WINDOW_S;
    const recent = db.prepare(`
      SELECT
        COALESCE(SUM(input_tokens), 0)  AS recentIn,
        COALESCE(SUM(output_tokens), 0) AS recentOut
      FROM sessions
      WHERE started_at > ?
    `).get(cutoff);
    return {
      totalIn: totals.totalIn,
      totalOut: totals.totalOut,
      totalCache: totals.totalCache,
      sessionIn: (_a = latest == null ? void 0 : latest.sessionIn) != null ? _a : 0,
      sessionOut: (_b = latest == null ? void 0 : latest.sessionOut) != null ? _b : 0,
      recentIn: recent.recentIn,
      recentOut: recent.recentOut,
      totalCostUsd: totals.totalCostUsd,
      lastActivityAt: totals.lastActivityAt,
      present: true
    };
  } catch (e) {
    console.error(`[tokens] failed to read ${profileDir}:`, e.message);
    return { ...ZERO_USAGE, present: true };
  }
}

function runHermes(args) {
  return new Promise((resolve, reject) => {
    const child = spawn("hermes", args, { stdio: ["ignore", "pipe", "pipe"] });
    child.stdout.setEncoding("utf8");
    child.stderr.setEncoding("utf8");
    let stdout = "";
    let stderr = "";
    child.stdout.on("data", (d) => stdout += d);
    child.stderr.on("data", (d) => stderr += d);
    child.on("error", reject);
    child.on("close", (code) => resolve({ code: code != null ? code : -1, stdout, stderr }));
  });
}
const ANSI_RE = /\x1B\[[0-9;]*m/g;
const TOOL_LINE_RE = /^\s*(✓|✗)\s+(enabled|disabled)\s+(\S+)\s+(.+?)\s*$/;
async function listTools(profileSlug) {
  const args = [];
  if (profileSlug) args.push("-p", profileSlug);
  args.push("tools", "list", "--platform", "cli");
  const { code, stdout, stderr } = await runHermes(args);
  if (code !== 0) {
    throw new Error(stderr.trim() || `hermes tools list exited ${code}`);
  }
  const out = [];
  let inBuiltins = false;
  for (const rawLine of stdout.split("\n")) {
    const line = rawLine.replace(ANSI_RE, "");
    if (line.startsWith("Built-in toolsets")) {
      inBuiltins = true;
      continue;
    }
    if (inBuiltins && (line.startsWith("MCP servers") || line.trim() === "")) {
      if (line.startsWith("MCP servers")) break;
      if (out.length > 0) break;
      continue;
    }
    if (!inBuiltins) continue;
    const m = line.match(TOOL_LINE_RE);
    if (m) {
      out.push({
        name: m[3],
        label: m[4].trim(),
        enabled: m[2] === "enabled"
      });
    }
  }
  return out;
}
async function applyToolState(profileSlug, toEnable, toDisable) {
  for (const [verb, names] of [["enable", toEnable], ["disable", toDisable]]) {
    if (names.length === 0) continue;
    const args = ["-p", profileSlug, "tools", verb, "--platform", "cli", ...names];
    const { code, stderr } = await runHermes(args);
    if (code !== 0) {
      throw new Error(stderr.trim() || `hermes tools ${verb} exited ${code}`);
    }
  }
}

function useRuntimeI18n(nuxtApp, event) {
  {
    return useRuntimeConfig(event).public.i18n;
  }
}
function useI18nDetection(nuxtApp) {
  const detectBrowserLanguage = useRuntimeI18n().detectBrowserLanguage;
  const detect = detectBrowserLanguage || {};
  return {
    ...detect,
    enabled: !!detectBrowserLanguage,
    cookieKey: detect.cookieKey || "i18n_redirected"
  };
}
function resolveRootRedirect(config) {
  if (!config) {
    return void 0;
  }
  return {
    path: "/" + (isString(config) ? config : config.path).replace(/^\//, ""),
    code: !isString(config) && config.statusCode || 302
  };
}
function toArray(value) {
  return Array.isArray(value) ? value : [value];
}

function createLocaleConfigs(fallbackLocale) {
  const localeConfigs = {};
  for (const locale of localeCodes) {
    const fallbacks = getFallbackLocaleCodes(fallbackLocale, [locale]);
    const cacheable = isLocaleWithFallbacksCacheable(locale, fallbacks);
    localeConfigs[locale] = { fallbacks, cacheable };
  }
  return localeConfigs;
}
function getFallbackLocaleCodes(fallback, locales) {
  if (fallback === false) {
    return [];
  }
  if (isArray(fallback)) {
    return fallback;
  }
  let fallbackLocales = [];
  if (isString(fallback)) {
    if (locales.every((locale) => locale !== fallback)) {
      fallbackLocales.push(fallback);
    }
    return fallbackLocales;
  }
  const targets = [...locales, "default"];
  for (const locale of targets) {
    if (locale in fallback == false) {
      continue;
    }
    fallbackLocales = [...fallbackLocales, ...fallback[locale].filter(Boolean)];
  }
  return fallbackLocales;
}
function isLocaleCacheable(locale) {
  return localeLoaders[locale] != null && localeLoaders[locale].every((loader) => loader.cache !== false);
}
function isLocaleWithFallbacksCacheable(locale, fallbackLocales) {
  return isLocaleCacheable(locale) && fallbackLocales.every((fallbackLocale) => isLocaleCacheable(fallbackLocale));
}
function getDefaultLocaleForDomain(host) {
  return normalizedLocales.find((l) => !!l.defaultForDomains?.includes(host))?.code;
}
const isSupportedLocale = (locale) => localeCodes.includes(locale || "");

function useI18nContext(event) {
  if (event.context.nuxtI18n == null) {
    throw new Error("Nuxt I18n server context has not been set up yet.");
  }
  return event.context.nuxtI18n;
}
function tryUseI18nContext(event) {
  return event.context.nuxtI18n;
}
const getHost = (event) => getRequestURL(event, { xForwardedHost: true }).host;
async function initializeI18nContext(event) {
  const runtimeI18n = useRuntimeI18n(void 0, event);
  const defaultLocale = runtimeI18n.defaultLocale || "";
  const options = await setupVueI18nOptions(getDefaultLocaleForDomain(getHost(event)) || defaultLocale);
  const localeConfigs = createLocaleConfigs(options.fallbackLocale);
  const ctx = createI18nContext();
  ctx.vueI18nOptions = options;
  ctx.localeConfigs = localeConfigs;
  event.context.nuxtI18n = ctx;
  return ctx;
}
function createI18nContext() {
  return {
    messages: {},
    slp: {},
    localeConfigs: {},
    trackMap: {},
    vueI18nOptions: void 0,
    trackKey(key, locale) {
      this.trackMap[locale] ??= /* @__PURE__ */ new Set();
      this.trackMap[locale].add(key);
    }
  };
}

function matchBrowserLocale(locales, browserLocales) {
  const matchedLocales = [];
  for (const [index, browserCode] of browserLocales.entries()) {
    const matchedLocale = locales.find((l) => l.language?.toLowerCase() === browserCode.toLowerCase());
    if (matchedLocale) {
      matchedLocales.push({ code: matchedLocale.code, score: 1 - index / browserLocales.length });
      break;
    }
  }
  for (const [index, browserCode] of browserLocales.entries()) {
    const languageCode = browserCode.split("-")[0].toLowerCase();
    const matchedLocale = locales.find((l) => l.language?.split("-")[0].toLowerCase() === languageCode);
    if (matchedLocale) {
      matchedLocales.push({ code: matchedLocale.code, score: 0.999 - index / browserLocales.length });
      break;
    }
  }
  return matchedLocales;
}
function compareBrowserLocale(a, b) {
  if (a.score === b.score) {
    return b.code.length - a.code.length;
  }
  return b.score - a.score;
}
function findBrowserLocale(locales, browserLocales) {
  const matchedLocales = matchBrowserLocale(
    locales.map((l) => ({ code: l.code, language: l.language || l.code })),
    browserLocales
  );
  return matchedLocales.sort(compareBrowserLocale).at(0)?.code ?? "";
}

const appHead = {"meta":[{"name":"viewport","content":"width=device-width, initial-scale=1"},{"charset":"utf-8"}],"link":[],"style":[],"script":[],"noscript":[]};

const appRootTag = "div";

const appRootAttrs = {"id":"__nuxt","class":"isolate"};

const appTeleportTag = "div";

const appTeleportAttrs = {"id":"teleports"};

const appSpaLoaderTag = "div";

const appSpaLoaderAttrs = {"id":"__nuxt-loader"};

const appId = "nuxt-app";

const separator = "___";
const pathLanguageParser = createPathIndexLanguageParser(0);
const getLocaleFromRoutePath = (path) => pathLanguageParser(path);
const getLocaleFromRouteName = (name) => name.split(separator).at(1) ?? "";
function normalizeInput(input) {
  return typeof input !== "object" ? String(input) : String(input?.name || input?.path || "");
}
function getLocaleFromRoute(route) {
  const input = normalizeInput(route);
  if (input[0] === "/") {
    return getLocaleFromRoutePath(input);
  }
  const fromName = getLocaleFromRouteName(input);
  if (fromName) {
    return fromName;
  }
  if (typeof route === "object" && route?.path) {
    return getLocaleFromRoutePath(String(route.path));
  }
  return "";
}

function matchDomainLocale(locales, host, pathLocale) {
  const normalizeDomain = (domain = "") => domain.replace(/https?:\/\//, "");
  const matches = locales.filter(
    (locale) => normalizeDomain(locale.domain) === host || toArray(locale.domains).includes(host)
  );
  if (matches.length <= 1) {
    return matches[0]?.code;
  }
  return (
    // match by current path locale
    matches.find((l) => l.code === pathLocale)?.code || matches.find((l) => l.defaultForDomains?.includes(host) ?? l.domainDefault)?.code
  );
}

const getCookieLocale = (event, cookieName) => (getCookie(event, cookieName)) || void 0;
const getRouteLocale = (event, route) => getLocaleFromRoute(route);
const getHeaderLocale = (event) => findBrowserLocale(normalizedLocales, parseAcceptLanguage(getRequestHeader(event, "accept-language") || ""));
const getHostLocale = (event, path, domainLocales) => {
  const host = getRequestURL(event, { xForwardedHost: true }).host;
  const locales = normalizedLocales.map((l) => ({
    ...l,
    domain: domainLocales[l.code]?.domain ?? l.domain
  }));
  return matchDomainLocale(locales, host, getLocaleFromRoutePath(path));
};
const useDetectors = (event, config, nuxtApp) => {
  if (!event) {
    throw new Error("H3Event is required for server-side locale detection");
  }
  const runtimeI18n = useRuntimeI18n();
  return {
    cookie: () => getCookieLocale(event, config.cookieKey),
    header: () => getHeaderLocale(event) ,
    navigator: () => void 0,
    host: (path) => getHostLocale(event, path, runtimeI18n.domainLocales),
    route: (path) => getRouteLocale(event, path)
  };
};

// Generated by @nuxtjs/i18n
const pathToI18nConfig = {
  "/missions": {
    "en": "/missions",
    "es": "/missions"
  },
  "/team": {
    "en": "/team",
    "es": "/team"
  },
  "/": {
    "en": "/",
    "es": "/"
  }
};
const i18nPathToPath = {
  "/missions": "/missions",
  "/team": "/team",
  "/": "/"
};

const formatTrailingSlash = withoutTrailingSlash;
const matcher = createRouterMatcher([], {});
for (const path of Object.keys(i18nPathToPath)) {
  matcher.addRoute({ path, component: () => "", meta: {} });
}
const getI18nPathToI18nPath = (path, locale) => {
  if (!path || !locale) {
    return;
  }
  const plainPath = i18nPathToPath[path];
  const i18nConfig = pathToI18nConfig[plainPath];
  if (i18nConfig && i18nConfig[locale]) {
    return i18nConfig[locale] === true ? plainPath : i18nConfig[locale];
  }
};
function isExistingNuxtRoute(path) {
  if (path === "") {
    return;
  }
  if (path.endsWith("/__nuxt_error")) {
    return;
  }
  const resolvedMatch = matcher.resolve({ path }, { path: "/", name: "", matched: [], params: {}, meta: {} });
  return resolvedMatch.matched.length > 0 ? resolvedMatch : void 0;
}
function matchLocalized(path, locale, defaultLocale) {
  if (path === "") {
    return;
  }
  const parsed = parsePath(path);
  const resolvedMatch = matcher.resolve(
    { path: parsed.pathname || "/" },
    { path: "/", name: "", matched: [], params: {}, meta: {} }
  );
  if (resolvedMatch.matched.length > 0) {
    const alternate = getI18nPathToI18nPath(resolvedMatch.matched[0].path, locale);
    const match = matcher.resolve(
      { params: resolvedMatch.params },
      { path: alternate || "/", name: "", matched: [], params: {}, meta: {} }
    );
    return formatTrailingSlash(withLeadingSlash(joinURL("", match.path)), true);
  }
}

function* detect(detectors, detection, path) {
  if (detection.enabled) {
    yield { locale: detectors.cookie(), source: "cookie" };
    yield { locale: detectors.header(), source: "header" };
  }
  yield { locale: detection.fallbackLocale, source: "fallback" };
}
function createRedirectResponse(event, dest, code) {
  event.node.res.setHeader("location", dest);
  event.node.res.statusCode = sanitizeStatusCode(code, event.node.res.statusCode);
  return {
    headers: event.node.res.getHeaders(),
    statusCode: event.node.res.statusCode,
    body: `<!DOCTYPE html><html><head><meta http-equiv="refresh" content="0; url=${dest.replace(/"/g, "%22")}"></head></html>`
  };
}
const _fUwBaQoeFfqheMvYbwQe1ClUL8_4QeozRRaRRe4hGk = defineNitroPlugin(async (nitro) => {
  const runtimeI18n = useRuntimeI18n();
  const rootRedirect = resolveRootRedirect(runtimeI18n.rootRedirect);
  runtimeI18n.defaultLocale || "";
  try {
    const cacheStorage = useStorage("cache");
    const cachedKeys = await cacheStorage.getKeys("nitro:handlers:i18n");
    await Promise.all(cachedKeys.map((key) => cacheStorage.removeItem(key)));
  } catch {
  }
  const detection = useI18nDetection();
  const cookieOptions = {
    path: "/",
    domain: detection.cookieDomain || void 0,
    maxAge: 60 * 60 * 24 * 365,
    sameSite: "lax",
    secure: detection.cookieSecure
  };
  const createBaseUrlGetter = () => {
    isFunction(runtimeI18n.baseUrl) ? "" : runtimeI18n.baseUrl || "";
    if (isFunction(runtimeI18n.baseUrl)) {
      return () => "";
    }
    return (event, defaultLocale) => {
      return "";
    };
  };
  function resolveRedirectPath(event, path, pathLocale, defaultLocale, detector) {
    let locale = "";
    for (const detected of detect(detector, detection, event.path)) {
      if (detected.locale && isSupportedLocale(detected.locale)) {
        locale = detected.locale;
        break;
      }
    }
    locale ||= defaultLocale;
    function getLocalizedMatch(locale2) {
      const res = matchLocalized(path || "/", locale2);
      if (res && res !== event.path) {
        return res;
      }
    }
    let resolvedPath = void 0;
    let redirectCode = 302;
    const requestURL = getRequestURL(event);
    if (rootRedirect && requestURL.pathname === "/") {
      locale = detection.enabled && locale || defaultLocale;
      resolvedPath = isSupportedLocale(detector.route(rootRedirect.path)) && rootRedirect.path || matchLocalized(rootRedirect.path, locale);
      redirectCode = rootRedirect.code;
    } else if (runtimeI18n.redirectStatusCode) {
      redirectCode = runtimeI18n.redirectStatusCode;
    }
    switch (detection.redirectOn) {
      case "root":
        if (requestURL.pathname !== "/") {
          break;
        }
      // fallthrough (root has no prefix)
      case "no prefix":
        if (pathLocale) {
          break;
        }
      // fallthrough to resolve
      case "all":
        resolvedPath ??= getLocalizedMatch(locale);
        break;
    }
    if (requestURL.pathname === "/" && "no_prefix" === "prefix") ;
    return { path: resolvedPath, code: redirectCode, locale };
  }
  const baseUrlGetter = createBaseUrlGetter();
  nitro.hooks.hook("request", async (event) => {
    await initializeI18nContext(event);
  });
  nitro.hooks.hook("render:before", async (context) => {
    const { event } = context;
    const ctx = useI18nContext(event);
    const url = getRequestURL(event);
    const detector = useDetectors(event, detection);
    const localeSegment = detector.route(event.path);
    const pathLocale = isSupportedLocale(localeSegment) && localeSegment || void 0;
    const path = (pathLocale && url.pathname.slice(pathLocale.length + 1)) ?? url.pathname;
    if (!url.pathname.includes("/_i18n") && !isExistingNuxtRoute(path)) {
      return;
    }
    const resolved = resolveRedirectPath(event, path, pathLocale, ctx.vueI18nOptions.defaultLocale, detector);
    if (resolved.path && resolved.path !== url.pathname) {
      ctx.detectLocale = resolved.locale;
      detection.useCookie && setCookie(event, detection.cookieKey, resolved.locale, cookieOptions);
      context.response = createRedirectResponse(
        event,
        joinURL(baseUrlGetter(event, ctx.vueI18nOptions.defaultLocale), resolved.path + url.search),
        resolved.code
      );
      return;
    }
  });
  nitro.hooks.hook("render:html", (htmlContext, { event }) => {
    tryUseI18nContext(event);
  });
});

const script = "\"use strict\";(()=>{const t=window,e=document.documentElement,c=[\"dark\",\"light\"],n=getStorageValue(\"localStorage\",\"nuxt-color-mode\")||\"system\";let i=n===\"system\"?u():n;const r=e.getAttribute(\"data-color-mode-forced\");r&&(i=r),l(i),t[\"__NUXT_COLOR_MODE__\"]={preference:n,value:i,getColorScheme:u,addColorScheme:l,removeColorScheme:d};function l(o){const s=\"\"+o+\"\",a=\"\";e.classList?e.classList.add(s):e.className+=\" \"+s,a&&e.setAttribute(\"data-\"+a,o)}function d(o){const s=\"\"+o+\"\",a=\"\";e.classList?e.classList.remove(s):e.className=e.className.replace(new RegExp(s,\"g\"),\"\"),a&&e.removeAttribute(\"data-\"+a)}function f(o){return t.matchMedia(\"(prefers-color-scheme\"+o+\")\")}function u(){if(t.matchMedia&&f(\"\").media!==\"not all\"){for(const o of c)if(f(\":\"+o).matches)return o}return\"light\"}})();function getStorageValue(t,e){switch(t){case\"localStorage\":return window.localStorage.getItem(e);case\"sessionStorage\":return window.sessionStorage.getItem(e);case\"cookie\":return getCookie(e);default:return null}}function getCookie(t){const c=(\"; \"+window.document.cookie).split(\"; \"+t+\"=\");if(c.length===2)return c.pop()?.split(\";\").shift()}";

const _QBjSuN2dl8IkwAvnr5P1X__eBiFktLoMkBOQs0C9V4 = (function(nitro) {
  nitro.hooks.hook("render:html", (htmlContext) => {
    htmlContext.head.push(`<script>${script}<\/script>`);
  });
});

const _ICETcJ3NhFoMfJX2x_ZVYFFVgXOtXxjXwRVER9bmT9o = defineNitroPlugin(() => {
  loadWatchedFromDb();
  startAutoNudge();
});

const _7e_IGRuIQhiEbEbg2GWLj9JKsirqPMjKvyoudnXO4HE = defineNitroPlugin(() => {
  const db = useDb();
  const orphans = db.prepare(`
    SELECT id, orchestrator_slug, last_message_at
      FROM missions
     WHERE status = 'open'
       AND id NOT IN (
         SELECT id FROM (
           SELECT id,
                  ROW_NUMBER() OVER (
                    PARTITION BY orchestrator_slug
                    ORDER BY last_message_at DESC
                  ) AS rn
             FROM missions
            WHERE status = 'open'
         ) WHERE rn = 1
       )
  `).all();
  if (orphans.length === 0) return;
  const ids = orphans.map((o) => o.id);
  const placeholders = ids.map(() => "?").join(",");
  db.prepare(`UPDATE missions SET status = 'archived' WHERE id IN (${placeholders})`).run(...ids);
  db.prepare(`DELETE FROM mission_watched_tasks WHERE mission_id IN (${placeholders})`).run(...ids);
  console.log(
    `[mission-cleanup] archived ${orphans.length} orphan open mission(s):`,
    orphans.map((o) => `${o.orchestrator_slug}/${o.id.slice(0, 8)}`).join(", ")
  );
});

const PROTECTED = /* @__PURE__ */ new Set(["kanban-worker"]);
const _n6bSztapAOwr6rbziC9Wb86XNjye196eWKaHqA91lr8 = defineNitroPlugin(() => {
  let fixed = 0;
  for (const p of discoverProfiles()) {
    try {
      const disabled = getDisabledSkills(p.hermesDir);
      const offending = disabled.filter((s) => PROTECTED.has(s));
      if (offending.length === 0) continue;
      const cleaned = disabled.filter((s) => !PROTECTED.has(s));
      setDisabledSkills(p.hermesDir, cleaned);
      console.log(`[skills-repair] ${p.slug}: re-enabled ${offending.join(", ")}`);
      fixed++;
    } catch (e) {
      console.error(`[skills-repair] ${p.slug}: failed to repair:`, e.message);
    }
  }
  if (fixed === 0) return;
  console.log(`[skills-repair] repaired ${fixed} profile(s)`);
});

const plugins = [
  _fUwBaQoeFfqheMvYbwQe1ClUL8_4QeozRRaRRe4hGk,
_QBjSuN2dl8IkwAvnr5P1X__eBiFktLoMkBOQs0C9V4,
_ICETcJ3NhFoMfJX2x_ZVYFFVgXOtXxjXwRVER9bmT9o,
_7e_IGRuIQhiEbEbg2GWLj9JKsirqPMjKvyoudnXO4HE,
_n6bSztapAOwr6rbziC9Wb86XNjye196eWKaHqA91lr8
];

const assets = {
  "/favicon.ico": {
    "type": "image/vnd.microsoft.icon",
    "etag": "\"10be-n8egyE9tcb7sKGr/pYCaQ4uWqxI\"",
    "mtime": "2026-05-11T19:26:06.235Z",
    "size": 4286,
    "path": "../public/favicon.ico"
  },
  "/_nuxt/B2grN5aH.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1d729-W6VRZnBoVXb62iwR6LedaoDDBGs\"",
    "mtime": "2026-05-11T19:26:06.229Z",
    "size": 120617,
    "path": "../public/_nuxt/B2grN5aH.js"
  },
  "/_nuxt/B4Dbb2J0.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"17039-cUEjrQa+9xsaFBBmjsv5CVJ1k9w\"",
    "mtime": "2026-05-11T19:26:06.229Z",
    "size": 94265,
    "path": "../public/_nuxt/B4Dbb2J0.js"
  },
  "/_nuxt/Bf4_Uh3u.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"5082-m70xuwyzjVwS2rj8lKwIqVxPsl4\"",
    "mtime": "2026-05-11T19:26:06.230Z",
    "size": 20610,
    "path": "../public/_nuxt/Bf4_Uh3u.js"
  },
  "/_nuxt/Ccyu5pnq.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"107d2-wRwzFfb6kNm1UYs9tLWACGkvsU0\"",
    "mtime": "2026-05-11T19:26:06.230Z",
    "size": 67538,
    "path": "../public/_nuxt/Ccyu5pnq.js"
  },
  "/_nuxt/BGEdKKbn.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"2f30-QZHF+hq+/j+UaXEt248+KSwhgEA\"",
    "mtime": "2026-05-11T19:26:06.229Z",
    "size": 12080,
    "path": "../public/_nuxt/BGEdKKbn.js"
  },
  "/_nuxt/D6sCgUBY.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"d96-UUSb/O5GoFGMJLRIpOVX+GaaqfM\"",
    "mtime": "2026-05-11T19:26:06.230Z",
    "size": 3478,
    "path": "../public/_nuxt/D6sCgUBY.js"
  },
  "/_nuxt/DQeyIzwB.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"55e8-d6JCg3V6lBFjKuCe2JHCQIiwnXQ\"",
    "mtime": "2026-05-11T19:26:06.230Z",
    "size": 21992,
    "path": "../public/_nuxt/DQeyIzwB.js"
  },
  "/_nuxt/DZRpN4jW.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"eb9-phtIRHzS5aOsf3YHgrMrnsjdTbE\"",
    "mtime": "2026-05-11T19:26:06.230Z",
    "size": 3769,
    "path": "../public/_nuxt/DZRpN4jW.js"
  },
  "/_nuxt/DelJvkva.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"4e59-igrJqNJM+B2CA2VFwozfP6U4c5s\"",
    "mtime": "2026-05-11T19:26:06.230Z",
    "size": 20057,
    "path": "../public/_nuxt/DelJvkva.js"
  },
  "/_nuxt/DdliQBuQ.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"7e97f-Z/J6+qdfL+Jj3HZm+k+gF1NFs+Y\"",
    "mtime": "2026-05-11T19:26:06.230Z",
    "size": 518527,
    "path": "../public/_nuxt/DdliQBuQ.js"
  },
  "/_nuxt/DlAUqK2U.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"5b-eFCz/UrraTh721pgAl0VxBNR1es\"",
    "mtime": "2026-05-11T19:26:06.230Z",
    "size": 91,
    "path": "../public/_nuxt/DlAUqK2U.js"
  },
  "/_nuxt/entry.CJVAoYsK.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"33c68-4X2dyxu6BzmcsesAFFfHgbxG1yw\"",
    "mtime": "2026-05-11T19:26:06.230Z",
    "size": 212072,
    "path": "../public/_nuxt/entry.CJVAoYsK.css"
  },
  "/_nuxt/error-500.CmJqjJCq.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"773-aJt0cNzz+ruyBbkHLGqfAhDjDDU\"",
    "mtime": "2026-05-11T19:26:06.230Z",
    "size": 1907,
    "path": "../public/_nuxt/error-500.CmJqjJCq.css"
  },
  "/_nuxt/error-404.i5tMg30p.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"97e-ViUWvjtBcU3vbWi7tb2PrqiChKE\"",
    "mtime": "2026-05-11T19:26:06.230Z",
    "size": 2430,
    "path": "../public/_nuxt/error-404.i5tMg30p.css"
  },
  "/_nuxt/index.CPQkpOx2.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"26717-mRWkOVJd0rIU0JdD+KUwMjTdrG0\"",
    "mtime": "2026-05-11T19:26:06.230Z",
    "size": 157463,
    "path": "../public/_nuxt/index.CPQkpOx2.css"
  },
  "/_nuxt/overlay.D_j8P3na.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"53f5-ooytKrTMfMN/vOrne1IV9+GTpJw\"",
    "mtime": "2026-05-11T19:26:06.230Z",
    "size": 21493,
    "path": "../public/_nuxt/overlay.D_j8P3na.css"
  },
  "/_nuxt/team.BknbaknM.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"224ef-nkVqUJ4dnp1HvrB9TkbJlW7s3Oc\"",
    "mtime": "2026-05-11T19:26:06.230Z",
    "size": 140527,
    "path": "../public/_nuxt/team.BknbaknM.css"
  },
  "/_fonts/2vrrJ3MJLeeRdsxoGShjYhieJbC2KYTsL2TxP6pMbHw-M0DkDLNITN2p_m211B__nX1QX-Xza3m69L-nMauwf2g.woff2": {
    "type": "font/woff2",
    "etag": "\"1140-gFescGr8cudMaUhTPQW2ranuzTk\"",
    "mtime": "2026-05-11T19:26:06.213Z",
    "size": 4416,
    "path": "../public/_fonts/2vrrJ3MJLeeRdsxoGShjYhieJbC2KYTsL2TxP6pMbHw-M0DkDLNITN2p_m211B__nX1QX-Xza3m69L-nMauwf2g.woff2"
  },
  "/_nuxt/missions.DStzFQM4.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"752b-DHiZqmVJhvvICESx+vjSYMnPKaA\"",
    "mtime": "2026-05-11T19:26:06.230Z",
    "size": 29995,
    "path": "../public/_nuxt/missions.DStzFQM4.css"
  },
  "/_fonts/3EoiQ3JXV9M854bFdDwbRdGEY3-Du8oUds3aqK5whzM-0k8mcMMDR7LSyG5LPtIn07Rq92oTawhgfoVy5edJiuM.woff2": {
    "type": "font/woff2",
    "etag": "\"2740-BlpGY1CeuDg1hSpFNnhsSRcztKQ\"",
    "mtime": "2026-05-11T19:26:06.214Z",
    "size": 10048,
    "path": "../public/_fonts/3EoiQ3JXV9M854bFdDwbRdGEY3-Du8oUds3aqK5whzM-0k8mcMMDR7LSyG5LPtIn07Rq92oTawhgfoVy5edJiuM.woff2"
  },
  "/_fonts/4QnBRRPRkqsZZsI-BMyAY6O8mcHveU0lVITGztsdgaU-6W9goIX2kkUb_cEk1DVhEit9nFnfoMy0U1qs3xF4uAE.woff2": {
    "type": "font/woff2",
    "etag": "\"2788-wRrckTAkoblSg41oU8DEFPKCXXk\"",
    "mtime": "2026-05-11T19:26:06.214Z",
    "size": 10120,
    "path": "../public/_fonts/4QnBRRPRkqsZZsI-BMyAY6O8mcHveU0lVITGztsdgaU-6W9goIX2kkUb_cEk1DVhEit9nFnfoMy0U1qs3xF4uAE.woff2"
  },
  "/_fonts/4VzVfti7A9XwdTiq16lO4lLfZTtYPcEFGbpaWWH4bDo-xec7qfdrgCQ5lsquFv1xibvLzatcl3q_vTUpC4HNYZA.woff2": {
    "type": "font/woff2",
    "etag": "\"1e94-oMpeSFrJ8+QD6t+NDMZQ7mF2dvE\"",
    "mtime": "2026-05-11T19:26:06.214Z",
    "size": 7828,
    "path": "../public/_fonts/4VzVfti7A9XwdTiq16lO4lLfZTtYPcEFGbpaWWH4bDo-xec7qfdrgCQ5lsquFv1xibvLzatcl3q_vTUpC4HNYZA.woff2"
  },
  "/_fonts/57NSSoFy1VLVs2gqly8Ls9awBnZMFyXGrefpmqvdqmc-zJfbBtpgM4cDmcXBsqZNW79_kFnlpPd62b48glgdydA.woff2": {
    "type": "font/woff2",
    "etag": "\"4b5c-TAo9mx7r3xQs52+HbHcHJ52z8Qo\"",
    "mtime": "2026-05-11T19:26:06.214Z",
    "size": 19292,
    "path": "../public/_fonts/57NSSoFy1VLVs2gqly8Ls9awBnZMFyXGrefpmqvdqmc-zJfbBtpgM4cDmcXBsqZNW79_kFnlpPd62b48glgdydA.woff2"
  },
  "/_fonts/7HAR14LKTzhJQKjIswIdjqbb_ir_9ierJYPiQk1I0T4-CAhl9c6lKjXQV_OAVGFlQ8ZIg0kI00oZ4sqnwBOU2vo.woff2": {
    "type": "font/woff2",
    "etag": "\"2d58-stNEcBioFKpvjyNTxTRJLMDNTAc\"",
    "mtime": "2026-05-11T19:26:06.214Z",
    "size": 11608,
    "path": "../public/_fonts/7HAR14LKTzhJQKjIswIdjqbb_ir_9ierJYPiQk1I0T4-CAhl9c6lKjXQV_OAVGFlQ8ZIg0kI00oZ4sqnwBOU2vo.woff2"
  },
  "/_fonts/7WxvCoQoBAH14zHMIzud8LZLGLbCxdZ5rYFBwWDUCA0-7rZmBN39Ay7RD0aDGNP_t34hul4ct2_i1NrHyzMUL9Q.woff2": {
    "type": "font/woff2",
    "etag": "\"67b4-DChIsY9TTx6LwrqU2FM7I8p6IqM\"",
    "mtime": "2026-05-11T19:26:06.214Z",
    "size": 26548,
    "path": "../public/_fonts/7WxvCoQoBAH14zHMIzud8LZLGLbCxdZ5rYFBwWDUCA0-7rZmBN39Ay7RD0aDGNP_t34hul4ct2_i1NrHyzMUL9Q.woff2"
  },
  "/_fonts/7qYB9pTPpQMGJcc1oBw4aJs8qrR5AEqnE_aISylzMZk-bEs5OXN1qanFoMWgw9Rbj_qKdScgEiDVW5fwM_e-DbY.woff2": {
    "type": "font/woff2",
    "etag": "\"11b0-nbOgpAuCShpLPBAUi1gN5MNBh40\"",
    "mtime": "2026-05-11T19:26:06.215Z",
    "size": 4528,
    "path": "../public/_fonts/7qYB9pTPpQMGJcc1oBw4aJs8qrR5AEqnE_aISylzMZk-bEs5OXN1qanFoMWgw9Rbj_qKdScgEiDVW5fwM_e-DbY.woff2"
  },
  "/_fonts/7u0-77UfQZ7R5xCkHtH-6FcLzzYcD0xArs2lWsaXoxo-nx_kVkjHkrHGl_yt9uLKYpDnl16LRpt038O6up8FgXw.woff2": {
    "type": "font/woff2",
    "etag": "\"15ac-G2h5Lo3s6Xp9HqWpKL2NJ36tV74\"",
    "mtime": "2026-05-11T19:26:06.214Z",
    "size": 5548,
    "path": "../public/_fonts/7u0-77UfQZ7R5xCkHtH-6FcLzzYcD0xArs2lWsaXoxo-nx_kVkjHkrHGl_yt9uLKYpDnl16LRpt038O6up8FgXw.woff2"
  },
  "/_fonts/8VR2wSMN-3U4NbWAVYXlkRV6hA0jFBXP-0RtL3X7fko-x2gYI4qfmkRdxyQQUPaBZdZdgl1TeVrquF_TxHeM4lM.woff2": {
    "type": "font/woff2",
    "etag": "\"212c-FshXJibFzNhd2HEIMP8C3JR5PYg\"",
    "mtime": "2026-05-11T19:26:06.214Z",
    "size": 8492,
    "path": "../public/_fonts/8VR2wSMN-3U4NbWAVYXlkRV6hA0jFBXP-0RtL3X7fko-x2gYI4qfmkRdxyQQUPaBZdZdgl1TeVrquF_TxHeM4lM.woff2"
  },
  "/_fonts/8s05g7h1BsO8lFAzNqHs5fJZFxS-xwv8O45ZLDdw4Xc-0o1JXtxv_7kmP3VcvEp-9kAlLtZv249JWMmVsfIzhxw.woff2": {
    "type": "font/woff2",
    "etag": "\"2d2c-HieuXDm0V6OzJmt/m2Z/z/ulw1Y\"",
    "mtime": "2026-05-11T19:26:06.214Z",
    "size": 11564,
    "path": "../public/_fonts/8s05g7h1BsO8lFAzNqHs5fJZFxS-xwv8O45ZLDdw4Xc-0o1JXtxv_7kmP3VcvEp-9kAlLtZv249JWMmVsfIzhxw.woff2"
  },
  "/_fonts/9IYWZwGkalWblbQ0qUB1NVEWKltx8MGbUCCI8A-nXvc-A42XFuaMkcGV8IU4tyjaz8jlX4w7e0oOK9ZL1W1A_tg.woff2": {
    "type": "font/woff2",
    "etag": "\"15a4-dpZ/UKTavoCAhxN2KhucYEfQDdo\"",
    "mtime": "2026-05-11T19:26:06.214Z",
    "size": 5540,
    "path": "../public/_fonts/9IYWZwGkalWblbQ0qUB1NVEWKltx8MGbUCCI8A-nXvc-A42XFuaMkcGV8IU4tyjaz8jlX4w7e0oOK9ZL1W1A_tg.woff2"
  },
  "/_fonts/ATc0VqIXMNIEgWU4XzMMCAWoJJ4G11FKjX38DInsfx0-bGhSBtjl_XEffZBInMi-gJZBMjmF_0UQsncnDV02cEc.woff2": {
    "type": "font/woff2",
    "etag": "\"3d44-vVHWOdnyEL7Y2j/cUTbD6+Uxsi0\"",
    "mtime": "2026-05-11T19:26:06.214Z",
    "size": 15684,
    "path": "../public/_fonts/ATc0VqIXMNIEgWU4XzMMCAWoJJ4G11FKjX38DInsfx0-bGhSBtjl_XEffZBInMi-gJZBMjmF_0UQsncnDV02cEc.woff2"
  },
  "/_fonts/Be-n02WlyGlCYr6AKZTu1ZLO7yH-M5nlZkD_wXnLEHI-dzPF0VM_shn45xQxjIQGDrk8A3rEcAn5G6IvnYsvdnc.woff2": {
    "type": "font/woff2",
    "etag": "\"11e8-nQCdonyq4Ycdo9WwRtHpj3HP7mA\"",
    "mtime": "2026-05-11T19:26:06.214Z",
    "size": 4584,
    "path": "../public/_fonts/Be-n02WlyGlCYr6AKZTu1ZLO7yH-M5nlZkD_wXnLEHI-dzPF0VM_shn45xQxjIQGDrk8A3rEcAn5G6IvnYsvdnc.woff2"
  },
  "/_fonts/G1z3mcby8z4pfQp_shaJSYZuXyNpaES81jf-Uy3wFLc-QdRJEr2TP9Yyj3gppGIo3wyzXYHET_I1oHxOKv4_UBc.woff2": {
    "type": "font/woff2",
    "etag": "\"2794-oRmewbb0k+vye1IGjsbmb3Jq1mI\"",
    "mtime": "2026-05-11T19:26:06.214Z",
    "size": 10132,
    "path": "../public/_fonts/G1z3mcby8z4pfQp_shaJSYZuXyNpaES81jf-Uy3wFLc-QdRJEr2TP9Yyj3gppGIo3wyzXYHET_I1oHxOKv4_UBc.woff2"
  },
  "/_fonts/GsKUclqeNLJ96g5AU593ug6yanivOiwjW_7zESNPChw-jHA4tBeM1bjF7LATGUpfBuSTyomIFrWBTzjF7txVYfg.woff2": {
    "type": "font/woff2",
    "etag": "\"680c-mJtsV33lkTAKSmfq5k3lKHSllcU\"",
    "mtime": "2026-05-11T19:26:06.214Z",
    "size": 26636,
    "path": "../public/_fonts/GsKUclqeNLJ96g5AU593ug6yanivOiwjW_7zESNPChw-jHA4tBeM1bjF7LATGUpfBuSTyomIFrWBTzjF7txVYfg.woff2"
  },
  "/_fonts/IOQmCJk1c1X8tTiR2_xRphUddTG90WpG00y3mrL7asc-fI5Z9vM1TPimFu47KjlvcLJubuCXAUmRe99EOBGK4Jg.woff2": {
    "type": "font/woff2",
    "etag": "\"1408-Lkovyg4WNz4KOqYUDqy745g9k7k\"",
    "mtime": "2026-05-11T19:26:06.214Z",
    "size": 5128,
    "path": "../public/_fonts/IOQmCJk1c1X8tTiR2_xRphUddTG90WpG00y3mrL7asc-fI5Z9vM1TPimFu47KjlvcLJubuCXAUmRe99EOBGK4Jg.woff2"
  },
  "/_fonts/Ld1FnTo3yTIwDyGfTQ5-Fws9AWsCbKfMvgxduXr7JcY-W25bL8NF1fjpLRSOgJb7RoZPHqGQNwMTM7S9tHVoxx8.woff2": {
    "type": "font/woff2",
    "etag": "\"6ec4-8OoFFPZKF1grqmfGVjh5JDE6DOU\"",
    "mtime": "2026-05-11T19:26:06.214Z",
    "size": 28356,
    "path": "../public/_fonts/Ld1FnTo3yTIwDyGfTQ5-Fws9AWsCbKfMvgxduXr7JcY-W25bL8NF1fjpLRSOgJb7RoZPHqGQNwMTM7S9tHVoxx8.woff2"
  },
  "/_fonts/MkzsVVsVa19hNhuifJxuUyjYXA8QsnSlohE8Xis64wI-b_OhvLchONOxbaZEOWy7B_wZN5OrU3apyvlSa5_nXOQ.woff2": {
    "type": "font/woff2",
    "etag": "\"3ac0-bI6KKRvdRmeMPcl+y0GuPiF3IVo\"",
    "mtime": "2026-05-11T19:26:06.214Z",
    "size": 15040,
    "path": "../public/_fonts/MkzsVVsVa19hNhuifJxuUyjYXA8QsnSlohE8Xis64wI-b_OhvLchONOxbaZEOWy7B_wZN5OrU3apyvlSa5_nXOQ.woff2"
  },
  "/_fonts/MlNgkMyhKIDysanNTo08JXs1NKT7N3PAiE-rd67y0tk-4_8EiC-OPpJkFXcZG4fmdwz7sj_gpRAqn-822cldaKI.woff2": {
    "type": "font/woff2",
    "etag": "\"2d44-cx4JptvYNAd9P/crVpSBDRsh/kg\"",
    "mtime": "2026-05-11T19:26:06.214Z",
    "size": 11588,
    "path": "../public/_fonts/MlNgkMyhKIDysanNTo08JXs1NKT7N3PAiE-rd67y0tk-4_8EiC-OPpJkFXcZG4fmdwz7sj_gpRAqn-822cldaKI.woff2"
  },
  "/_fonts/NaeHrWP1-iMKUUbIzW8qCa662095DhNYoHJXtkNCjkM-1gqKNyA5_uizWtQDHl7DvGwhfCQZkjE87-e8v9ZSzew.woff2": {
    "type": "font/woff2",
    "etag": "\"2790-lElgtykWMolMVVgPLI51B03w+w4\"",
    "mtime": "2026-05-11T19:26:06.214Z",
    "size": 10128,
    "path": "../public/_fonts/NaeHrWP1-iMKUUbIzW8qCa662095DhNYoHJXtkNCjkM-1gqKNyA5_uizWtQDHl7DvGwhfCQZkjE87-e8v9ZSzew.woff2"
  },
  "/_fonts/NdzqRASp2bovDUhQT1IRE_EMqKJ2KYQdTCfFcBvL8yw-KhwZiS86o3fErOe5GGMExHUemmI_dBfaEFxjISZrBd0.woff2": {
    "type": "font/woff2",
    "etag": "\"1d98-cDZfMibtk4T04FTTAmlfhWDpkN0\"",
    "mtime": "2026-05-11T19:26:06.214Z",
    "size": 7576,
    "path": "../public/_fonts/NdzqRASp2bovDUhQT1IRE_EMqKJ2KYQdTCfFcBvL8yw-KhwZiS86o3fErOe5GGMExHUemmI_dBfaEFxjISZrBd0.woff2"
  },
  "/_fonts/P20rFYUuJYBG6P413-kmy1MH2c5-AHidHeOkhurVW9E-s9pky6iiS9O9L4P9FGQnIeXl7IrK7HsqmKdubOA2j4w.woff2": {
    "type": "font/woff2",
    "etag": "\"fa0-8pnZFroGRdDc8+ahGidL979/ihs\"",
    "mtime": "2026-05-11T19:26:06.214Z",
    "size": 4000,
    "path": "../public/_fonts/P20rFYUuJYBG6P413-kmy1MH2c5-AHidHeOkhurVW9E-s9pky6iiS9O9L4P9FGQnIeXl7IrK7HsqmKdubOA2j4w.woff2"
  },
  "/_fonts/P-opX31986DaGyCeEVxGapeAZVhWZEmsnHrtz-8uNjk-Qdxvbv5v3sdw4jMVvggdQIwnhFnU5CSX7ZkcKlqcM5E.woff2": {
    "type": "font/woff2",
    "etag": "\"1c54-OG2if67VU/nhDKeYVki97VlQYh8\"",
    "mtime": "2026-05-11T19:26:06.214Z",
    "size": 7252,
    "path": "../public/_fonts/P-opX31986DaGyCeEVxGapeAZVhWZEmsnHrtz-8uNjk-Qdxvbv5v3sdw4jMVvggdQIwnhFnU5CSX7ZkcKlqcM5E.woff2"
  },
  "/_fonts/TFWlwoCp6ug4N2WAg-6QAZ14xTmMw01biXyVG4455dI-q3iMkKdBtHvY5CwbWL9amwnIlWjCh_MBY6rJ1ZpktWQ.woff2": {
    "type": "font/woff2",
    "etag": "\"1c64-omp4MH365EzIVFTAu1+q7R5SXKU\"",
    "mtime": "2026-05-11T19:26:06.214Z",
    "size": 7268,
    "path": "../public/_fonts/TFWlwoCp6ug4N2WAg-6QAZ14xTmMw01biXyVG4455dI-q3iMkKdBtHvY5CwbWL9amwnIlWjCh_MBY6rJ1ZpktWQ.woff2"
  },
  "/_fonts/Y7f-8GVyzqqVUZE9RGKSEwHKp-J5xG9W9JvAuAXnukE-a6vWQ8lr44WUpidIwQELsd_UxxoksjFr_7OFl0B1cj4.woff2": {
    "type": "font/woff2",
    "etag": "\"274c-OiZouUtcE4jv0YOEZwuC6xkeUG0\"",
    "mtime": "2026-05-11T19:26:06.214Z",
    "size": 10060,
    "path": "../public/_fonts/Y7f-8GVyzqqVUZE9RGKSEwHKp-J5xG9W9JvAuAXnukE-a6vWQ8lr44WUpidIwQELsd_UxxoksjFr_7OFl0B1cj4.woff2"
  },
  "/_fonts/YFhrCfizGmZCCsX1GkJqSsa1Ln3ZkYEBQx1kS5GBSNM-lnlTSm_m0Am_5BfksHFyxTS8HwzeRUIimtrJh-2-hQk.woff2": {
    "type": "font/woff2",
    "etag": "\"157c-aVomdjcSXW3z8Bc2vJxBkeUpd9E\"",
    "mtime": "2026-05-11T19:26:06.214Z",
    "size": 5500,
    "path": "../public/_fonts/YFhrCfizGmZCCsX1GkJqSsa1Ln3ZkYEBQx1kS5GBSNM-lnlTSm_m0Am_5BfksHFyxTS8HwzeRUIimtrJh-2-hQk.woff2"
  },
  "/_fonts/abc3urfYpum3NohTJJ82tZYrJ0Qq6V1DDuV4nEN3-K8-2_2ztTmYY0L6UFJjC5ut8vWYRD-RsvXGTIbWQjKw8ig.woff2": {
    "type": "font/woff2",
    "etag": "\"146c-znyFmBgCNV9ukMaGPyw6ZWHt0+U\"",
    "mtime": "2026-05-11T19:26:06.214Z",
    "size": 5228,
    "path": "../public/_fonts/abc3urfYpum3NohTJJ82tZYrJ0Qq6V1DDuV4nEN3-K8-2_2ztTmYY0L6UFJjC5ut8vWYRD-RsvXGTIbWQjKw8ig.woff2"
  },
  "/_fonts/c9UOtWdvEkMdkWxin3fO_nOvZfFevXVtanKkemdlzVs-NZc_1h0ba5jh8strJX03YaVqHCE1TFVMTjG6rHlowdk.woff2": {
    "type": "font/woff2",
    "etag": "\"1208-oKoJ8To63UzDBFzYobOXCymeMps\"",
    "mtime": "2026-05-11T19:26:06.215Z",
    "size": 4616,
    "path": "../public/_fonts/c9UOtWdvEkMdkWxin3fO_nOvZfFevXVtanKkemdlzVs-NZc_1h0ba5jh8strJX03YaVqHCE1TFVMTjG6rHlowdk.woff2"
  },
  "/_fonts/csHsi_ayDY-1Bb0elJrgXc5EYv_3ZUHTjyt6t6R_hvI-2j_LO_XEAFCarGnUMAZp9mH1XcHyWmBOSOM3UU8Yh80.woff2": {
    "type": "font/woff2",
    "etag": "\"1424-nherMEGoSS290Xp+3Zf2G+9bBv8\"",
    "mtime": "2026-05-11T19:26:06.215Z",
    "size": 5156,
    "path": "../public/_fonts/csHsi_ayDY-1Bb0elJrgXc5EYv_3ZUHTjyt6t6R_hvI-2j_LO_XEAFCarGnUMAZp9mH1XcHyWmBOSOM3UU8Yh80.woff2"
  },
  "/_fonts/de9Hn98X7qjvQryMTK_S5_8pcE2ixEzuPClwbeHVxAI-2R9bduNO98qcxzo2cGRCSP20RqlwtuSKwb6RYUOUHtQ.woff2": {
    "type": "font/woff2",
    "etag": "\"fc4-BieU4aPtWkSYTMxXRbxbx5+wMT8\"",
    "mtime": "2026-05-11T19:26:06.215Z",
    "size": 4036,
    "path": "../public/_fonts/de9Hn98X7qjvQryMTK_S5_8pcE2ixEzuPClwbeHVxAI-2R9bduNO98qcxzo2cGRCSP20RqlwtuSKwb6RYUOUHtQ.woff2"
  },
  "/_fonts/fxn6Ta_PXKaftNQ6o3GFS9b6XU2VmWsDHvzQlBYv26k-RCwtZl_Z0-eqoKkgjV2Lvu8bNskZv3RiHclp-qdyFbE.woff2": {
    "type": "font/woff2",
    "etag": "\"2290-JDl6PoNbZMzCJDyDwXYqGbKTBtM\"",
    "mtime": "2026-05-11T19:26:06.215Z",
    "size": 8848,
    "path": "../public/_fonts/fxn6Ta_PXKaftNQ6o3GFS9b6XU2VmWsDHvzQlBYv26k-RCwtZl_Z0-eqoKkgjV2Lvu8bNskZv3RiHclp-qdyFbE.woff2"
  },
  "/_fonts/iTkrULNFJJkTvihIg1Vqi5IODRH_9btXCioVF5l98I8-AndUyau2HR2felA_ra8V2mutQgschhasE5FD1dXGJX8.woff2": {
    "type": "font/woff2",
    "etag": "\"47c4-5xyngHnzzhetUee74tMx9OTgqNQ\"",
    "mtime": "2026-05-11T19:26:06.215Z",
    "size": 18372,
    "path": "../public/_fonts/iTkrULNFJJkTvihIg1Vqi5IODRH_9btXCioVF5l98I8-AndUyau2HR2felA_ra8V2mutQgschhasE5FD1dXGJX8.woff2"
  },
  "/_fonts/ib-aovnRDsdvSBzUC6Ll2tdWY2U3C9FsxsqLnPpAg18-c_nItv4f1UIuWsSuQgkfygxojtODoHxU-eKvW69FGyI.woff2": {
    "type": "font/woff2",
    "etag": "\"263c-uO9xx9og1UxHdWxGEMAbG87IPU8\"",
    "mtime": "2026-05-11T19:26:06.215Z",
    "size": 9788,
    "path": "../public/_fonts/ib-aovnRDsdvSBzUC6Ll2tdWY2U3C9FsxsqLnPpAg18-c_nItv4f1UIuWsSuQgkfygxojtODoHxU-eKvW69FGyI.woff2"
  },
  "/_fonts/iwtMiRQr9MVxkS-mqNWNDfuQrs4GB3dvByMM9ojyFHw-ExrDYapJHBuMovYABEGrabFChkrO9vAYi7UAvRk2fC8.woff2": {
    "type": "font/woff2",
    "etag": "\"1bb8-LaXJJ6fcnGRK1T9v8sydkRAWjBA\"",
    "mtime": "2026-05-11T19:26:06.215Z",
    "size": 7096,
    "path": "../public/_fonts/iwtMiRQr9MVxkS-mqNWNDfuQrs4GB3dvByMM9ojyFHw-ExrDYapJHBuMovYABEGrabFChkrO9vAYi7UAvRk2fC8.woff2"
  },
  "/_fonts/k9VNYFZ3lbLjdFOvyoe_t6P1Z4y9X5RYYVuXmoEo_ig-nTKWoqtzyKxAIKIx8JNNQ2Q8SwgTTBWZ4p5o2jmFO3k.woff2": {
    "type": "font/woff2",
    "etag": "\"2300-U1oxFKckByacAdyq/sRbwi1P30g\"",
    "mtime": "2026-05-11T19:26:06.215Z",
    "size": 8960,
    "path": "../public/_fonts/k9VNYFZ3lbLjdFOvyoe_t6P1Z4y9X5RYYVuXmoEo_ig-nTKWoqtzyKxAIKIx8JNNQ2Q8SwgTTBWZ4p5o2jmFO3k.woff2"
  },
  "/_fonts/ljD0O_drjiflVTw1FPwOjK1CL1HwVPYB7us-BfZqHuQ-ZjVgBNdLadH_Dw6T1hPTCJa6wTlqofsHYwtGtzawATs.woff2": {
    "type": "font/woff2",
    "etag": "\"138c-nsTL8P8x/ruW5Hmn/VHn39+87Q8\"",
    "mtime": "2026-05-11T19:26:06.215Z",
    "size": 5004,
    "path": "../public/_fonts/ljD0O_drjiflVTw1FPwOjK1CL1HwVPYB7us-BfZqHuQ-ZjVgBNdLadH_Dw6T1hPTCJa6wTlqofsHYwtGtzawATs.woff2"
  },
  "/_fonts/oA7rp6XLB_UIP_utZxXIDlSPcMeVLGKMaeey_kAD0fo-98JsXCHs_mcC6olFARmc-2GM9H4YyxJhTUClXLaqEOU.woff2": {
    "type": "font/woff2",
    "etag": "\"2744-LJus8CQbFCvY6PHfqFW7KTpJCuE\"",
    "mtime": "2026-05-11T19:26:06.215Z",
    "size": 10052,
    "path": "../public/_fonts/oA7rp6XLB_UIP_utZxXIDlSPcMeVLGKMaeey_kAD0fo-98JsXCHs_mcC6olFARmc-2GM9H4YyxJhTUClXLaqEOU.woff2"
  },
  "/_fonts/r2KASPa1NYEuoln4lN0W3EcSZ4QcjSeSmKvuJKUW_e0-EBXL59uF8lOU0BbZ0Qd0HKaqxnk9ahNM_OUahEvA2bA.woff2": {
    "type": "font/woff2",
    "etag": "\"229c-EI1QkISaIxaKB4L03XMpcfDrSdE\"",
    "mtime": "2026-05-11T19:26:06.215Z",
    "size": 8860,
    "path": "../public/_fonts/r2KASPa1NYEuoln4lN0W3EcSZ4QcjSeSmKvuJKUW_e0-EBXL59uF8lOU0BbZ0Qd0HKaqxnk9ahNM_OUahEvA2bA.woff2"
  },
  "/_fonts/rEVNcLQEmJVubb0q0kMM6MajWqyJYTV-UP_44aUFvUo-_H56nSwPr9uNlDdYXIr3uqY0nhgxA9cuDS1xHZ8_NlQ.woff2": {
    "type": "font/woff2",
    "etag": "\"3f98-88i6SqqtBw4wBBi/drOL9wM7z1k\"",
    "mtime": "2026-05-11T19:26:06.215Z",
    "size": 16280,
    "path": "../public/_fonts/rEVNcLQEmJVubb0q0kMM6MajWqyJYTV-UP_44aUFvUo-_H56nSwPr9uNlDdYXIr3uqY0nhgxA9cuDS1xHZ8_NlQ.woff2"
  },
  "/_fonts/sZOWZh4Lseqiy1g9lJ-6sp_l7Tnfae4gGZYr6PHqLgc-NVanILUbCWR2T4cC6yna0eytAT4QEmYcMi_qN_YFwrA.woff2": {
    "type": "font/woff2",
    "etag": "\"10f8-GLJ2i7uQ99WJlVFKckqW880M7es\"",
    "mtime": "2026-05-11T19:26:06.215Z",
    "size": 4344,
    "path": "../public/_fonts/sZOWZh4Lseqiy1g9lJ-6sp_l7Tnfae4gGZYr6PHqLgc-NVanILUbCWR2T4cC6yna0eytAT4QEmYcMi_qN_YFwrA.woff2"
  },
  "/_fonts/svLEQR1NhVsKV3td5-qEdR3OcCyUB1uXwND4pueM24E-_ai0lJkLAXfhhHb6ZYIId61FSPBqXyGFmF0ftxqBrQ0.woff2": {
    "type": "font/woff2",
    "etag": "\"20fc-0w0yJD5vH339O5nppqu5lxikx0o\"",
    "mtime": "2026-05-11T19:26:06.215Z",
    "size": 8444,
    "path": "../public/_fonts/svLEQR1NhVsKV3td5-qEdR3OcCyUB1uXwND4pueM24E-_ai0lJkLAXfhhHb6ZYIId61FSPBqXyGFmF0ftxqBrQ0.woff2"
  },
  "/_fonts/uqOUEfp6GyasEjSs6mPL4xH4Ogfg9dejwyGqFvieEhQ-1DC4lhOKAtHn_hSVO1eAmsDfxgXpJii8eq16JZynm5s.woff2": {
    "type": "font/woff2",
    "etag": "\"10fc-RCs+yYfoyLwcYPlcoSJyZzsRQZg\"",
    "mtime": "2026-05-11T19:26:06.215Z",
    "size": 4348,
    "path": "../public/_fonts/uqOUEfp6GyasEjSs6mPL4xH4Ogfg9dejwyGqFvieEhQ-1DC4lhOKAtHn_hSVO1eAmsDfxgXpJii8eq16JZynm5s.woff2"
  },
  "/_fonts/tHIC4jbWRecrkBLYzXeJ-l-FMVE3IC-WCOr8aeczZzk-HpEbV83Au1R7ttgKEHICBgfH9eJ1oI4aqhcwYRiyk_E.woff2": {
    "type": "font/woff2",
    "etag": "\"1014-eSWi3WwMGnxP7XNiwKOIYl18D+8\"",
    "mtime": "2026-05-11T19:26:06.215Z",
    "size": 4116,
    "path": "../public/_fonts/tHIC4jbWRecrkBLYzXeJ-l-FMVE3IC-WCOr8aeczZzk-HpEbV83Au1R7ttgKEHICBgfH9eJ1oI4aqhcwYRiyk_E.woff2"
  },
  "/_fonts/vSGurvFi7J9DFpc3gRh0zb7zfLGEZfPgQADV5W675RU-SOsE32TvAEDx4Ogk8IUoJ8eiJFzZUTZWzAjnjTzmlhU.woff2": {
    "type": "font/woff2",
    "etag": "\"2d30-AvyaVQm1mcR1p7YEJ7HKZU39erI\"",
    "mtime": "2026-05-11T19:26:06.215Z",
    "size": 11568,
    "path": "../public/_fonts/vSGurvFi7J9DFpc3gRh0zb7zfLGEZfPgQADV5W675RU-SOsE32TvAEDx4Ogk8IUoJ8eiJFzZUTZWzAjnjTzmlhU.woff2"
  },
  "/_fonts/vijLFK-KHAfLMAJw3I00MGO7TegKZixeBpXB8P8ZNSw-CWJay_vzLuCpDiGXYEvr4DhzjKgzr8DcTgueGgkphlw.woff2": {
    "type": "font/woff2",
    "etag": "\"fe0-ei7Wh0jD2b723I3q8D6SY+Ov9ao\"",
    "mtime": "2026-05-11T19:26:06.215Z",
    "size": 4064,
    "path": "../public/_fonts/vijLFK-KHAfLMAJw3I00MGO7TegKZixeBpXB8P8ZNSw-CWJay_vzLuCpDiGXYEvr4DhzjKgzr8DcTgueGgkphlw.woff2"
  },
  "/_fonts/vkmZkh-CHOvBXhWqyxI7y7yhtJnjEZhooZMtIOrKbdc-2IAHU0readmKJy05HSHAUr9ZfblPKy1cYnIzD6FaafQ.woff2": {
    "type": "font/woff2",
    "etag": "\"1564-8+PvX0p8QVrbuzvTJ7m8mSqTU30\"",
    "mtime": "2026-05-11T19:26:06.215Z",
    "size": 5476,
    "path": "../public/_fonts/vkmZkh-CHOvBXhWqyxI7y7yhtJnjEZhooZMtIOrKbdc-2IAHU0readmKJy05HSHAUr9ZfblPKy1cYnIzD6FaafQ.woff2"
  },
  "/_fonts/wXrnAZG6imawmnLMrmEGDaw8OERkBjrhxtvCpdAoFtU-THRRjDiTK2YhlZWGZ4KWGQimEEJ4q90NggcMPrCWifk.woff2": {
    "type": "font/woff2",
    "etag": "\"10f0-9JKRt5EU0TBf17ofgpEWU93L3vI\"",
    "mtime": "2026-05-11T19:26:06.215Z",
    "size": 4336,
    "path": "../public/_fonts/wXrnAZG6imawmnLMrmEGDaw8OERkBjrhxtvCpdAoFtU-THRRjDiTK2YhlZWGZ4KWGQimEEJ4q90NggcMPrCWifk.woff2"
  },
  "/_fonts/xJPBIvvk_Sw4KqpH43KzxcdvgIqPAswKL2-SL5mMfgk-P0mrlLOS5DRt4uVQ_yTmC-xlOBH5DV5VtMOSziFrN8U.woff2": {
    "type": "font/woff2",
    "etag": "\"10e0-wxSiXDoqEt19B8iXROBQ4MTcoMA\"",
    "mtime": "2026-05-11T19:26:06.215Z",
    "size": 4320,
    "path": "../public/_fonts/xJPBIvvk_Sw4KqpH43KzxcdvgIqPAswKL2-SL5mMfgk-P0mrlLOS5DRt4uVQ_yTmC-xlOBH5DV5VtMOSziFrN8U.woff2"
  },
  "/_fonts/xfTORM6zMaCBLN8KEmrdAwkoRlhpJreq9od0IdnzZ0g-_9Qp95jKFav7hdhcdpsrtGsvVOKgw5NpeBgIuaa3qLg.woff2": {
    "type": "font/woff2",
    "etag": "\"222c-pC24jdTU4TUCDC80OBc5NrqaSr0\"",
    "mtime": "2026-05-11T19:26:06.215Z",
    "size": 8748,
    "path": "../public/_fonts/xfTORM6zMaCBLN8KEmrdAwkoRlhpJreq9od0IdnzZ0g-_9Qp95jKFav7hdhcdpsrtGsvVOKgw5NpeBgIuaa3qLg.woff2"
  },
  "/_fonts/zhpX147TwsvlSAL8_vtsG77wE2r4o_uOAuyxH7pu_ro-9hIvJr5HdnrHw0ka90s0eA135TAMwiiABrhsW5rDElc.woff2": {
    "type": "font/woff2",
    "etag": "\"26f4-UnYcudN+21/VvKZdmLQWGsRt1Fw\"",
    "mtime": "2026-05-11T19:26:06.215Z",
    "size": 9972,
    "path": "../public/_fonts/zhpX147TwsvlSAL8_vtsG77wE2r4o_uOAuyxH7pu_ro-9hIvJr5HdnrHw0ka90s0eA135TAMwiiABrhsW5rDElc.woff2"
  },
  "/_fonts/zxddnekyjgM8Leg15hUgrEIp2Ny0tH_b-TRYGPmkH1o-3ppcoPOnLuSdSUDCyG_oPN72xWzFr2Pe0QIytgvDeZs.woff2": {
    "type": "font/woff2",
    "etag": "\"1bd8-hAlxTiOEZrzWiMiA0DRmOzQlNaA\"",
    "mtime": "2026-05-11T19:26:06.215Z",
    "size": 7128,
    "path": "../public/_fonts/zxddnekyjgM8Leg15hUgrEIp2Ny0tH_b-TRYGPmkH1o-3ppcoPOnLuSdSUDCyG_oPN72xWzFr2Pe0QIytgvDeZs.woff2"
  },
  "/_nuxt/builds/latest.json": {
    "type": "application/json",
    "etag": "\"47-Runo9ZNHgrQGk1BVNhez829DKF0\"",
    "mtime": "2026-05-11T19:26:06.200Z",
    "size": 71,
    "path": "../public/_nuxt/builds/latest.json"
  },
  "/_nuxt/builds/meta/651d4888-c173-4ede-a015-b513cf77dea6.json": {
    "type": "application/json",
    "etag": "\"58-EKlXO2OgtfDUS4ChYYkpeS5lyRk\"",
    "mtime": "2026-05-11T19:26:06.196Z",
    "size": 88,
    "path": "../public/_nuxt/builds/meta/651d4888-c173-4ede-a015-b513cf77dea6.json"
  }
};

const _DRIVE_LETTER_START_RE = /^[A-Za-z]:\//;
function normalizeWindowsPath(input = "") {
  if (!input) {
    return input;
  }
  return input.replace(/\\/g, "/").replace(_DRIVE_LETTER_START_RE, (r) => r.toUpperCase());
}
const _IS_ABSOLUTE_RE = /^[/\\](?![/\\])|^[/\\]{2}(?!\.)|^[A-Za-z]:[/\\]/;
const _DRIVE_LETTER_RE = /^[A-Za-z]:$/;
function cwd() {
  if (typeof process !== "undefined" && typeof process.cwd === "function") {
    return process.cwd().replace(/\\/g, "/");
  }
  return "/";
}
const resolve = function(...arguments_) {
  arguments_ = arguments_.map((argument) => normalizeWindowsPath(argument));
  let resolvedPath = "";
  let resolvedAbsolute = false;
  for (let index = arguments_.length - 1; index >= -1 && !resolvedAbsolute; index--) {
    const path = index >= 0 ? arguments_[index] : cwd();
    if (!path || path.length === 0) {
      continue;
    }
    resolvedPath = `${path}/${resolvedPath}`;
    resolvedAbsolute = isAbsolute(path);
  }
  resolvedPath = normalizeString(resolvedPath, !resolvedAbsolute);
  if (resolvedAbsolute && !isAbsolute(resolvedPath)) {
    return `/${resolvedPath}`;
  }
  return resolvedPath.length > 0 ? resolvedPath : ".";
};
function normalizeString(path, allowAboveRoot) {
  let res = "";
  let lastSegmentLength = 0;
  let lastSlash = -1;
  let dots = 0;
  let char = null;
  for (let index = 0; index <= path.length; ++index) {
    if (index < path.length) {
      char = path[index];
    } else if (char === "/") {
      break;
    } else {
      char = "/";
    }
    if (char === "/") {
      if (lastSlash === index - 1 || dots === 1) ; else if (dots === 2) {
        if (res.length < 2 || lastSegmentLength !== 2 || res[res.length - 1] !== "." || res[res.length - 2] !== ".") {
          if (res.length > 2) {
            const lastSlashIndex = res.lastIndexOf("/");
            if (lastSlashIndex === -1) {
              res = "";
              lastSegmentLength = 0;
            } else {
              res = res.slice(0, lastSlashIndex);
              lastSegmentLength = res.length - 1 - res.lastIndexOf("/");
            }
            lastSlash = index;
            dots = 0;
            continue;
          } else if (res.length > 0) {
            res = "";
            lastSegmentLength = 0;
            lastSlash = index;
            dots = 0;
            continue;
          }
        }
        if (allowAboveRoot) {
          res += res.length > 0 ? "/.." : "..";
          lastSegmentLength = 2;
        }
      } else {
        if (res.length > 0) {
          res += `/${path.slice(lastSlash + 1, index)}`;
        } else {
          res = path.slice(lastSlash + 1, index);
        }
        lastSegmentLength = index - lastSlash - 1;
      }
      lastSlash = index;
      dots = 0;
    } else if (char === "." && dots !== -1) {
      ++dots;
    } else {
      dots = -1;
    }
  }
  return res;
}
const isAbsolute = function(p) {
  return _IS_ABSOLUTE_RE.test(p);
};
const dirname = function(p) {
  const segments = normalizeWindowsPath(p).replace(/\/$/, "").split("/").slice(0, -1);
  if (segments.length === 1 && _DRIVE_LETTER_RE.test(segments[0])) {
    segments[0] += "/";
  }
  return segments.join("/") || (isAbsolute(p) ? "/" : ".");
};
const basename = function(p, extension) {
  const segments = normalizeWindowsPath(p).split("/");
  let lastSegment = "";
  for (let i = segments.length - 1; i >= 0; i--) {
    const val = segments[i];
    if (val) {
      lastSegment = val;
      break;
    }
  }
  return extension && lastSegment.endsWith(extension) ? lastSegment.slice(0, -extension.length) : lastSegment;
};

function readAsset (id) {
  const serverDir = dirname(fileURLToPath(globalThis._importMeta_.url));
  return promises.readFile(resolve(serverDir, assets[id].path))
}

const publicAssetBases = {"/_nuxt/builds/meta/":{"maxAge":31536000},"/_nuxt/builds/":{"maxAge":1},"/_fonts/":{"maxAge":31536000},"/_nuxt/":{"maxAge":31536000}};

function isPublicAssetURL(id = '') {
  if (assets[id]) {
    return true
  }
  for (const base in publicAssetBases) {
    if (id.startsWith(base)) { return true }
  }
  return false
}

function getAsset (id) {
  return assets[id]
}

const METHODS = /* @__PURE__ */ new Set(["HEAD", "GET"]);
const EncodingMap = { gzip: ".gz", br: ".br" };
const _OkA_gT = eventHandler((event) => {
  if (event.method && !METHODS.has(event.method)) {
    return;
  }
  let id = decodePath(
    withLeadingSlash(withoutTrailingSlash(parseURL(event.path).pathname))
  );
  let asset;
  const encodingHeader = String(
    getRequestHeader(event, "accept-encoding") || ""
  );
  const encodings = [
    ...encodingHeader.split(",").map((e) => EncodingMap[e.trim()]).filter(Boolean).sort(),
    ""
  ];
  for (const encoding of encodings) {
    for (const _id of [id + encoding, joinURL(id, "index.html" + encoding)]) {
      const _asset = getAsset(_id);
      if (_asset) {
        asset = _asset;
        id = _id;
        break;
      }
    }
  }
  if (!asset) {
    if (isPublicAssetURL(id)) {
      removeResponseHeader(event, "Cache-Control");
      throw createError$1({ statusCode: 404 });
    }
    return;
  }
  if (asset.encoding !== void 0) {
    appendResponseHeader(event, "Vary", "Accept-Encoding");
  }
  const ifNotMatch = getRequestHeader(event, "if-none-match") === asset.etag;
  if (ifNotMatch) {
    setResponseStatus(event, 304, "Not Modified");
    return "";
  }
  const ifModifiedSinceH = getRequestHeader(event, "if-modified-since");
  const mtimeDate = new Date(asset.mtime);
  if (ifModifiedSinceH && asset.mtime && new Date(ifModifiedSinceH) >= mtimeDate) {
    setResponseStatus(event, 304, "Not Modified");
    return "";
  }
  if (asset.type && !getResponseHeader(event, "Content-Type")) {
    setResponseHeader(event, "Content-Type", asset.type);
  }
  if (asset.etag && !getResponseHeader(event, "ETag")) {
    setResponseHeader(event, "ETag", asset.etag);
  }
  if (asset.mtime && !getResponseHeader(event, "Last-Modified")) {
    setResponseHeader(event, "Last-Modified", mtimeDate.toUTCString());
  }
  if (asset.encoding && !getResponseHeader(event, "Content-Encoding")) {
    setResponseHeader(event, "Content-Encoding", asset.encoding);
  }
  if (asset.size > 0 && !getResponseHeader(event, "Content-Length")) {
    setResponseHeader(event, "Content-Length", asset.size);
  }
  return readAsset(id);
});

const _SxA8c9 = defineEventHandler(() => {});

const collections = {
  'lucide': () => import('../_/icons.mjs').then(m => m.default),
  'simple-icons': () => import('../_/icons2.mjs').then(m => m.default),
};

const DEFAULT_ENDPOINT = "https://api.iconify.design";
const _ziEtqM = defineCachedEventHandler(async (event) => {
  const url = getRequestURL(event);
  if (!url)
    return createError$1({ status: 400, message: "Invalid icon request" });
  const options = useAppConfig().icon;
  const collectionName = event.context.params?.collection?.replace(/\.json$/, "");
  const collection = collectionName ? await collections[collectionName]?.() : null;
  const apiEndPoint = options.iconifyApiEndpoint || DEFAULT_ENDPOINT;
  const icons = url.searchParams.get("icons")?.split(",");
  if (collection) {
    if (icons?.length) {
      const data = getIcons(
        collection,
        icons
      );
      consola.debug(`[Icon] serving ${(icons || []).map((i) => "`" + collectionName + ":" + i + "`").join(",")} from bundled collection`);
      return data;
    }
  }
  if (options.fallbackToApi === true || options.fallbackToApi === "server-only") {
    const apiUrl = new URL("./" + basename(url.pathname) + url.search, apiEndPoint);
    consola.debug(`[Icon] fetching ${(icons || []).map((i) => "`" + collectionName + ":" + i + "`").join(",")} from iconify api`);
    if (apiUrl.host !== new URL(apiEndPoint).host) {
      return createError$1({ status: 400, message: "Invalid icon request" });
    }
    try {
      const data = await $fetch(apiUrl.href);
      return data;
    } catch (e) {
      consola.error(e);
      if (e.status === 404)
        return createError$1({ status: 404 });
      else
        return createError$1({ status: 500, message: "Failed to fetch fallback icon" });
    }
  }
  return createError$1({ status: 404 });
}, {
  group: "nuxt",
  name: "icon",
  getKey(event) {
    const collection = event.context.params?.collection?.replace(/\.json$/, "") || "unknown";
    const icons = String(getQuery(event).icons || "");
    return `${collection}_${icons.split(",")[0]}_${icons.length}_${hash$1(icons)}`;
  },
  swr: true,
  maxAge: 60 * 60 * 24 * 7
  // 1 week
});

const storage = prefixStorage(useStorage(), "i18n");
function cachedFunctionI18n(fn, opts) {
  opts = { maxAge: 1, ...opts };
  const pending = {};
  async function get(key, resolver) {
    const isPending = pending[key];
    if (!isPending) {
      pending[key] = Promise.resolve(resolver());
    }
    try {
      return await pending[key];
    } finally {
      delete pending[key];
    }
  }
  return async (...args) => {
    const key = [opts.name, opts.getKey(...args)].join(":").replace(/:\/$/, ":index");
    const maxAge = opts.maxAge ?? 1;
    const isCacheable = !opts.shouldBypassCache(...args) && maxAge >= 0;
    const cache = isCacheable && await storage.getItemRaw(key);
    if (!cache || cache.ttl < Date.now()) {
      pending[key] = Promise.resolve(fn(...args));
      const value = await get(key, () => fn(...args));
      if (isCacheable) {
        await storage.setItemRaw(key, { ttl: Date.now() + maxAge * 1e3, value, mtime: Date.now() });
      }
      return value;
    }
    return cache.value;
  };
}

const _getMessages = async (locale) => {
  return { [locale]: await getLocaleMessagesMerged(locale, localeLoaders[locale]) };
};
const _getMessagesCached = cachedFunctionI18n(_getMessages, {
  name: "messages",
  maxAge: 60 * 60 * 24,
  getKey: (locale) => locale,
  shouldBypassCache: (locale) => !isLocaleCacheable(locale)
});
const getMessages = _getMessagesCached;
const _getMergedMessages = async (locale, fallbackLocales) => {
  const merged = {};
  try {
    if (fallbackLocales.length > 0) {
      const messages = await Promise.all(fallbackLocales.map(getMessages));
      for (const message2 of messages) {
        deepCopy(message2, merged);
      }
    }
    const message = await getMessages(locale);
    deepCopy(message, merged);
    return merged;
  } catch (e) {
    throw new Error("Failed to merge messages: " + e.message);
  }
};
const getMergedMessages = cachedFunctionI18n(_getMergedMessages, {
  name: "merged-single",
  maxAge: 60 * 60 * 24,
  getKey: (locale, fallbackLocales) => `${locale}-[${[...new Set(fallbackLocales)].sort().join("-")}]`,
  shouldBypassCache: (locale, fallbackLocales) => !isLocaleWithFallbacksCacheable(locale, fallbackLocales)
});
const _getAllMergedMessages = async (locales) => {
  const merged = {};
  try {
    const messages = await Promise.all(locales.map(getMessages));
    for (const message of messages) {
      deepCopy(message, merged);
    }
    return merged;
  } catch (e) {
    throw new Error("Failed to merge messages: " + e.message);
  }
};
cachedFunctionI18n(_getAllMergedMessages, {
  name: "merged-all",
  maxAge: 60 * 60 * 24,
  getKey: (locales) => locales.join("-"),
  shouldBypassCache: (locales) => !locales.every((locale) => isLocaleCacheable(locale))
});

const _messagesHandler = defineEventHandler(async (event) => {
  const locale = getRouterParam(event, "locale");
  if (!locale) {
    throw createError$1({ status: 400, message: "Locale not specified." });
  }
  const ctx = useI18nContext(event);
  if (ctx.localeConfigs && locale in ctx.localeConfigs === false) {
    throw createError$1({ status: 404, message: `Locale '${locale}' not found.` });
  }
  const messages = await getMergedMessages(locale, ctx.localeConfigs?.[locale]?.fallbacks ?? []);
  deepCopy(messages, ctx.messages);
  return ctx.messages;
});
const _cachedMessageLoader = defineCachedFunction(_messagesHandler, {
  name: "i18n:messages-internal",
  maxAge: 60 * 60 * 24,
  getKey: (event) => [getRouterParam(event, "locale") ?? "null", getRouterParam(event, "hash") ?? "null"].join("-"),
  async shouldBypassCache(event) {
    const locale = getRouterParam(event, "locale");
    if (locale == null) {
      return false;
    }
    const ctx = tryUseI18nContext(event) || await initializeI18nContext(event);
    return !ctx.localeConfigs?.[locale]?.cacheable;
  }
});
const _messagesHandlerCached = defineCachedEventHandler(_cachedMessageLoader, {
  name: "i18n:messages",
  maxAge: 10,
  swr: false,
  getKey: (event) => [getRouterParam(event, "locale") ?? "null", getRouterParam(event, "hash") ?? "null"].join("-")
});
const _6_YHkp = _messagesHandlerCached;

const _lazy_TCV6zM = () => import('../routes/api/config.get.mjs');
const _lazy_fTPY7T = () => import('../routes/api/kanban/dispatch.post.mjs');
const _lazy_DjCnMT = () => import('../routes/api/kanban/tasks.get.mjs');
const _lazy_8IJv8u = () => import('../routes/api/kanban/tasks/_id/approve-and-retry.post.mjs');
const _lazy_tG4wLr = () => import('../routes/api/kanban/tasks/_id/failure.get.mjs');
const _lazy_bn5t87 = () => import('../routes/api/kanban/tasks/_id/feed.get.mjs');
const _lazy_kIEYc8 = () => import('../routes/api/kanban/tasks/_id/kill.post.mjs');
const _lazy_dRZgui = () => import('../routes/api/kanban/tasks/_id/log.get.mjs');
const _lazy_7kqu3s = () => import('../routes/api/kanban/tasks/history.get.mjs');
const _lazy_hnxIUa = () => import('../routes/api/missions.post.mjs');
const _lazy_My8Alz = () => import('../routes/api/missions/_id/archive.post.mjs');
const _lazy_Q5Y7jC = () => import('../routes/api/missions/index.get.mjs');
const _lazy_cVZYP_ = () => import('../routes/api/missions/_id/messages.post.mjs');
const _lazy_iM9Sbe = () => import('../routes/api/missions/_id/stream.get.mjs');
const _lazy_KXfG7f = () => import('../routes/api/missions/active.get.mjs');
const _lazy_yjDBaK = () => import('../routes/api/index.get.mjs');
const _lazy_kAVtIH = () => import('../routes/api/models.get.mjs');
const _lazy_R5W6Br = () => import('../routes/api/orchestrators/_slug/warmup.post.mjs');
const _lazy_RqlB7f = () => import('../routes/api/presets.get.mjs');
const _lazy_C_dZWL = () => import('../routes/api/profiles.get.mjs');
const _lazy_gg7HmU = () => import('../routes/api/profiles.post.mjs');
const _lazy_PLg4M2 = () => import('../routes/api/profiles/_slug_.delete.mjs');
const _lazy_jKdgka = () => import('../routes/api/profiles/_slug_.patch.mjs');
const _lazy_dEQSC8 = () => import('../routes/api/profiles/_slug/agents.get.mjs');
const _lazy_109Ifs = () => import('../routes/api/profiles/_slug/agents.put.mjs');
const _lazy_hbZwzD = () => import('../routes/api/profiles/_slug/config.get.mjs');
const _lazy_aFbH54 = () => import('../routes/api/profiles/_slug/config.put.mjs');
const _lazy_pCeCxc = () => import('../routes/api/profiles/_slug/mcp.get.mjs');
const _lazy_wrkf6A = () => import('../routes/api/profiles/_slug/mcp/_name_.delete.mjs');
const _lazy_JBIuvO = () => import('../routes/api/profiles/_slug/rename.post.mjs');
const _lazy_xeMwMl = () => import('../routes/api/profiles/_slug/skills.get.mjs');
const _lazy_MD9165 = () => import('../routes/api/profiles/_slug/skills.put.mjs');
const _lazy_jRJWeN = () => import('../routes/api/profiles/_slug/soul.get.mjs');
const _lazy_2JXpiP = () => import('../routes/api/profiles/_slug/soul.put.mjs');
const _lazy_0eU_9X = () => import('../routes/api/profiles/_slug/tools.get.mjs');
const _lazy_kXz6pc = () => import('../routes/api/profiles/_slug/tools.put.mjs');
const _lazy_4SJACj = () => import('../routes/api/skills.get.mjs');
const _lazy_7jLhMh = () => import('../routes/api/tools.get.mjs');
const _lazy_roKdui = () => import('../routes/api/usage.get.mjs');
const _lazy_Ittf4Z = () => import('../routes/renderer.mjs').then(function (n) { return n.r; });

const handlers = [
  { route: '', handler: _OkA_gT, lazy: false, middleware: true, method: undefined },
  { route: '/api/config', handler: _lazy_TCV6zM, lazy: true, middleware: false, method: "get" },
  { route: '/api/kanban/dispatch', handler: _lazy_fTPY7T, lazy: true, middleware: false, method: "post" },
  { route: '/api/kanban/tasks', handler: _lazy_DjCnMT, lazy: true, middleware: false, method: "get" },
  { route: '/api/kanban/tasks/:id/approve-and-retry', handler: _lazy_8IJv8u, lazy: true, middleware: false, method: "post" },
  { route: '/api/kanban/tasks/:id/failure', handler: _lazy_tG4wLr, lazy: true, middleware: false, method: "get" },
  { route: '/api/kanban/tasks/:id/feed', handler: _lazy_bn5t87, lazy: true, middleware: false, method: "get" },
  { route: '/api/kanban/tasks/:id/kill', handler: _lazy_kIEYc8, lazy: true, middleware: false, method: "post" },
  { route: '/api/kanban/tasks/:id/log', handler: _lazy_dRZgui, lazy: true, middleware: false, method: "get" },
  { route: '/api/kanban/tasks/history', handler: _lazy_7kqu3s, lazy: true, middleware: false, method: "get" },
  { route: '/api/missions', handler: _lazy_hnxIUa, lazy: true, middleware: false, method: "post" },
  { route: '/api/missions/:id/archive', handler: _lazy_My8Alz, lazy: true, middleware: false, method: "post" },
  { route: '/api/missions/:id', handler: _lazy_Q5Y7jC, lazy: true, middleware: false, method: "get" },
  { route: '/api/missions/:id/messages', handler: _lazy_cVZYP_, lazy: true, middleware: false, method: "post" },
  { route: '/api/missions/:id/stream', handler: _lazy_iM9Sbe, lazy: true, middleware: false, method: "get" },
  { route: '/api/missions/active', handler: _lazy_KXfG7f, lazy: true, middleware: false, method: "get" },
  { route: '/api/missions', handler: _lazy_yjDBaK, lazy: true, middleware: false, method: "get" },
  { route: '/api/models', handler: _lazy_kAVtIH, lazy: true, middleware: false, method: "get" },
  { route: '/api/orchestrators/:slug/warmup', handler: _lazy_R5W6Br, lazy: true, middleware: false, method: "post" },
  { route: '/api/presets', handler: _lazy_RqlB7f, lazy: true, middleware: false, method: "get" },
  { route: '/api/profiles', handler: _lazy_C_dZWL, lazy: true, middleware: false, method: "get" },
  { route: '/api/profiles', handler: _lazy_gg7HmU, lazy: true, middleware: false, method: "post" },
  { route: '/api/profiles/:slug', handler: _lazy_PLg4M2, lazy: true, middleware: false, method: "delete" },
  { route: '/api/profiles/:slug', handler: _lazy_jKdgka, lazy: true, middleware: false, method: "patch" },
  { route: '/api/profiles/:slug/agents', handler: _lazy_dEQSC8, lazy: true, middleware: false, method: "get" },
  { route: '/api/profiles/:slug/agents', handler: _lazy_109Ifs, lazy: true, middleware: false, method: "put" },
  { route: '/api/profiles/:slug/config', handler: _lazy_hbZwzD, lazy: true, middleware: false, method: "get" },
  { route: '/api/profiles/:slug/config', handler: _lazy_aFbH54, lazy: true, middleware: false, method: "put" },
  { route: '/api/profiles/:slug/mcp', handler: _lazy_pCeCxc, lazy: true, middleware: false, method: "get" },
  { route: '/api/profiles/:slug/mcp/:name', handler: _lazy_wrkf6A, lazy: true, middleware: false, method: "delete" },
  { route: '/api/profiles/:slug/rename', handler: _lazy_JBIuvO, lazy: true, middleware: false, method: "post" },
  { route: '/api/profiles/:slug/skills', handler: _lazy_xeMwMl, lazy: true, middleware: false, method: "get" },
  { route: '/api/profiles/:slug/skills', handler: _lazy_MD9165, lazy: true, middleware: false, method: "put" },
  { route: '/api/profiles/:slug/soul', handler: _lazy_jRJWeN, lazy: true, middleware: false, method: "get" },
  { route: '/api/profiles/:slug/soul', handler: _lazy_2JXpiP, lazy: true, middleware: false, method: "put" },
  { route: '/api/profiles/:slug/tools', handler: _lazy_0eU_9X, lazy: true, middleware: false, method: "get" },
  { route: '/api/profiles/:slug/tools', handler: _lazy_kXz6pc, lazy: true, middleware: false, method: "put" },
  { route: '/api/skills', handler: _lazy_4SJACj, lazy: true, middleware: false, method: "get" },
  { route: '/api/tools', handler: _lazy_7jLhMh, lazy: true, middleware: false, method: "get" },
  { route: '/api/usage', handler: _lazy_roKdui, lazy: true, middleware: false, method: "get" },
  { route: '/__nuxt_error', handler: _lazy_Ittf4Z, lazy: true, middleware: false, method: undefined },
  { route: '/__nuxt_island/**', handler: _SxA8c9, lazy: false, middleware: false, method: undefined },
  { route: '/api/_nuxt_icon/:collection', handler: _ziEtqM, lazy: false, middleware: false, method: undefined },
  { route: '/_i18n/:hash/:locale/messages.json', handler: _6_YHkp, lazy: false, middleware: false, method: undefined },
  { route: '/**', handler: _lazy_Ittf4Z, lazy: true, middleware: false, method: undefined }
];

function createNitroApp() {
  const config = useRuntimeConfig();
  const hooks = createHooks();
  const captureError = (error, context = {}) => {
    const promise = hooks.callHookParallel("error", error, context).catch((error_) => {
      console.error("Error while capturing another error", error_);
    });
    if (context.event && isEvent(context.event)) {
      const errors = context.event.context.nitro?.errors;
      if (errors) {
        errors.push({ error, context });
      }
      if (context.event.waitUntil) {
        context.event.waitUntil(promise);
      }
    }
  };
  const h3App = createApp({
    debug: destr(false),
    onError: (error, event) => {
      captureError(error, { event, tags: ["request"] });
      return errorHandler(error, event);
    },
    onRequest: async (event) => {
      event.context.nitro = event.context.nitro || { errors: [] };
      const fetchContext = event.node.req?.__unenv__;
      if (fetchContext?._platform) {
        event.context = {
          _platform: fetchContext?._platform,
          // #3335
          ...fetchContext._platform,
          ...event.context
        };
      }
      if (!event.context.waitUntil && fetchContext?.waitUntil) {
        event.context.waitUntil = fetchContext.waitUntil;
      }
      event.fetch = (req, init) => fetchWithEvent(event, req, init, { fetch: localFetch });
      event.$fetch = (req, init) => fetchWithEvent(event, req, init, {
        fetch: $fetch
      });
      event.waitUntil = (promise) => {
        if (!event.context.nitro._waitUntilPromises) {
          event.context.nitro._waitUntilPromises = [];
        }
        event.context.nitro._waitUntilPromises.push(promise);
        if (event.context.waitUntil) {
          event.context.waitUntil(promise);
        }
      };
      event.captureError = (error, context) => {
        captureError(error, { event, ...context });
      };
      await nitroApp$1.hooks.callHook("request", event).catch((error) => {
        captureError(error, { event, tags: ["request"] });
      });
    },
    onBeforeResponse: async (event, response) => {
      await nitroApp$1.hooks.callHook("beforeResponse", event, response).catch((error) => {
        captureError(error, { event, tags: ["request", "response"] });
      });
    },
    onAfterResponse: async (event, response) => {
      await nitroApp$1.hooks.callHook("afterResponse", event, response).catch((error) => {
        captureError(error, { event, tags: ["request", "response"] });
      });
    }
  });
  const router = createRouter({
    preemptive: true
  });
  const nodeHandler = toNodeListener(h3App);
  const localCall = (aRequest) => b(
    nodeHandler,
    aRequest
  );
  const localFetch = (input, init) => {
    if (!input.toString().startsWith("/")) {
      return globalThis.fetch(input, init);
    }
    return C(
      nodeHandler,
      input,
      init
    ).then((response) => normalizeFetchResponse(response));
  };
  const $fetch = createFetch({
    fetch: localFetch,
    Headers: Headers$1,
    defaults: { baseURL: config.app.baseURL }
  });
  globalThis.$fetch = $fetch;
  h3App.use(createRouteRulesHandler({ localFetch }));
  for (const h of handlers) {
    let handler = h.lazy ? lazyEventHandler(h.handler) : h.handler;
    if (h.middleware || !h.route) {
      const middlewareBase = (config.app.baseURL + (h.route || "/")).replace(
        /\/+/g,
        "/"
      );
      h3App.use(middlewareBase, handler);
    } else {
      const routeRules = getRouteRulesForPath(
        h.route.replace(/:\w+|\*\*/g, "_")
      );
      if (routeRules.cache) {
        handler = cachedEventHandler(handler, {
          group: "nitro/routes",
          ...routeRules.cache
        });
      }
      router.use(h.route, handler, h.method);
    }
  }
  h3App.use(config.app.baseURL, router.handler);
  const app = {
    hooks,
    h3App,
    router,
    localCall,
    localFetch,
    captureError
  };
  return app;
}
function runNitroPlugins(nitroApp2) {
  for (const plugin of plugins) {
    try {
      plugin(nitroApp2);
    } catch (error) {
      nitroApp2.captureError(error, { tags: ["plugin"] });
      throw error;
    }
  }
}
const nitroApp$1 = createNitroApp();
function useNitroApp() {
  return nitroApp$1;
}
runNitroPlugins(nitroApp$1);

const NullObject = /* @__PURE__ */ (() => {
  const C = function() {
  };
  C.prototype = /* @__PURE__ */ Object.create(null);
  return C;
})();
function parse(str, options) {
  if (typeof str !== "string") {
    throw new TypeError("argument str must be a string");
  }
  const obj = new NullObject();
  const opt = options || {};
  const dec = opt.decode || decode;
  let index = 0;
  while (index < str.length) {
    const eqIdx = str.indexOf("=", index);
    if (eqIdx === -1) {
      break;
    }
    let endIdx = str.indexOf(";", index);
    if (endIdx === -1) {
      endIdx = str.length;
    } else if (endIdx < eqIdx) {
      index = str.lastIndexOf(";", eqIdx - 1) + 1;
      continue;
    }
    const key = str.slice(index, eqIdx).trim();
    if (opt?.filter && !opt?.filter(key)) {
      index = endIdx + 1;
      continue;
    }
    if (void 0 === obj[key]) {
      let val = str.slice(eqIdx + 1, endIdx).trim();
      if (val.codePointAt(0) === 34) {
        val = val.slice(1, -1);
      }
      obj[key] = tryDecode(val, dec);
    }
    index = endIdx + 1;
  }
  return obj;
}
function decode(str) {
  return str.includes("%") ? decodeURIComponent(str) : str;
}
function tryDecode(str, decode2) {
  try {
    return decode2(str);
  } catch {
    return str;
  }
}

const debug = (...args) => {
};
function GracefulShutdown(server, opts) {
  opts = opts || {};
  const options = Object.assign(
    {
      signals: "SIGINT SIGTERM",
      timeout: 3e4,
      development: false,
      forceExit: true,
      onShutdown: (signal) => Promise.resolve(signal),
      preShutdown: (signal) => Promise.resolve(signal)
    },
    opts
  );
  let isShuttingDown = false;
  const connections = {};
  let connectionCounter = 0;
  const secureConnections = {};
  let secureConnectionCounter = 0;
  let failed = false;
  let finalRun = false;
  function onceFactory() {
    let called = false;
    return (emitter, events, callback) => {
      function call() {
        if (!called) {
          called = true;
          return Reflect.apply(callback, this, arguments);
        }
      }
      for (const e of events) {
        emitter.on(e, call);
      }
    };
  }
  const signals = options.signals.split(" ").map((s) => s.trim()).filter((s) => s.length > 0);
  const once = onceFactory();
  once(process, signals, (signal) => {
    debug("received shut down signal", signal);
    shutdown(signal).then(() => {
      if (options.forceExit) {
        process.exit(failed ? 1 : 0);
      }
    }).catch((error) => {
      debug("server shut down error occurred", error);
      process.exit(1);
    });
  });
  function isFunction(functionToCheck) {
    const getType = Object.prototype.toString.call(functionToCheck);
    return /^\[object\s([A-Za-z]+)?Function]$/.test(getType);
  }
  function destroy(socket, force = false) {
    if (socket._isIdle && isShuttingDown || force) {
      socket.destroy();
      if (socket.server instanceof http.Server) {
        delete connections[socket._connectionId];
      } else {
        delete secureConnections[socket._connectionId];
      }
    }
  }
  function destroyAllConnections(force = false) {
    debug("Destroy Connections : " + (force ? "forced close" : "close"));
    let counter = 0;
    let secureCounter = 0;
    for (const key of Object.keys(connections)) {
      const socket = connections[key];
      const serverResponse = socket._httpMessage;
      if (serverResponse && !force) {
        if (!serverResponse.headersSent) {
          serverResponse.setHeader("connection", "close");
        }
      } else {
        counter++;
        destroy(socket);
      }
    }
    debug("Connections destroyed : " + counter);
    debug("Connection Counter    : " + connectionCounter);
    for (const key of Object.keys(secureConnections)) {
      const socket = secureConnections[key];
      const serverResponse = socket._httpMessage;
      if (serverResponse && !force) {
        if (!serverResponse.headersSent) {
          serverResponse.setHeader("connection", "close");
        }
      } else {
        secureCounter++;
        destroy(socket);
      }
    }
    debug("Secure Connections destroyed : " + secureCounter);
    debug("Secure Connection Counter    : " + secureConnectionCounter);
  }
  server.on("request", (req, res) => {
    req.socket._isIdle = false;
    if (isShuttingDown && !res.headersSent) {
      res.setHeader("connection", "close");
    }
    res.on("finish", () => {
      req.socket._isIdle = true;
      destroy(req.socket);
    });
  });
  server.on("connection", (socket) => {
    if (isShuttingDown) {
      socket.destroy();
    } else {
      const id = connectionCounter++;
      socket._isIdle = true;
      socket._connectionId = id;
      connections[id] = socket;
      socket.once("close", () => {
        delete connections[socket._connectionId];
      });
    }
  });
  server.on("secureConnection", (socket) => {
    if (isShuttingDown) {
      socket.destroy();
    } else {
      const id = secureConnectionCounter++;
      socket._isIdle = true;
      socket._connectionId = id;
      secureConnections[id] = socket;
      socket.once("close", () => {
        delete secureConnections[socket._connectionId];
      });
    }
  });
  process.on("close", () => {
    debug("closed");
  });
  function shutdown(sig) {
    function cleanupHttp() {
      destroyAllConnections();
      debug("Close http server");
      return new Promise((resolve, reject) => {
        server.close((err) => {
          if (err) {
            return reject(err);
          }
          return resolve(true);
        });
      });
    }
    debug("shutdown signal - " + sig);
    if (options.development) {
      debug("DEV-Mode - immediate forceful shutdown");
      return process.exit(0);
    }
    function finalHandler() {
      if (!finalRun) {
        finalRun = true;
        if (options.finally && isFunction(options.finally)) {
          debug("executing finally()");
          options.finally();
        }
      }
      return Promise.resolve();
    }
    function waitForReadyToShutDown(totalNumInterval) {
      debug(`waitForReadyToShutDown... ${totalNumInterval}`);
      if (totalNumInterval === 0) {
        debug(
          `Could not close connections in time (${options.timeout}ms), will forcefully shut down`
        );
        return Promise.resolve(true);
      }
      const allConnectionsClosed = Object.keys(connections).length === 0 && Object.keys(secureConnections).length === 0;
      if (allConnectionsClosed) {
        debug("All connections closed. Continue to shutting down");
        return Promise.resolve(false);
      }
      debug("Schedule the next waitForReadyToShutdown");
      return new Promise((resolve) => {
        setTimeout(() => {
          resolve(waitForReadyToShutDown(totalNumInterval - 1));
        }, 250);
      });
    }
    if (isShuttingDown) {
      return Promise.resolve();
    }
    debug("shutting down");
    return options.preShutdown(sig).then(() => {
      isShuttingDown = true;
      cleanupHttp();
    }).then(() => {
      const pollIterations = options.timeout ? Math.round(options.timeout / 250) : 0;
      return waitForReadyToShutDown(pollIterations);
    }).then((force) => {
      debug("Do onShutdown now");
      if (force) {
        destroyAllConnections(force);
      }
      return options.onShutdown(sig);
    }).then(finalHandler).catch((error) => {
      const errString = typeof error === "string" ? error : JSON.stringify(error);
      debug(errString);
      failed = true;
      throw errString;
    });
  }
  function shutdownManual() {
    return shutdown("manual");
  }
  return shutdownManual;
}

function getGracefulShutdownConfig() {
  return {
    disabled: !!process.env.NITRO_SHUTDOWN_DISABLED,
    signals: (process.env.NITRO_SHUTDOWN_SIGNALS || "SIGTERM SIGINT").split(" ").map((s) => s.trim()),
    timeout: Number.parseInt(process.env.NITRO_SHUTDOWN_TIMEOUT || "", 10) || 3e4,
    forceExit: !process.env.NITRO_SHUTDOWN_NO_FORCE_EXIT
  };
}
function setupGracefulShutdown(listener, nitroApp) {
  const shutdownConfig = getGracefulShutdownConfig();
  if (shutdownConfig.disabled) {
    return;
  }
  GracefulShutdown(listener, {
    signals: shutdownConfig.signals.join(" "),
    timeout: shutdownConfig.timeout,
    forceExit: shutdownConfig.forceExit,
    onShutdown: async () => {
      await new Promise((resolve) => {
        const timeout = setTimeout(() => {
          console.warn("Graceful shutdown timeout, force exiting...");
          resolve();
        }, shutdownConfig.timeout);
        nitroApp.hooks.callHook("close").catch((error) => {
          console.error(error);
        }).finally(() => {
          clearTimeout(timeout);
          resolve();
        });
      });
    }
  });
}

const cert = process.env.NITRO_SSL_CERT;
const key = process.env.NITRO_SSL_KEY;
const nitroApp = useNitroApp();
const server = cert && key ? new Server({ key, cert }, toNodeListener(nitroApp.h3App)) : new Server$1(toNodeListener(nitroApp.h3App));
const port = destr(process.env.NITRO_PORT || process.env.PORT) || 3e3;
const host = process.env.NITRO_HOST || process.env.HOST;
const path = process.env.NITRO_UNIX_SOCKET;
const listener = server.listen(path ? { path } : { port, host }, (err) => {
  if (err) {
    console.error(err);
    process.exit(1);
  }
  const protocol = cert && key ? "https" : "http";
  const addressInfo = listener.address();
  if (typeof addressInfo === "string") {
    console.log(`Listening on unix socket ${addressInfo}`);
    return;
  }
  const baseURL = (useRuntimeConfig().app.baseURL || "").replace(/\/$/, "");
  const url = `${protocol}://${addressInfo.family === "IPv6" ? `[${addressInfo.address}]` : addressInfo.address}:${addressInfo.port}${baseURL}`;
  console.log(`Listening on ${url}`);
});
trapUnhandledNodeErrors();
setupGracefulShutdown(listener, nitroApp);
const nodeServer = {};

export { appSpaLoaderTag as $, getActiveMission as A, listMissions as B, countMissions as C, warmup as D, discoverProfiles as E, defaultSeed as F, pickColor as G, syncRoster as H, avatarUrl as I, setDisabledSkills as J, writeSoul as K, writeAgents as L, listTools as M, applyToolState as N, readAgents as O, PRESETS as P, restart as Q, listMcpServers as R, removeMcpServer as S, listGlobalSkills as T, listProfileSkills as U, getDisabledSkills as V, readSoul as W, readTokenUsage as X, appRootTag as Y, appRootAttrs as Z, buildAssetsURL as _, dispatcherLikelyStale as a, appSpaLoaderAttrs as a0, useRuntimeConfig as a1, getResponseStatusText as a2, getResponseStatus as a3, appId as a4, defineRenderHandler as a5, publicAssetsURL as a6, appTeleportTag as a7, appTeleportAttrs as a8, appHead as a9, parse as aA, createDefu as aB, parsePath as aC, setCookie as aD, deleteCookie as aE, nodeServer as aF, destr as aa, getRouteRules as ab, joinURL as ac, useNitroApp as ad, defu as ae, klona as af, parseQuery as ag, defuFn as ah, hasProtocol as ai, parseURL as aj, encodePath as ak, decodePath as al, getContext as am, isEqual as an, withQuery as ao, isScriptProtocol as ap, withTrailingSlash as aq, withoutTrailingSlash as ar, sanitizeStatusCode as as, $fetch$1 as at, baseURL as au, hash$1 as av, executeAsync as aw, getRequestURL as ax, getRequestHeader as ay, getCookie as az, getRouterParam as b, createError$1 as c, defineEventHandler as d, getKanbanDb as e, readProfileConfig as f, getQuery as g, getFailureContext as h, distillReason as i, extractPermissionLabel as j, looksLikePermissionDenial as k, listActiveTasks as l, getTaskFeed as m, listCompletedTasks as n, createMission as o, runMissionTurn as p, getMission as q, readBody as r, setResponseStatus as s, archiveMission as t, useDb as u, removeMission as v, writeProfileConfig as w, listMessages as x, createEventStream as y, getMissionBus as z };

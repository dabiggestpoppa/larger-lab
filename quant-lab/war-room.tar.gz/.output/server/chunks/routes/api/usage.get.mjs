import { d as defineEventHandler, u as useDb, X as readTokenUsage } from '../../nitro/nitro.mjs';
import 'node:fs';
import 'node:path';
import 'node:os';
import 'yaml';
import 'node:sqlite';
import 'node:child_process';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:crypto';
import 'vue-router';
import 'node:stream';
import '@zed-industries/agent-client-protocol';
import 'node:url';
import '@iconify/utils';
import 'consola';

const usage_get = defineEventHandler(() => {
  const db = useDb();
  const rows = db.prepare("SELECT slug, hermes_dir FROM profiles WHERE present = 1").all();
  const usage = {};
  for (const r of rows) {
    usage[r.slug] = readTokenUsage(r.hermes_dir);
  }
  return { usage, generatedAt: Date.now() };
});

export { usage_get as default };

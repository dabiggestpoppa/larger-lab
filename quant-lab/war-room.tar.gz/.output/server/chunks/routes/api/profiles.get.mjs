import { d as defineEventHandler, u as useDb, E as discoverProfiles, F as defaultSeed, G as pickColor, f as readProfileConfig, H as syncRoster, I as avatarUrl } from '../../nitro/nitro.mjs';
import 'node:fs';
import 'node:path';
import 'node:os';
import 'yaml';
import 'node:sqlite';
import 'node:child_process';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:crypto';
import 'vue-router';
import 'node:stream';
import '@zed-industries/agent-client-protocol';
import 'node:url';
import '@iconify/utils';
import 'consola';

let rosterPrimed = false;
const profiles_get = defineEventHandler(() => {
  const db = useDb();
  const now = (/* @__PURE__ */ new Date()).toISOString();
  const discovered = discoverProfiles();
  const insert = db.prepare(`
    INSERT INTO profiles (slug, display_name, is_default, hermes_dir, avatar_seed, background_color, gesture, first_seen, last_seen, present)
    VALUES (?, ?, ?, ?, ?, ?, 'hand', ?, ?, 1)
    ON CONFLICT(slug) DO UPDATE SET
      display_name = excluded.display_name,
      is_default   = excluded.is_default,
      hermes_dir   = excluded.hermes_dir,
      last_seen    = excluded.last_seen,
      present      = 1
  `);
  db.exec("UPDATE profiles SET present = 0");
  for (const p of discovered) {
    insert.run(
      p.slug,
      p.slug,
      p.isDefault ? 1 : 0,
      p.hermesDir,
      defaultSeed(p.slug),
      pickColor(p.slug),
      now,
      now
    );
  }
  const updateCallsign = db.prepare("UPDATE profiles SET given_name = ? WHERE slug = ?");
  for (const p of discovered) {
    const config = readProfileConfig(p.hermesDir);
    if (config.name) {
      updateCallsign.run(config.name, p.slug);
    }
  }
  const rows = db.prepare("SELECT * FROM profiles WHERE present = 1 ORDER BY is_default DESC, slug ASC").all();
  if (!rosterPrimed) {
    rosterPrimed = true;
    try {
      syncRoster();
    } catch (e) {
      console.error("[roster] initial sync failed:", e.message);
    }
  }
  return rows.map((r) => ({
    slug: r.slug,
    displayName: r.display_name,
    givenName: r.given_name,
    isDefault: r.is_default === 1,
    active: r.active === 1,
    hermesDir: r.hermes_dir,
    backgroundColor: r.background_color,
    gesture: r.gesture,
    avatarSeed: r.avatar_seed,
    avatarUrl: avatarUrl({
      seed: r.avatar_seed,
      backgroundColor: r.background_color,
      gesture: r.gesture,
      size: 240
    }),
    avatarPortraitUrl: avatarUrl({
      seed: r.avatar_seed,
      gesture: r.gesture,
      size: 320,
      transparent: true
    }),
    firstSeen: r.first_seen,
    lastSeen: r.last_seen
  }));
});

export { profiles_get as default };

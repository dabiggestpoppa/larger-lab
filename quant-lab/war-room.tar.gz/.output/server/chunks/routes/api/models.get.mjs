import { d as defineEventHandler } from '../../nitro/nitro.mjs';
import { existsSync, statSync, readFileSync } from 'node:fs';
import { join } from 'node:path';
import { homedir } from 'node:os';
import { parse } from 'yaml';
import 'node:sqlite';
import 'node:child_process';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:crypto';
import 'vue-router';
import 'node:stream';
import '@zed-industries/agent-client-protocol';
import 'node:url';
import '@iconify/utils';
import 'consola';

const HERMES_HOME = process.env.HERMES_HOME || join(homedir(), ".hermes");
const CATALOG_PATH = join(HERMES_HOME, "cache", "model_catalog.json");
const CONFIG_PATH = join(HERMES_HOME, "config.yaml");
let cached = null;
function loadCatalog() {
  if (!existsSync(CATALOG_PATH)) return null;
  try {
    return JSON.parse(readFileSync(CATALOG_PATH, "utf8"));
  } catch {
    return null;
  }
}
function loadHermesConfig() {
  if (!existsSync(CONFIG_PATH)) return null;
  try {
    return parse(readFileSync(CONFIG_PATH, "utf8"));
  } catch {
    return null;
  }
}
const FALLBACK_PROVIDERS = {
  anthropic: "Anthropic",
  openai: "OpenAI",
  custom: "Custom (base_url)"
};
function extractModelIds(raw) {
  if (!raw) return [];
  if (Array.isArray(raw)) {
    const out = [];
    for (const entry of raw) {
      if (typeof entry === "string") out.push(entry);
      else if (entry && typeof entry === "object" && "id" in entry && typeof entry.id === "string") {
        out.push(entry.id);
      }
    }
    return out;
  }
  if (typeof raw === "object") return Object.keys(raw);
  return [];
}
function build(catalog, config) {
  var _a, _b, _c, _d, _e, _f, _g, _h;
  const providers = [];
  const seen = /* @__PURE__ */ new Set();
  const models = [];
  const modelKey = (m) => `${m.provider}::${m.id}`;
  const modelKeys = /* @__PURE__ */ new Set();
  for (const [pid, body] of Object.entries((_a = catalog == null ? void 0 : catalog.providers) != null ? _a : {})) {
    const list = Array.isArray(body == null ? void 0 : body.models) ? body.models : [];
    providers.push({
      id: pid,
      label: (_c = (_b = body == null ? void 0 : body.metadata) == null ? void 0 : _b.display_name) != null ? _c : pid,
      count: list.length
    });
    seen.add(pid);
    for (const m of list) {
      if (!(m == null ? void 0 : m.id)) continue;
      const desc = ((_d = m.description) != null ? _d : "").toLowerCase();
      const opt = {
        id: m.id,
        provider: pid,
        description: (_e = m.description) != null ? _e : "",
        recommended: desc.includes("recommended"),
        free: desc.includes("free")
      };
      models.push(opt);
      modelKeys.add(modelKey(opt));
    }
  }
  const configModels = [];
  const ensureProvider = (id, label) => {
    var _a2;
    if (!seen.has(id)) {
      providers.push({ id, label: (_a2 = FALLBACK_PROVIDERS[id]) != null ? _a2 : id, count: 0 });
      seen.add(id);
    }
  };
  if (((_f = config == null ? void 0 : config.model) == null ? void 0 : _f.default) && config.model.provider) {
    const pid = config.model.provider;
    ensureProvider(pid);
    const opt = {
      id: config.model.default,
      provider: pid,
      description: "configured default",
      recommended: false,
      free: false
    };
    if (!modelKeys.has(modelKey(opt))) {
      configModels.push(opt);
      modelKeys.add(modelKey(opt));
    }
  }
  for (const [pid, body] of Object.entries((_g = config == null ? void 0 : config.providers) != null ? _g : {})) {
    if (!body || typeof body !== "object") continue;
    ensureProvider(pid);
    const ids = extractModelIds(body.models);
    if (body.default && !ids.includes(body.default)) ids.unshift(body.default);
    for (const id of ids) {
      const opt = {
        id,
        provider: pid,
        description: "configured",
        recommended: false,
        free: false
      };
      if (!modelKeys.has(modelKey(opt))) {
        configModels.push(opt);
        modelKeys.add(modelKey(opt));
      }
    }
  }
  for (const m of configModels) {
    const p = providers.find((p2) => p2.id === m.provider);
    if (p) p.count += 1;
  }
  models.push(...configModels);
  for (const [pid, label] of Object.entries(FALLBACK_PROVIDERS)) {
    if (!seen.has(pid)) {
      providers.push({ id: pid, label, count: 0 });
    }
  }
  models.sort((a, b) => {
    if (a.recommended !== b.recommended) return a.recommended ? -1 : 1;
    if (a.provider !== b.provider) return a.provider.localeCompare(b.provider);
    return a.id.localeCompare(b.id);
  });
  return {
    updatedAt: (_h = catalog == null ? void 0 : catalog.updated_at) != null ? _h : null,
    providers,
    models
  };
}
const models_get = defineEventHandler(() => {
  const catalogMtimeMs = existsSync(CATALOG_PATH) ? statSync(CATALOG_PATH).mtimeMs : 0;
  const configMtimeMs = existsSync(CONFIG_PATH) ? statSync(CONFIG_PATH).mtimeMs : 0;
  if (!catalogMtimeMs && !configMtimeMs) {
    return { updatedAt: null, providers: [], models: [] };
  }
  if (cached && cached.catalogMtimeMs === catalogMtimeMs && cached.configMtimeMs === configMtimeMs) {
    return cached.payload;
  }
  const catalog = loadCatalog();
  const config = loadHermesConfig();
  const payload = build(catalog, config);
  cached = { catalogMtimeMs, configMtimeMs, payload };
  return payload;
});

export { models_get as default };

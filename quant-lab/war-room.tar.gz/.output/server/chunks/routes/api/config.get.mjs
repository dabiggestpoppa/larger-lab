import { d as defineEventHandler } from '../../nitro/nitro.mjs';
import 'node:fs';
import 'node:path';
import 'node:os';
import 'yaml';
import 'node:sqlite';
import 'node:child_process';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:crypto';
import 'vue-router';
import 'node:stream';
import '@zed-industries/agent-client-protocol';
import 'node:url';
import '@iconify/utils';
import 'consola';

const config_get = defineEventHandler(() => {
  return {
    missionsEnabled: process.env.WAR_ROOM_MISSIONS_ENABLED !== "false"
  };
});

export { config_get as default };

import { d as defineEventHandler, r as readBody, c as createError, u as useDb, o as createMission, p as runMissionTurn, s as setResponseStatus } from '../../nitro/nitro.mjs';
import 'node:fs';
import 'node:path';
import 'node:os';
import 'yaml';
import 'node:sqlite';
import 'node:child_process';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:crypto';
import 'vue-router';
import 'node:stream';
import '@zed-industries/agent-client-protocol';
import 'node:url';
import '@iconify/utils';
import 'consola';

const missions_post = defineEventHandler(async (event) => {
  var _a, _b;
  const body = await readBody(event) || {};
  const slug = ((_a = body.orchestratorSlug) != null ? _a : "").trim();
  const message = ((_b = body.message) != null ? _b : "").trim();
  if (!slug) throw createError({ statusCode: 400, statusMessage: "orchestratorSlug required" });
  if (!message) throw createError({ statusCode: 400, statusMessage: "message required" });
  const db = useDb();
  const profile = db.prepare(
    "SELECT slug, active FROM profiles WHERE slug = ? AND present = 1"
  ).get(slug);
  if (!profile) throw createError({ statusCode: 404, statusMessage: `Profile "${slug}" not found` });
  if (!profile.active) throw createError({ statusCode: 400, statusMessage: `Profile "${slug}" is inactive` });
  const mission = createMission(slug, message);
  runMissionTurn(mission.id, message).catch((e) => {
    console.error(`[mission ${mission.id}] turn failed:`, e.message);
  });
  setResponseStatus(event, 201);
  return {
    mission: {
      id: mission.id,
      orchestratorSlug: mission.orchestrator_slug,
      acpSessionId: mission.acp_session_id,
      title: mission.title,
      status: mission.status,
      createdAt: mission.created_at,
      lastMessageAt: mission.last_message_at
    }
  };
});

export { missions_post as default };

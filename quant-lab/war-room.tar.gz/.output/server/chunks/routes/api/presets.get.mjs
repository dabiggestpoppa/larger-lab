import { d as defineEventHandler, P as PRESETS } from '../../nitro/nitro.mjs';
import 'node:fs';
import 'node:path';
import 'node:os';
import 'yaml';
import 'node:sqlite';
import 'node:child_process';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:crypto';
import 'vue-router';
import 'node:stream';
import '@zed-industries/agent-client-protocol';
import 'node:url';
import '@iconify/utils';
import 'consola';

const presets_get = defineEventHandler(() => {
  return { presets: PRESETS };
});

export { presets_get as default };

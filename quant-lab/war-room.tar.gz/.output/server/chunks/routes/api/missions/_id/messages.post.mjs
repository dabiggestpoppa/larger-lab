import { d as defineEventHandler, b as getRouterParam, c as createError, r as readBody, q as getMission, p as runMissionTurn } from '../../../../nitro/nitro.mjs';
import 'node:fs';
import 'node:path';
import 'node:os';
import 'yaml';
import 'node:sqlite';
import 'node:child_process';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:crypto';
import 'vue-router';
import 'node:stream';
import '@zed-industries/agent-client-protocol';
import 'node:url';
import '@iconify/utils';
import 'consola';

const messages_post = defineEventHandler(async (event) => {
  var _a;
  const id = getRouterParam(event, "id");
  if (!id) throw createError({ statusCode: 400, statusMessage: "Missing mission id" });
  const body = await readBody(event) || {};
  const message = ((_a = body.message) != null ? _a : "").trim();
  if (!message) throw createError({ statusCode: 400, statusMessage: "message required" });
  const mission = getMission(id);
  if (!mission) throw createError({ statusCode: 404, statusMessage: "Mission not found" });
  if (mission.status !== "open") throw createError({ statusCode: 400, statusMessage: "Mission is not open" });
  runMissionTurn(id, message).catch((e) => {
    console.error(`[mission ${id}] turn failed:`, e.message);
  });
  return { ok: true };
});

export { messages_post as default };

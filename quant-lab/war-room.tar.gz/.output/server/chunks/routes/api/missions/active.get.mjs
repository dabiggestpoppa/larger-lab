import { d as defineEventHandler, g as getQuery, c as createError, A as getActiveMission, x as listMessages } from '../../../nitro/nitro.mjs';
import 'node:fs';
import 'node:path';
import 'node:os';
import 'yaml';
import 'node:sqlite';
import 'node:child_process';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:crypto';
import 'vue-router';
import 'node:stream';
import '@zed-industries/agent-client-protocol';
import 'node:url';
import '@iconify/utils';
import 'consola';

const active_get = defineEventHandler((event) => {
  const orchestrator = getQuery(event).orchestrator;
  if (typeof orchestrator !== "string" || !orchestrator) {
    throw createError({ statusCode: 400, statusMessage: "`orchestrator` query param required" });
  }
  const mission = getActiveMission(orchestrator);
  if (!mission) return { mission: null, messages: [] };
  const messages = listMessages(mission.id);
  return {
    mission: {
      id: mission.id,
      orchestratorSlug: mission.orchestrator_slug,
      acpSessionId: mission.acp_session_id,
      title: mission.title,
      status: mission.status,
      createdAt: mission.created_at,
      lastMessageAt: mission.last_message_at
    },
    messages: messages.map((m) => ({
      id: m.id,
      role: m.role,
      content: m.content,
      createdAt: m.created_at
    }))
  };
});

export { active_get as default };

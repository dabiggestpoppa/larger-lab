import { d as defineEventHandler, b as getRouterParam, c as createError, q as getMission, t as archiveMission, v as removeMission } from '../../../../nitro/nitro.mjs';
import 'node:fs';
import 'node:path';
import 'node:os';
import 'yaml';
import 'node:sqlite';
import 'node:child_process';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:crypto';
import 'vue-router';
import 'node:stream';
import '@zed-industries/agent-client-protocol';
import 'node:url';
import '@iconify/utils';
import 'consola';

const archive_post = defineEventHandler((event) => {
  const id = getRouterParam(event, "id");
  if (!id) throw createError({ statusCode: 400, statusMessage: "Missing mission id" });
  const mission = getMission(id);
  if (!mission) throw createError({ statusCode: 404, statusMessage: "Mission not found" });
  archiveMission(id);
  removeMission(id);
  return { ok: true };
});

export { archive_post as default };

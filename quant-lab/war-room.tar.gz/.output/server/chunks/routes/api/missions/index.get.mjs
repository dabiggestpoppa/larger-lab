import { d as defineEventHandler, b as getRouterParam, c as createError, q as getMission, x as listMessages } from '../../../nitro/nitro.mjs';
import 'node:fs';
import 'node:path';
import 'node:os';
import 'yaml';
import 'node:sqlite';
import 'node:child_process';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:crypto';
import 'vue-router';
import 'node:stream';
import '@zed-industries/agent-client-protocol';
import 'node:url';
import '@iconify/utils';
import 'consola';

const index_get = defineEventHandler((event) => {
  const id = getRouterParam(event, "id");
  if (!id) throw createError({ statusCode: 400, statusMessage: "Missing mission id" });
  const m = getMission(id);
  if (!m) throw createError({ statusCode: 404, statusMessage: "Mission not found" });
  const messages = listMessages(id);
  return {
    mission: {
      id: m.id,
      orchestratorSlug: m.orchestrator_slug,
      acpSessionId: m.acp_session_id,
      title: m.title,
      status: m.status,
      createdAt: m.created_at,
      lastMessageAt: m.last_message_at
    },
    messages: messages.map((msg) => ({
      id: msg.id,
      role: msg.role,
      content: msg.content,
      createdAt: msg.created_at
    }))
  };
});

export { index_get as default };

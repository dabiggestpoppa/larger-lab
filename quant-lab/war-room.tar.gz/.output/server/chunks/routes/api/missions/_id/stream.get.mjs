import { d as defineEventHandler, b as getRouterParam, c as createError, q as getMission, y as createEventStream, z as getMissionBus } from '../../../../nitro/nitro.mjs';
import 'node:fs';
import 'node:path';
import 'node:os';
import 'yaml';
import 'node:sqlite';
import 'node:child_process';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:crypto';
import 'vue-router';
import 'node:stream';
import '@zed-industries/agent-client-protocol';
import 'node:url';
import '@iconify/utils';
import 'consola';

const stream_get = defineEventHandler(async (event) => {
  var _a;
  const id = getRouterParam(event, "id");
  if (!id) throw createError({ statusCode: 400, statusMessage: "Missing mission id" });
  const mission = getMission(id);
  if (!mission) throw createError({ statusCode: 404, statusMessage: "Mission not found" });
  const stream = createEventStream(event);
  const bus = getMissionBus(id);
  const onEvent = (e) => {
    stream.push({
      event: e.type,
      data: JSON.stringify(e)
    });
  };
  bus.on("event", onEvent);
  const heartbeat = setInterval(() => {
    stream.push({ event: "ping", data: JSON.stringify({ ts: Date.now() }) });
  }, 25e3);
  (_a = heartbeat.unref) == null ? void 0 : _a.call(heartbeat);
  stream.onClosed(() => {
    clearInterval(heartbeat);
    bus.off("event", onEvent);
  });
  return stream.send();
});

export { stream_get as default };

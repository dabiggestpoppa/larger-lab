import { d as defineEventHandler, b as getRouterParam, c as createError, u as useDb, D as warmup } from '../../../../nitro/nitro.mjs';
import 'node:fs';
import 'node:path';
import 'node:os';
import 'yaml';
import 'node:sqlite';
import 'node:child_process';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:crypto';
import 'vue-router';
import 'node:stream';
import '@zed-industries/agent-client-protocol';
import 'node:url';
import '@iconify/utils';
import 'consola';

const warmup_post = defineEventHandler(async (event) => {
  const slug = getRouterParam(event, "slug");
  if (!slug) throw createError({ statusCode: 400, statusMessage: "Missing slug" });
  const db = useDb();
  const profile = db.prepare("SELECT slug, active FROM profiles WHERE slug = ? AND present = 1").get(slug);
  if (!profile) throw createError({ statusCode: 404, statusMessage: `Profile "${slug}" not found` });
  if (!profile.active) throw createError({ statusCode: 400, statusMessage: `Profile "${slug}" is inactive` });
  const startedAt = Date.now();
  try {
    const { alreadyWarm } = await warmup(slug);
    return {
      ok: true,
      alreadyWarm,
      elapsedMs: Date.now() - startedAt
    };
  } catch (e) {
    throw createError({ statusCode: 500, statusMessage: `Warmup failed: ${e.message}` });
  }
});

export { warmup_post as default };

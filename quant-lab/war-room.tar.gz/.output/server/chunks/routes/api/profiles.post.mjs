import { d as defineEventHandler, r as readBody, c as createError, u as useDb, E as discoverProfiles, J as setDisabledSkills, K as writeSoul, L as writeAgents, w as writeProfileConfig, M as listTools, N as applyToolState, F as defaultSeed, G as pickColor, H as syncRoster, s as setResponseStatus, I as avatarUrl } from '../../nitro/nitro.mjs';
import { spawn } from 'node:child_process';
import 'node:fs';
import 'node:path';
import 'node:os';
import 'yaml';
import 'node:sqlite';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:crypto';
import 'vue-router';
import 'node:stream';
import '@zed-industries/agent-client-protocol';
import 'node:url';
import '@iconify/utils';
import 'consola';

const NAME_RE = /^[a-z0-9]+$/;
function runHermes(args) {
  return new Promise((resolve, reject) => {
    const child = spawn("hermes", args, { stdio: ["ignore", "pipe", "pipe"] });
    child.stdout.setEncoding("utf8");
    child.stderr.setEncoding("utf8");
    let stdout = "";
    let stderr = "";
    child.stdout.on("data", (d) => stdout += d);
    child.stderr.on("data", (d) => stderr += d);
    child.on("error", reject);
    child.on("close", (code) => resolve({ code: code != null ? code : -1, stdout, stderr }));
  });
}
const profiles_post = defineEventHandler(async (event) => {
  var _a, _b, _c, _d;
  const body = await readBody(event) || {};
  const name = ((_a = body.name) != null ? _a : "").trim();
  const cloneFrom = ((_b = body.cloneFrom) == null ? void 0 : _b.trim()) || null;
  if (!name) throw createError({ statusCode: 400, statusMessage: "Profile name is required" });
  if (!NAME_RE.test(name)) {
    throw createError({ statusCode: 400, statusMessage: "Profile name must be lowercase alphanumeric" });
  }
  const db = useDb();
  const existing = db.prepare("SELECT slug FROM profiles WHERE slug = ?").get(name);
  if (existing) {
    throw createError({ statusCode: 409, statusMessage: `Profile "${name}" already exists` });
  }
  if (cloneFrom) {
    const source = db.prepare("SELECT slug FROM profiles WHERE slug = ?").get(cloneFrom);
    if (!source) {
      throw createError({ statusCode: 400, statusMessage: `Source profile "${cloneFrom}" not found` });
    }
  }
  const args = ["profile", "create", name, "--no-alias"];
  if (cloneFrom) args.push("--clone-from", cloneFrom);
  const { code, stderr } = await runHermes(args).catch((e) => {
    throw createError({ statusCode: 500, statusMessage: `Failed to invoke hermes: ${e.message}` });
  });
  if (code !== 0) {
    throw createError({
      statusCode: 500,
      statusMessage: stderr.trim() || `hermes profile create exited with code ${code}`
    });
  }
  const discovered = discoverProfiles().find((p) => p.slug === name);
  if (!discovered) {
    throw createError({
      statusCode: 500,
      statusMessage: `Profile "${name}" was not found on disk after creation`
    });
  }
  if (Array.isArray(body.disabled) && body.disabled.length > 0) {
    const disabled = body.disabled.filter((v) => typeof v === "string" && v.trim() !== "");
    try {
      setDisabledSkills(discovered.hermesDir, disabled);
    } catch (e) {
      throw createError({
        statusCode: 500,
        statusMessage: `Profile created but failed to apply skills config: ${e.message}`
      });
    }
  }
  if (typeof body.soul === "string" && body.soul.trim() !== "") {
    try {
      writeSoul(discovered.hermesDir, body.soul);
    } catch (e) {
      throw createError({
        statusCode: 500,
        statusMessage: `Profile created but failed to write SOUL.md: ${e.message}`
      });
    }
  }
  if (typeof body.agents === "string" && body.agents.trim() !== "") {
    try {
      writeAgents(discovered.hermesDir, body.agents);
    } catch (e) {
      throw createError({
        statusCode: 500,
        statusMessage: `Profile created but failed to write AGENTS.md: ${e.message}`
      });
    }
  }
  const configPatch = {};
  if (body.inheritGlobalModel === true) {
    configPatch.inheritGlobalModel = true;
  } else {
    if ("model" in body) configPatch.model = ((_c = body.model) == null ? void 0 : _c.trim()) || null;
    if ("provider" in body) configPatch.provider = ((_d = body.provider) == null ? void 0 : _d.trim()) || null;
  }
  if (Object.keys(configPatch).length > 0) {
    try {
      writeProfileConfig(discovered.hermesDir, configPatch);
    } catch (e) {
      throw createError({
        statusCode: 500,
        statusMessage: `Profile created but failed to write config.yaml: ${e.message}`
      });
    }
  }
  if (Array.isArray(body.enabledTools)) {
    const requested = new Set(
      body.enabledTools.filter((v) => typeof v === "string" && v.trim() !== "")
    );
    try {
      const current = await listTools(discovered.slug);
      const toEnable = [];
      const toDisable = [];
      for (const t of current) {
        const wantOn = requested.has(t.name);
        if (wantOn && !t.enabled) toEnable.push(t.name);
        else if (!wantOn && t.enabled) toDisable.push(t.name);
      }
      await applyToolState(discovered.slug, toEnable, toDisable);
    } catch (e) {
      throw createError({
        statusCode: 500,
        statusMessage: `Profile created but failed to apply tools config: ${e.message}`
      });
    }
  }
  const now = (/* @__PURE__ */ new Date()).toISOString();
  db.prepare(`
    INSERT INTO profiles (slug, display_name, is_default, hermes_dir, avatar_seed, background_color, gesture, first_seen, last_seen)
    VALUES (?, ?, ?, ?, ?, ?, 'hand', ?, ?)
    ON CONFLICT(slug) DO UPDATE SET
      display_name = excluded.display_name,
      is_default   = excluded.is_default,
      hermes_dir   = excluded.hermes_dir,
      last_seen    = excluded.last_seen
  `).run(
    discovered.slug,
    discovered.slug,
    discovered.isDefault ? 1 : 0,
    discovered.hermesDir,
    defaultSeed(discovered.slug),
    pickColor(discovered.slug),
    now,
    now
  );
  const r = db.prepare("SELECT * FROM profiles WHERE slug = ?").get(discovered.slug);
  try {
    syncRoster();
  } catch (e) {
    console.error("[roster] sync failed after hire:", e.message);
  }
  setResponseStatus(event, 201);
  return {
    slug: r.slug,
    displayName: r.display_name,
    givenName: r.given_name,
    isDefault: r.is_default === 1,
    active: r.active === 1,
    hermesDir: r.hermes_dir,
    backgroundColor: r.background_color,
    gesture: r.gesture,
    avatarUrl: avatarUrl({
      seed: r.avatar_seed,
      backgroundColor: r.background_color,
      gesture: r.gesture,
      size: 240
    }),
    firstSeen: r.first_seen,
    lastSeen: r.last_seen
  };
});

export { profiles_post as default };

import { d as defineEventHandler, b as getRouterParam, c as createError, u as useDb, W as readSoul } from '../../../../nitro/nitro.mjs';
import 'node:fs';
import 'node:path';
import 'node:os';
import 'yaml';
import 'node:sqlite';
import 'node:child_process';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:crypto';
import 'vue-router';
import 'node:stream';
import '@zed-industries/agent-client-protocol';
import 'node:url';
import '@iconify/utils';
import 'consola';

const soul_get = defineEventHandler((event) => {
  const slug = getRouterParam(event, "slug");
  if (!slug) throw createError({ statusCode: 400, statusMessage: "Missing slug" });
  const db = useDb();
  const row = db.prepare("SELECT * FROM profiles WHERE slug = ?").get(slug);
  if (!row) throw createError({ statusCode: 404, statusMessage: "Profile not found" });
  return { soul: readSoul(row.hermes_dir) };
});

export { soul_get as default };

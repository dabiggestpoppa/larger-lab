import { d as defineEventHandler, b as getRouterParam, c as createError, u as useDb, S as removeMcpServer } from '../../../../../nitro/nitro.mjs';
import 'node:fs';
import 'node:path';
import 'node:os';
import 'yaml';
import 'node:sqlite';
import 'node:child_process';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:crypto';
import 'vue-router';
import 'node:stream';
import '@zed-industries/agent-client-protocol';
import 'node:url';
import '@iconify/utils';
import 'consola';

const _name__delete = defineEventHandler((event) => {
  const slug = getRouterParam(event, "slug");
  const name = getRouterParam(event, "name");
  if (!slug) throw createError({ statusCode: 400, statusMessage: "Missing slug" });
  if (!name) throw createError({ statusCode: 400, statusMessage: "Missing MCP server name" });
  const db = useDb();
  const row = db.prepare("SELECT * FROM profiles WHERE slug = ?").get(slug);
  if (!row) throw createError({ statusCode: 404, statusMessage: "Profile not found" });
  let removed = false;
  try {
    removed = removeMcpServer(row.hermes_dir, name);
  } catch (e) {
    throw createError({ statusCode: 500, statusMessage: `Failed to remove MCP server: ${e.message}` });
  }
  if (!removed) {
    throw createError({ statusCode: 404, statusMessage: `MCP server "${name}" not found in profile "${slug}"` });
  }
  return { ok: true };
});

export { _name__delete as default };

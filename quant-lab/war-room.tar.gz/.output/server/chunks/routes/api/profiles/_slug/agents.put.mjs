import { d as defineEventHandler, b as getRouterParam, c as createError, r as readBody, u as useDb, L as writeAgents } from '../../../../nitro/nitro.mjs';
import 'node:fs';
import 'node:path';
import 'node:os';
import 'yaml';
import 'node:sqlite';
import 'node:child_process';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:crypto';
import 'vue-router';
import 'node:stream';
import '@zed-industries/agent-client-protocol';
import 'node:url';
import '@iconify/utils';
import 'consola';

const agents_put = defineEventHandler(async (event) => {
  const slug = getRouterParam(event, "slug");
  if (!slug) throw createError({ statusCode: 400, statusMessage: "Missing slug" });
  const body = await readBody(event) || {};
  if (typeof body.content !== "string") {
    throw createError({ statusCode: 400, statusMessage: "`content` must be a string" });
  }
  const db = useDb();
  const row = db.prepare("SELECT * FROM profiles WHERE slug = ?").get(slug);
  if (!row) throw createError({ statusCode: 404, statusMessage: "Profile not found" });
  try {
    writeAgents(row.hermes_dir, body.content);
  } catch (e) {
    throw createError({ statusCode: 500, statusMessage: `Failed to write AGENTS.md: ${e.message}` });
  }
  return { ok: true };
});

export { agents_put as default };

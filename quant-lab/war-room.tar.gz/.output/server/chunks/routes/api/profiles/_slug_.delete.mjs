import { d as defineEventHandler, b as getRouterParam, c as createError, u as useDb, H as syncRoster, s as setResponseStatus } from '../../../nitro/nitro.mjs';
import { spawn } from 'node:child_process';
import 'node:fs';
import 'node:path';
import 'node:os';
import 'yaml';
import 'node:sqlite';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:crypto';
import 'vue-router';
import 'node:stream';
import '@zed-industries/agent-client-protocol';
import 'node:url';
import '@iconify/utils';
import 'consola';

function runHermes(args) {
  return new Promise((resolve, reject) => {
    const child = spawn("hermes", args, { stdio: ["ignore", "pipe", "pipe"] });
    child.stdout.setEncoding("utf8");
    child.stderr.setEncoding("utf8");
    let stdout = "";
    let stderr = "";
    child.stdout.on("data", (d) => stdout += d);
    child.stderr.on("data", (d) => stderr += d);
    child.on("error", reject);
    child.on("close", (code) => resolve({ code: code != null ? code : -1, stdout, stderr }));
  });
}
const _slug__delete = defineEventHandler(async (event) => {
  const slug = getRouterParam(event, "slug");
  if (!slug) throw createError({ statusCode: 400, statusMessage: "Missing slug" });
  const db = useDb();
  const existing = db.prepare("SELECT slug, is_default FROM profiles WHERE slug = ?").get(slug);
  if (!existing) throw createError({ statusCode: 404, statusMessage: "Profile not found" });
  if (existing.is_default === 1) {
    throw createError({
      statusCode: 400,
      statusMessage: "Cannot fire the default profile \u2014 Hermes needs it to function."
    });
  }
  const { code, stderr } = await runHermes(["profile", "delete", slug, "--yes"]).catch((e) => {
    throw createError({ statusCode: 500, statusMessage: `Failed to invoke hermes: ${e.message}` });
  });
  if (code !== 0) {
    throw createError({
      statusCode: 500,
      statusMessage: stderr.trim() || `hermes profile delete exited with code ${code}`
    });
  }
  db.prepare("DELETE FROM profiles WHERE slug = ?").run(slug);
  try {
    syncRoster();
  } catch (e) {
    console.error("[roster] sync failed after fire:", e.message);
  }
  setResponseStatus(event, 204);
  return null;
});

export { _slug__delete as default };

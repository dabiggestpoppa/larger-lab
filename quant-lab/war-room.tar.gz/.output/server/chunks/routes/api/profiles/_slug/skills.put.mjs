import { d as defineEventHandler, b as getRouterParam, c as createError, r as readBody, u as useDb, J as setDisabledSkills } from '../../../../nitro/nitro.mjs';
import 'node:fs';
import 'node:path';
import 'node:os';
import 'yaml';
import 'node:sqlite';
import 'node:child_process';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:crypto';
import 'vue-router';
import 'node:stream';
import '@zed-industries/agent-client-protocol';
import 'node:url';
import '@iconify/utils';
import 'consola';

const skills_put = defineEventHandler(async (event) => {
  const slug = getRouterParam(event, "slug");
  if (!slug) throw createError({ statusCode: 400, statusMessage: "Missing slug" });
  const body = await readBody(event) || {};
  if (!Array.isArray(body.disabled)) {
    throw createError({ statusCode: 400, statusMessage: "`disabled` must be an array of skill names" });
  }
  const disabled = body.disabled.filter((v) => typeof v === "string" && v.trim() !== "");
  const db = useDb();
  const row = db.prepare("SELECT * FROM profiles WHERE slug = ?").get(slug);
  if (!row) throw createError({ statusCode: 404, statusMessage: "Profile not found" });
  try {
    setDisabledSkills(row.hermes_dir, disabled);
  } catch (e) {
    throw createError({ statusCode: 500, statusMessage: `Failed to update skills: ${e.message}` });
  }
  return { ok: true, disabled: [...new Set(disabled)].sort() };
});

export { skills_put as default };

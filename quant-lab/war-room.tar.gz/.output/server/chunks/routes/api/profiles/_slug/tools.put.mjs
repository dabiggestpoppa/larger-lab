import { d as defineEventHandler, b as getRouterParam, c as createError, r as readBody, u as useDb, M as listTools, N as applyToolState } from '../../../../nitro/nitro.mjs';
import 'node:fs';
import 'node:path';
import 'node:os';
import 'yaml';
import 'node:sqlite';
import 'node:child_process';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:crypto';
import 'vue-router';
import 'node:stream';
import '@zed-industries/agent-client-protocol';
import 'node:url';
import '@iconify/utils';
import 'consola';

const tools_put = defineEventHandler(async (event) => {
  const slug = getRouterParam(event, "slug");
  if (!slug) throw createError({ statusCode: 400, statusMessage: "Missing slug" });
  const body = await readBody(event) || {};
  if (!Array.isArray(body.enabled)) {
    throw createError({ statusCode: 400, statusMessage: "`enabled` must be an array of toolset names" });
  }
  const requested = new Set(body.enabled.filter((v) => typeof v === "string" && v.trim() !== ""));
  const db = useDb();
  const row = db.prepare("SELECT slug FROM profiles WHERE slug = ?").get(slug);
  if (!row) throw createError({ statusCode: 404, statusMessage: "Profile not found" });
  const current = await listTools(slug);
  const known = new Set(current.map((t) => t.name));
  const target = new Set([...requested].filter((n) => known.has(n)));
  const toEnable = [];
  const toDisable = [];
  for (const t of current) {
    const wantOn = target.has(t.name);
    if (wantOn && !t.enabled) toEnable.push(t.name);
    else if (!wantOn && t.enabled) toDisable.push(t.name);
  }
  try {
    await applyToolState(slug, toEnable, toDisable);
  } catch (e) {
    throw createError({ statusCode: 500, statusMessage: `Failed to update tools: ${e.message}` });
  }
  return { ok: true, enabled: [...target].sort() };
});

export { tools_put as default };

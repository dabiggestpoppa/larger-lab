import { d as defineEventHandler, b as getRouterParam, c as createError, r as readBody, u as useDb, E as discoverProfiles, H as syncRoster, I as avatarUrl } from '../../../../nitro/nitro.mjs';
import { spawn } from 'node:child_process';
import 'node:fs';
import 'node:path';
import 'node:os';
import 'yaml';
import 'node:sqlite';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:crypto';
import 'vue-router';
import 'node:stream';
import '@zed-industries/agent-client-protocol';
import 'node:url';
import '@iconify/utils';
import 'consola';

const NAME_RE = /^[a-z0-9]+$/;
function runHermes(args) {
  return new Promise((resolve, reject) => {
    const child = spawn("hermes", args, { stdio: ["ignore", "pipe", "pipe"] });
    child.stdout.setEncoding("utf8");
    child.stderr.setEncoding("utf8");
    let stdout = "";
    let stderr = "";
    child.stdout.on("data", (d) => stdout += d);
    child.stderr.on("data", (d) => stderr += d);
    child.on("error", reject);
    child.on("close", (code) => resolve({ code: code != null ? code : -1, stdout, stderr }));
  });
}
const rename_post = defineEventHandler(async (event) => {
  var _a, _b;
  const slug = getRouterParam(event, "slug");
  if (!slug) throw createError({ statusCode: 400, statusMessage: "Missing slug" });
  const body = await readBody(event) || {};
  const newSlug = ((_a = body.newSlug) != null ? _a : "").trim();
  if (!newSlug) throw createError({ statusCode: 400, statusMessage: "newSlug required" });
  if (!NAME_RE.test(newSlug)) {
    throw createError({ statusCode: 400, statusMessage: "Profile name must be lowercase alphanumeric" });
  }
  if (newSlug === slug) {
    throw createError({ statusCode: 400, statusMessage: "newSlug must differ from current slug" });
  }
  const db = useDb();
  const existing = db.prepare("SELECT * FROM profiles WHERE slug = ?").get(slug);
  if (!existing) throw createError({ statusCode: 404, statusMessage: "Profile not found" });
  if (existing.is_default === 1) {
    throw createError({ statusCode: 400, statusMessage: "Cannot rename the default profile" });
  }
  const conflict = db.prepare("SELECT slug FROM profiles WHERE slug = ?").get(newSlug);
  if (conflict) {
    throw createError({ statusCode: 409, statusMessage: `Profile "${newSlug}" already exists` });
  }
  const { code, stderr } = await runHermes(["profile", "rename", slug, newSlug]).catch((e) => {
    throw createError({ statusCode: 500, statusMessage: `Failed to invoke hermes: ${e.message}` });
  });
  if (code !== 0) {
    throw createError({
      statusCode: 500,
      statusMessage: stderr.trim() || `hermes profile rename exited with code ${code}`
    });
  }
  const discovered = discoverProfiles().find((p) => p.slug === newSlug);
  const newHermesDir = (_b = discovered == null ? void 0 : discovered.hermesDir) != null ? _b : existing.hermes_dir.replace(/[/\\][^/\\]+$/, "/" + newSlug);
  db.prepare(`
    UPDATE profiles
       SET slug = ?, display_name = ?, hermes_dir = ?
     WHERE slug = ?
  `).run(newSlug, newSlug, newHermesDir, slug);
  try {
    syncRoster();
  } catch (e) {
    console.error("[roster] sync failed after rename:", e.message);
  }
  const r = db.prepare("SELECT * FROM profiles WHERE slug = ?").get(newSlug);
  return {
    slug: r.slug,
    displayName: r.display_name,
    givenName: r.given_name,
    isDefault: r.is_default === 1,
    active: r.active === 1,
    hermesDir: r.hermes_dir,
    backgroundColor: r.background_color,
    gesture: r.gesture,
    avatarSeed: r.avatar_seed,
    avatarUrl: avatarUrl({
      seed: r.avatar_seed,
      backgroundColor: r.background_color,
      gesture: r.gesture,
      size: 240
    }),
    avatarPortraitUrl: avatarUrl({
      seed: r.avatar_seed,
      gesture: r.gesture,
      size: 320,
      transparent: true
    }),
    firstSeen: r.first_seen,
    lastSeen: r.last_seen
  };
});

export { rename_post as default };

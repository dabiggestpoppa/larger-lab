import { d as defineEventHandler, b as getRouterParam, c as createError, u as useDb, T as listGlobalSkills, U as listProfileSkills, V as getDisabledSkills } from '../../../../nitro/nitro.mjs';
import 'node:fs';
import 'node:path';
import 'node:os';
import 'yaml';
import 'node:sqlite';
import 'node:child_process';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:crypto';
import 'vue-router';
import 'node:stream';
import '@zed-industries/agent-client-protocol';
import 'node:url';
import '@iconify/utils';
import 'consola';

const skills_get = defineEventHandler((event) => {
  const slug = getRouterParam(event, "slug");
  if (!slug) throw createError({ statusCode: 400, statusMessage: "Missing slug" });
  const db = useDb();
  const row = db.prepare("SELECT * FROM profiles WHERE slug = ?").get(slug);
  if (!row) throw createError({ statusCode: 404, statusMessage: "Profile not found" });
  const all = [
    ...listGlobalSkills(),
    ...listProfileSkills(row.hermes_dir)
  ];
  const disabled = new Set(getDisabledSkills(row.hermes_dir));
  const seen = /* @__PURE__ */ new Map();
  for (const s of all) {
    if (!seen.has(s.name) || s.source === "profile") seen.set(s.name, s);
  }
  return [...seen.values()].sort((a, b) => {
    var _a, _b;
    return ((_a = a.category) != null ? _a : "").localeCompare((_b = b.category) != null ? _b : "") || a.name.localeCompare(b.name);
  }).map((s) => ({
    name: s.name,
    category: s.category,
    description: s.description,
    source: s.source,
    enabled: !disabled.has(s.name)
  }));
});

export { skills_get as default };

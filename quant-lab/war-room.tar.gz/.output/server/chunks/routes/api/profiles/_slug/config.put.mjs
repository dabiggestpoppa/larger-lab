import { d as defineEventHandler, b as getRouterParam, c as createError, r as readBody, u as useDb, w as writeProfileConfig, Q as restart, f as readProfileConfig } from '../../../../nitro/nitro.mjs';
import 'node:fs';
import 'node:path';
import 'node:os';
import 'yaml';
import 'node:sqlite';
import 'node:child_process';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:crypto';
import 'vue-router';
import 'node:stream';
import '@zed-industries/agent-client-protocol';
import 'node:url';
import '@iconify/utils';
import 'consola';

const config_put = defineEventHandler(async (event) => {
  const slug = getRouterParam(event, "slug");
  if (!slug) throw createError({ statusCode: 400, statusMessage: "Missing slug" });
  const body = await readBody(event) || {};
  const db = useDb();
  const row = db.prepare("SELECT * FROM profiles WHERE slug = ?").get(slug);
  if (!row) throw createError({ statusCode: 404, statusMessage: "Profile not found" });
  const patch = {};
  if (body.inheritGlobalModel === true) {
    patch.inheritGlobalModel = true;
  } else {
    if ("model" in body) {
      if (body.model === null || typeof body.model === "string") patch.model = body.model;
    }
    if ("provider" in body) {
      if (body.provider === null || typeof body.provider === "string") patch.provider = body.provider;
    }
  }
  if ("allowlist" in body) {
    if (!Array.isArray(body.allowlist)) {
      throw createError({ statusCode: 400, statusMessage: "`allowlist` must be an array of strings" });
    }
    patch.allowlist = body.allowlist.filter((v) => typeof v === "string");
  }
  if ("name" in body) {
    if (body.name === null || typeof body.name === "string") patch.name = body.name;
  }
  if (Object.keys(patch).length === 0) {
    throw createError({ statusCode: 400, statusMessage: "No-op" });
  }
  try {
    writeProfileConfig(row.hermes_dir, patch);
  } catch (e) {
    throw createError({ statusCode: 500, statusMessage: `Failed to update config: ${e.message}` });
  }
  const restarted = restart(slug);
  return {
    ...readProfileConfig(row.hermes_dir),
    acpRestarted: restarted.killed
  };
});

export { config_put as default };

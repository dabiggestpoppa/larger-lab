import { d as defineEventHandler, b as getRouterParam, c as createError } from '../../../../../nitro/nitro.mjs';
import { existsSync, statSync, readFileSync } from 'node:fs';
import { join } from 'node:path';
import { homedir } from 'node:os';
import 'yaml';
import 'node:sqlite';
import 'node:child_process';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:crypto';
import 'vue-router';
import 'node:stream';
import '@zed-industries/agent-client-protocol';
import 'node:url';
import '@iconify/utils';
import 'consola';

const HERMES_HOME = process.env.HERMES_HOME || join(homedir(), ".hermes");
const MAX_BYTES = 4 * 1024 * 1024;
const log_get = defineEventHandler((event) => {
  const id = getRouterParam(event, "id");
  if (!id) throw createError({ statusCode: 400, statusMessage: "Missing task id" });
  const path = join(HERMES_HOME, "kanban", "logs", `${id}.log`);
  if (!existsSync(path)) {
    return {
      taskId: id,
      exists: false,
      bytes: null,
      startedAt: null,
      lastActivityAt: null,
      truncated: false,
      content: null
    };
  }
  const st = statSync(path);
  const startedAt = Math.floor(st.birthtimeMs || st.ctimeMs || st.mtimeMs);
  const lastActivityAt = st.mtimeMs;
  let content = readFileSync(path, { encoding: "utf8" });
  let truncated = false;
  if (content.length > MAX_BYTES) {
    content = content.slice(content.length - MAX_BYTES);
    const nl = content.indexOf("\n");
    if (nl > 0) content = content.slice(nl + 1);
    truncated = true;
  }
  return {
    taskId: id,
    exists: true,
    bytes: st.size,
    startedAt,
    lastActivityAt,
    truncated,
    content
  };
});

export { log_get as default };

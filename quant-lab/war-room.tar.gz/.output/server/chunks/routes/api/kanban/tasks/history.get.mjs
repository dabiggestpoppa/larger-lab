import { d as defineEventHandler, g as getQuery, n as listCompletedTasks, u as useDb } from '../../../../nitro/nitro.mjs';
import 'node:fs';
import 'node:path';
import 'node:os';
import 'yaml';
import 'node:sqlite';
import 'node:child_process';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:crypto';
import 'vue-router';
import 'node:stream';
import '@zed-industries/agent-client-protocol';
import 'node:url';
import '@iconify/utils';
import 'consola';

const history_get = defineEventHandler((event) => {
  var _a;
  const q = getQuery(event);
  const assignee = typeof q.assignee === "string" ? q.assignee : void 0;
  const mission = typeof q.mission === "string" ? q.mission : void 0;
  const beforeRaw = typeof q.before === "string" ? Number(q.before) : void 0;
  const before = beforeRaw && Number.isFinite(beforeRaw) ? beforeRaw : void 0;
  const limitRaw = typeof q.limit === "string" ? Number(q.limit) : void 0;
  const limit = limitRaw && Number.isFinite(limitRaw) ? limitRaw : void 0;
  let tasks = listCompletedTasks({ assignee, before, limit });
  if (mission) {
    const rows = useDb().prepare("SELECT task_id FROM mission_watched_tasks WHERE mission_id = ?").all(mission);
    const allowed = new Set(rows.map((r) => r.task_id));
    tasks = tasks.filter((t) => allowed.has(t.id));
  }
  const last = tasks[tasks.length - 1];
  const nextBefore = last ? (_a = last.completedAt) != null ? _a : last.createdAt : null;
  const hasMore = tasks.length > 0 && tasks.length === (limit != null ? limit : 20);
  return { tasks, nextBefore: hasMore ? nextBefore : null, hasMore };
});

export { history_get as default };

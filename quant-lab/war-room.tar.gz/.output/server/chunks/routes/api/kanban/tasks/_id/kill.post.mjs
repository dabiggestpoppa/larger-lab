import { d as defineEventHandler, b as getRouterParam, c as createError, r as readBody } from '../../../../../nitro/nitro.mjs';
import { spawn } from 'node:child_process';
import 'node:fs';
import 'node:path';
import 'node:os';
import 'yaml';
import 'node:sqlite';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:crypto';
import 'vue-router';
import 'node:stream';
import '@zed-industries/agent-client-protocol';
import 'node:url';
import '@iconify/utils';
import 'consola';

function runHermes(args) {
  return new Promise((resolve, reject) => {
    const child = spawn("hermes", args, { stdio: ["ignore", "pipe", "pipe"] });
    child.stdout.setEncoding("utf8");
    child.stderr.setEncoding("utf8");
    let stdout = "";
    let stderr = "";
    child.stdout.on("data", (d) => stdout += d);
    child.stderr.on("data", (d) => stderr += d);
    child.on("error", reject);
    child.on("close", (code) => resolve({ code: code != null ? code : -1, stdout, stderr }));
  });
}
function killPid(pid, signal) {
  try {
    process.kill(pid, signal);
    return { ok: true };
  } catch (e) {
    const code = e.code;
    if (code === "ESRCH") return { ok: true };
    if (code === "EPERM") return { ok: false, error: "no permission" };
    return { ok: false, error: e.message };
  }
}
const kill_post = defineEventHandler(async (event) => {
  var _a, _b;
  const id = getRouterParam(event, "id");
  if (!id) throw createError({ statusCode: 400, statusMessage: "Missing task id" });
  const body = await readBody(event).catch(() => ({})) || {};
  const reason = ((_a = body.reason) != null ? _a : "killed via war-room").trim() || "killed via war-room";
  const runsResult = await runHermes(["kanban", "runs", id, "--json"]).catch((e) => {
    throw createError({ statusCode: 500, statusMessage: `Failed to list runs: ${e.message}` });
  });
  if (runsResult.code !== 0) {
    throw createError({
      statusCode: 500,
      statusMessage: runsResult.stderr.trim() || `hermes kanban runs exited with code ${runsResult.code}`
    });
  }
  let runs = [];
  try {
    runs = JSON.parse(runsResult.stdout || "[]");
  } catch {
    runs = [];
  }
  const livePids = runs.filter((r) => r.status === "running" && !r.ended_at && typeof r.worker_pid === "number").map((r) => r.worker_pid);
  const workersKilled = [];
  const workersFailed = [];
  for (const pid of livePids) {
    const term = killPid(pid, "SIGTERM");
    if (!term.ok) {
      workersFailed.push({ pid, reason: (_b = term.error) != null ? _b : "unknown" });
      continue;
    }
    workersKilled.push(pid);
  }
  if (workersKilled.length) {
    await new Promise((r) => setTimeout(r, 600));
    for (const pid of workersKilled) {
      try {
        process.kill(pid, 0);
        killPid(pid, "SIGKILL");
      } catch {
      }
    }
  }
  await runHermes(["kanban", "block", id, reason]).catch(() => null);
  const archiveResult = await runHermes(["kanban", "archive", id]).catch((e) => ({
    code: -1,
    stdout: "",
    stderr: e.message
  }));
  const archived = archiveResult.code === 0;
  return {
    taskId: id,
    workersKilled,
    workersFailed,
    archived,
    archiveError: archived ? void 0 : archiveResult.stderr.trim() || `code ${archiveResult.code}`
  };
});

export { kill_post as default };

import { d as defineEventHandler, b as getRouterParam, c as createError, e as getKanbanDb, h as getFailureContext, i as distillReason, j as extractPermissionLabel, k as looksLikePermissionDenial } from '../../../../../nitro/nitro.mjs';
import 'node:fs';
import 'node:path';
import 'node:os';
import 'yaml';
import 'node:sqlite';
import 'node:child_process';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:crypto';
import 'vue-router';
import 'node:stream';
import '@zed-industries/agent-client-protocol';
import 'node:url';
import '@iconify/utils';
import 'consola';

const failure_get = defineEventHandler((event) => {
  const id = getRouterParam(event, "id");
  if (!id) throw createError({ statusCode: 400, statusMessage: "Missing task id" });
  const db = getKanbanDb();
  let status = null;
  let assignee = null;
  if (db) {
    const row = db.prepare("SELECT status, assignee FROM tasks WHERE id = ?").get(id);
    if (row) {
      status = row.status;
      assignee = row.assignee;
    }
  }
  const ctx = getFailureContext(id);
  const reason = distillReason(ctx);
  const permissionDenial = looksLikePermissionDenial(reason);
  const suggestedLabel = permissionDenial ? extractPermissionLabel(reason) : null;
  return {
    taskId: id,
    status,
    assignee,
    reason,
    lastComment: ctx.lastComment,
    lastRunOutcome: ctx.lastRunOutcome,
    lastRunError: ctx.lastRunError,
    taskResult: ctx.taskResult,
    spawnFailures: ctx.spawnFailures,
    permissionDenial,
    suggestedLabel
  };
});

export { failure_get as default };

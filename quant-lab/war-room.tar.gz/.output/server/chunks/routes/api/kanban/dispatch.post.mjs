import { d as defineEventHandler } from '../../../nitro/nitro.mjs';
import { spawn } from 'node:child_process';
import 'node:fs';
import 'node:path';
import 'node:os';
import 'yaml';
import 'node:sqlite';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:crypto';
import 'vue-router';
import 'node:stream';
import '@zed-industries/agent-client-protocol';
import 'node:url';
import '@iconify/utils';
import 'consola';

function runHermes(args) {
  return new Promise((resolve, reject) => {
    const child = spawn("hermes", args, { stdio: ["ignore", "pipe", "pipe"] });
    child.stdout.setEncoding("utf8");
    child.stderr.setEncoding("utf8");
    let stdout = "";
    let stderr = "";
    child.stdout.on("data", (d) => stdout += d);
    child.stderr.on("data", (d) => stderr += d);
    child.on("error", reject);
    child.on("close", (code) => resolve({ code: code != null ? code : -1, stdout, stderr }));
  });
}
const dispatch_post = defineEventHandler(async () => {
  const res = await runHermes(["kanban", "dispatch", "--json"]).catch((e) => ({
    code: -1,
    stdout: "",
    stderr: e.message
  }));
  return {
    ok: res.code === 0,
    code: res.code,
    stdout: res.stdout,
    stderr: res.stderr
  };
});

export { dispatch_post as default };

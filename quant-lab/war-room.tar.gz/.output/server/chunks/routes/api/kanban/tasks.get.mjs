import { d as defineEventHandler, g as getQuery, l as listActiveTasks, u as useDb, a as dispatcherLikelyStale } from '../../../nitro/nitro.mjs';
import 'node:fs';
import 'node:path';
import 'node:os';
import 'yaml';
import 'node:sqlite';
import 'node:child_process';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:crypto';
import 'vue-router';
import 'node:stream';
import '@zed-industries/agent-client-protocol';
import 'node:url';
import '@iconify/utils';
import 'consola';

const tasks_get = defineEventHandler((event) => {
  const q = getQuery(event);
  const assignee = typeof q.assignee === "string" ? q.assignee : void 0;
  const mission = typeof q.mission === "string" ? q.mission : void 0;
  let tasks = listActiveTasks(assignee);
  if (mission) {
    const rows = useDb().prepare("SELECT task_id FROM mission_watched_tasks WHERE mission_id = ?").all(mission);
    const allowed = new Set(rows.map((r) => r.task_id));
    tasks = tasks.filter((t) => allowed.has(t.id));
  }
  return {
    tasks,
    dispatcherStale: dispatcherLikelyStale()
  };
});

export { tasks_get as default };

import { d as defineEventHandler, b as getRouterParam, c as createError, r as readBody, e as getKanbanDb, u as useDb, f as readProfileConfig, w as writeProfileConfig } from '../../../../../nitro/nitro.mjs';
import { spawn } from 'node:child_process';
import 'node:fs';
import 'node:path';
import 'node:os';
import 'yaml';
import 'node:sqlite';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:crypto';
import 'vue-router';
import 'node:stream';
import '@zed-industries/agent-client-protocol';
import 'node:url';
import '@iconify/utils';
import 'consola';

function runHermes(args) {
  return new Promise((resolve, reject) => {
    const child = spawn("hermes", args, { stdio: ["ignore", "pipe", "pipe"] });
    child.stdout.setEncoding("utf8");
    child.stderr.setEncoding("utf8");
    let stdout = "";
    let stderr = "";
    child.stdout.on("data", (d) => stdout += d);
    child.stderr.on("data", (d) => stderr += d);
    child.on("error", reject);
    child.on("close", (code) => resolve({ code: code != null ? code : -1, stdout, stderr }));
  });
}
const approveAndRetry_post = defineEventHandler(async (event) => {
  var _a;
  const id = getRouterParam(event, "id");
  if (!id) throw createError({ statusCode: 400, statusMessage: "Missing task id" });
  const body = await readBody(event).catch(() => ({})) || {};
  const label = ((_a = body.label) != null ? _a : "").trim();
  if (!label) {
    throw createError({ statusCode: 400, statusMessage: "`label` is required" });
  }
  if (label.length > 200) {
    throw createError({ statusCode: 400, statusMessage: "label too long (max 200 chars)" });
  }
  const shouldDispatch = body.dispatch !== false;
  const kdb = getKanbanDb();
  if (!kdb) throw createError({ statusCode: 500, statusMessage: "kanban.db unavailable" });
  const task = kdb.prepare("SELECT assignee FROM tasks WHERE id = ?").get(id);
  if (!task) throw createError({ statusCode: 404, statusMessage: "task not found" });
  if (!task.assignee) {
    throw createError({ statusCode: 400, statusMessage: "task has no assignee \u2014 nothing to allowlist" });
  }
  const wrDb = useDb();
  const profile = wrDb.prepare("SELECT * FROM profiles WHERE slug = ?").get(task.assignee);
  if (!profile) {
    throw createError({
      statusCode: 404,
      statusMessage: `assignee profile "${task.assignee}" not found in war-room.db`
    });
  }
  const cfg = readProfileConfig(profile.hermes_dir);
  const existing = new Set(cfg.allowlist);
  const added = !existing.has(label);
  const allowlist = added ? [...cfg.allowlist, label].sort() : cfg.allowlist;
  if (added) {
    try {
      writeProfileConfig(profile.hermes_dir, { allowlist });
    } catch (e) {
      throw createError({
        statusCode: 500,
        statusMessage: `Failed to update command_allowlist: ${e.message}`
      });
    }
  }
  const unblockRes = await runHermes(["kanban", "unblock", id]).catch((e) => ({
    code: -1,
    stdout: "",
    stderr: e.message
  }));
  const unblocked = unblockRes.code === 0;
  const unblockError = unblocked ? void 0 : unblockRes.stderr.trim() || `code ${unblockRes.code}`;
  let dispatched = false;
  let dispatchError;
  if (shouldDispatch && unblocked) {
    const dispatchRes = await runHermes(["kanban", "dispatch", "--json"]).catch((e) => ({
      code: -1,
      stdout: "",
      stderr: e.message
    }));
    dispatched = dispatchRes.code === 0;
    dispatchError = dispatched ? void 0 : dispatchRes.stderr.trim() || `code ${dispatchRes.code}`;
  }
  return {
    taskId: id,
    profile: task.assignee,
    added,
    allowlist,
    unblocked,
    unblockError,
    dispatched,
    dispatchError
  };
});

export { approveAndRetry_post as default };

import { d as defineEventHandler, T as listGlobalSkills } from '../../nitro/nitro.mjs';
import 'node:fs';
import 'node:path';
import 'node:os';
import 'yaml';
import 'node:sqlite';
import 'node:child_process';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:crypto';
import 'vue-router';
import 'node:stream';
import '@zed-industries/agent-client-protocol';
import 'node:url';
import '@iconify/utils';
import 'consola';

const skills_get = defineEventHandler(() => {
  const skills = listGlobalSkills();
  const seen = /* @__PURE__ */ new Map();
  for (const s of skills) {
    if (!seen.has(s.name)) seen.set(s.name, s);
  }
  return [...seen.values()].sort((a, b) => {
    var _a, _b;
    return ((_a = a.category) != null ? _a : "").localeCompare((_b = b.category) != null ? _b : "") || a.name.localeCompare(b.name);
  }).map((s) => ({
    name: s.name,
    category: s.category,
    description: s.description,
    source: s.source,
    enabled: true
  }));
});

export { skills_get as default };

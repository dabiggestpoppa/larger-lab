import { d as defineEventHandler, M as listTools } from '../../nitro/nitro.mjs';
import 'node:fs';
import 'node:path';
import 'node:os';
import 'yaml';
import 'node:sqlite';
import 'node:child_process';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:crypto';
import 'vue-router';
import 'node:stream';
import '@zed-industries/agent-client-protocol';
import 'node:url';
import '@iconify/utils';
import 'consola';

const tools_get = defineEventHandler(async () => {
  return listTools();
});

export { tools_get as default };
